/**
 * DARIMMO - SaaS Immobilier Professionnel Niger & Afrique Francophone
 * Application principale avec gestion multi-tenant, baux OHADA, quittances et paiements locaux
 */

import React, { useState, useEffect } from 'react';
import { storage } from './services/storage';
import { auth, DEMO_USERS } from './services/auth';
import { firestoreService } from './services/firestoreService';
import { AlertTriangle, PlayCircle, ShieldAlert, Lock } from 'lucide-react';
import { 
  UserProfile, 
  Property, 
  Tenant, 
  Lease, 
  RentPayment, 
  RentDue,
  Expense, 
  RepairTicket, 
  AgencyMember, 
  SubscriptionState, 
  SubscriptionPaymentRequest, 
  AppNotification, 
  AuditLog, 
  AppConfig, 
  PlanConfig 
} from './types';

// Components
import { Header } from './components/common/Header';
import { Sidebar } from './components/common/Sidebar';
import { MobileNav } from './components/common/MobileNav';
import { ReceiptModal } from './components/common/ReceiptModal';
import { LeaseDocumentModal } from './components/common/LeaseDocumentModal';
import { WhatsAppReminderModal } from './components/common/WhatsAppReminderModal';
import { SplashScreen } from './components/common/SplashScreen';
import { LandingPage } from './components/landing/LandingPage';
import { AuthModal } from './components/auth/AuthModal';
import { DashboardOverview } from './components/dashboard/DashboardOverview';
import { PropertiesList } from './components/properties/PropertiesList';
import { PropertyModal } from './components/properties/PropertyModal';
import { PropertyDetailModal } from './components/properties/PropertyDetailModal';
import { TenantsList } from './components/tenants/TenantsList';
import { TenantModal } from './components/tenants/TenantModal';
import { LeasesList } from './components/leases/LeasesList';
import { LeaseModal } from './components/leases/LeaseModal';
import { RentsList } from './components/rents/RentsList';
import { RentPaymentModal } from './components/rents/RentPaymentModal';
import { ExpensesList } from './components/expenses/ExpensesList';
import { ExpenseModal } from './components/expenses/ExpenseModal';
import { RepairsList } from './components/repairs/RepairsList';
import { RepairModal } from './components/repairs/RepairModal';
import { ReportsView } from './components/reports/ReportsView';
import { AgencyTeamView } from './components/agency/AgencyTeamView';
import { TenantPortalView } from './components/tenant-portal/TenantPortalView';
import { SubscriptionView } from './components/subscription/SubscriptionView';
import { SuperAdminView } from './components/admin/SuperAdminView';
import { MaintenancePage } from './components/maintenance/MaintenancePage';
import { ErrorView } from './components/errors/ErrorPages';
import { DevErrorSimulatorModal } from './components/errors/DevErrorSimulatorModal';

export default function App() {
  // Authentication & session
  const [currentUser, setCurrentUser] = useState<UserProfile | null>(auth.getCurrentUser());
  const [isDemo, setIsDemo] = useState<boolean>(auth.isDemoMode());
  const [currentView, setCurrentView] = useState<string>('dashboard');
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState<boolean>(false);
  const [authModalOpen, setAuthModalOpen] = useState<boolean>(false);
  const [authInitialMode, setAuthInitialMode] = useState<'login' | 'signup' | 'forgot'>('login');

  // Application state
  const [config, setConfig] = useState<AppConfig>(storage.getConfig());
  const [plans, setPlans] = useState<PlanConfig[]>(storage.getPlans());
  const [properties, setProperties] = useState<Property[]>([]);
  const [organizations, setOrganizations] = useState<UserProfile[]>([]);
  const [allUsers, setAllUsers] = useState<UserProfile[]>([]);
  const [tenants, setTenants] = useState<Tenant[]>([]);
  const [leases, setLeases] = useState<Lease[]>([]);
  const [payments, setPayments] = useState<RentPayment[]>([]);
  const [rentDues, setRentDues] = useState<RentDue[]>([]);
  const [expenses, setExpenses] = useState<Expense[]>([]);
  const [repairs, setRepairs] = useState<RepairTicket[]>([]);
  const [agencyMembers, setAgencyMembers] = useState<AgencyMember[]>([]);
  const [subscription, setSubscription] = useState<SubscriptionState>(
    storage.getSubscription(currentUser?.organizationId || 'org_owner_1')
  );
  const [paymentRequests, setPaymentRequests] = useState<SubscriptionPaymentRequest[]>(
    storage.getPaymentRequests()
  );
  const [notifications, setNotifications] = useState<AppNotification[]>([]);
  const [auditLogs, setAuditLogs] = useState<AuditLog[]>([]);

  // Modals state
  const [activeReceiptPayment, setActiveReceiptPayment] = useState<RentPayment | null>(null);
  const [activeLeaseDocument, setActiveLeaseDocument] = useState<Lease | null>(null);
  const [activeDetailProperty, setActiveDetailProperty] = useState<Property | null>(null);
  const [activeReminderPayment, setActiveReminderPayment] = useState<RentPayment | null>(null);
  const [propertyModalOpen, setPropertyModalOpen] = useState<boolean>(false);
  const [editingProperty, setEditingProperty] = useState<Property | null>(null);
  const [adminTargetOrganizationId, setAdminTargetOrganizationId] = useState<string>('');
  const [tenantModalOpen, setTenantModalOpen] = useState<boolean>(false);
  const [editingTenant, setEditingTenant] = useState<Tenant | null>(null);
  const [leaseModalOpen, setLeaseModalOpen] = useState<boolean>(false);
  const [editingLease, setEditingLease] = useState<Lease | null>(null);
  const [rentModalOpen, setRentModalOpen] = useState<boolean>(false);
  const [editingPayment, setEditingPayment] = useState<RentPayment | null>(null);
  const [selectedRentDue, setSelectedRentDue] = useState<RentDue | null>(null);
  const [expenseModalOpen, setExpenseModalOpen] = useState<boolean>(false);
  const [editingExpense, setEditingExpense] = useState<Expense | null>(null);
  const [repairModalOpen, setRepairModalOpen] = useState<boolean>(false);
  const [editingRepair, setEditingRepair] = useState<RepairTicket | null>(null);
  const [devSimulatorOpen, setDevSimulatorOpen] = useState<boolean>(false);
  const [simulatedError, setSimulatedError] = useState<{ code: 400 | 401 | 403 | 404 | 500; message?: string } | null>(null);

  // Toast feedback
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => {
      setToastMessage(null);
    }, 3500);
  };

  const [showSplash, setShowSplash] = useState<boolean>(true);

  // Subscribe to auth changes (Firebase real user or demo session)
  useEffect(() => {
    const unsubscribe = auth.subscribe((user, demoActive) => {
      setCurrentUser(user);
      setIsDemo(demoActive);
      if (user) {
        loadDataForOrganization(user.organizationId, demoActive, user.role);
      }
    });
    return () => unsubscribe();
  }, []);

  // Real-time Firestore maintenance mode synchronization (collection app_config / doc maintenance)
  useEffect(() => {
    const unsubMaintenance = firestoreService.onMaintenanceChange((maintCfg) => {
      setConfig(prev => ({
        ...prev,
        maintenanceMode: maintCfg.maintenanceMode,
        maintenanceMessage: maintCfg.maintenanceMessage || prev.maintenanceMessage,
        maintenanceExpectedEnd: maintCfg.maintenanceExpectedEnd || prev.maintenanceExpectedEnd
      }));
    });
    return () => unsubMaintenance();
  }, []);

  // Reload data for the active organization
  const loadDataForOrganization = async (orgId: string, demoMode: boolean, userRole: string = currentUser?.role || '') => {
    if (demoMode) {
      // In isolated demo mode, use in-memory / storage sandbox
      setProperties(storage.getProperties(orgId));
      setTenants(storage.getTenants(orgId));
      setLeases(storage.getLeases(orgId));
      setRentDues(storage.getRentDues(orgId));
      setPayments(storage.getRentPayments(orgId));
      setExpenses(storage.getExpenses(orgId));
      setRepairs(storage.getRepairs(orgId));
      setAgencyMembers(storage.getAgencyMembers(orgId));
      setSubscription(storage.getSubscription(orgId));
      setPaymentRequests(storage.getPaymentRequests());
      setNotifications(storage.getNotifications(orgId));
      setAuditLogs(storage.getAuditLogs());
    } else if (userRole === 'super_admin') {
      // Vue globale : toutes les organisations et tous les biens de la plateforme.
      try {
        const [allProperties, allOrganizations, allRequests, allLogs, usersList] = await Promise.all([
          firestoreService.getAllProperties(),
          firestoreService.getAllOrganizations(),
          firestoreService.getPaymentRequests(),
          firestoreService.getAuditLogs(),
          firestoreService.getAllUsers()
        ]);
        setProperties(allProperties);
        setOrganizations(allOrganizations);
        setAllUsers(usersList);
        setTenants([]);
        setLeases([]);
        setRentDues([]);
        setPayments([]);
        setExpenses([]);
        setRepairs([]);
        setAgencyMembers([]);
        setNotifications([]);
        setPaymentRequests(allRequests);
        setAuditLogs(allLogs);
        setSubscription(storage.getSubscription(orgId));
      } catch (err) {
        console.error('Erreur chargement global Super Admin:', err);
        showToast("Impossible de charger les données globales. Vérifiez les règles Firestore.");
        setProperties([]);
        setOrganizations([]);
      }
    } else {
      // Real Cloud Firestore session pour une organisation classique
      setOrganizations([]);
      try {
        // Chaque collection est chargee separement : si l'une echoue, les autres s'affichent
        // quand meme et l'utilisateur est prevenu (plus de faux ecran vide silencieux).
        const labels = ['biens', 'locataires', 'baux', 'échéances', 'loyers', 'dépenses', 'réparations', 'abonnement'];
        const results = await Promise.allSettled([
          firestoreService.getProperties(orgId),
          firestoreService.getTenants(orgId),
          firestoreService.getLeases(orgId),
          firestoreService.getRentDues(orgId),
          firestoreService.getRentPayments(orgId),
          firestoreService.getExpenses(orgId),
          firestoreService.getRepairs(orgId),
          firestoreService.getSubscription(orgId)
        ]);
        const pick = (i: number): any => (results[i].status === 'fulfilled' ? (results[i] as PromiseFulfilledResult<any>).value : null);
        const failed = labels.filter((_, i) => results[i].status === 'rejected');
        if (failed.length > 0) {
          results.forEach((r, i) => { if (r.status === 'rejected') console.error(`Chargement impossible (${labels[i]}):`, r.reason); });
          showToast(`Chargement incomplet : ${failed.join(', ')}. Vérifiez votre connexion puis rouvrez l'application.`);
        }

        setProperties(pick(0) ?? []);
        setTenants(pick(1) ?? []);
        setLeases(pick(2) ?? []);
        setRentDues(pick(3) ?? []);
        setPayments(pick(4) ?? []);
        setExpenses(pick(5) ?? []);
        setRepairs(pick(6) ?? []);

        const cloudSub = pick(7);
        if (results[7].status === 'rejected') {
          setSubscription(storage.getSubscription(orgId));
        } else if (cloudSub) {
          setSubscription(cloudSub);
        } else {
          // Aucun abonnement enregistre : creation de l'essai gratuit de 14 jours pour cette organisation
          const defaultSub = storage.getSubscription(orgId);
          await firestoreService.saveSubscription(defaultSub);
          setSubscription(defaultSub);
        }

        setPaymentRequests(await firestoreService.getPaymentRequests(orgId));
        setNotifications(await firestoreService.getNotifications(orgId));
        setAuditLogs(await firestoreService.getAuditLogs(orgId));

        // Migration automatique si des paiements n'ont pas encore de dueId
        const cloudPayments = pick(4) ?? [];
        if (cloudPayments.some((p: RentPayment) => !p.dueId)) {
          try {
            await firestoreService.migrateOrgRentPaymentsToDues(orgId);
            const [freshDues, freshPays] = await Promise.all([
              firestoreService.getRentDues(orgId),
              firestoreService.getRentPayments(orgId)
            ]);
            setRentDues(freshDues);
            setPayments(freshPays);
          } catch (migErr) {
            console.warn('Migration Firestore partielle:', migErr);
          }
        }
      } catch (err) {
        console.warn('Chargement Firestore avec fallback local:', err);
        setProperties(storage.getProperties(orgId));
        setTenants(storage.getTenants(orgId));
        setLeases(storage.getLeases(orgId));
        setRentDues(storage.getRentDues(orgId));
        setPayments(storage.getRentPayments(orgId));
        setSubscription(storage.getSubscription(orgId));
      }
    }
    setConfig(storage.getConfig());
    setPlans(storage.getPlans());
  };

  // Expiration check (Read-Only Mode)
  const isExpired = subscription.status === 'expired' || 
    (subscription.status === 'trial' && new Date(subscription.trialEndsAt).getTime() < Date.now());

  const checkReadOnlyOrExecute = (action: () => Promise<void> | void) => {
    if (isExpired && currentUser?.role !== 'super_admin') {
      showToast("⚠️ Compte expiré : votre espace est en mode lecture seule. Veuillez renouveler votre formule pour modifier vos données.");
      return;
    }
    try {
      const result = action();
      if (result && typeof (result as Promise<void>).then === 'function') {
        (result as Promise<void>).catch(err => {
          console.error('Erreur pendant une opération:', err);
          showToast(`Opération impossible : ${err instanceof Error ? err.message : 'erreur inconnue'}`);
        });
      }
    } catch (err) {
      console.error('Erreur pendant une opération:', err);
      showToast(`Opération impossible : ${err instanceof Error ? err.message : 'erreur inconnue'}`);
    }
  };

  const handleCreateOrganization = async (organizationName: string, organizationType: 'individual' | 'agency') => {
    try {
      await firestoreService.createOrganization(organizationName, organizationType);
      if (currentUser) await loadDataForOrganization(currentUser.organizationId, isDemo, currentUser.role);
      showToast('Organisation créée avec succès.');
    } catch (err) {
      console.error('Erreur création organisation:', err);
      showToast(`Création impossible : ${err instanceof Error ? err.message : 'erreur inconnue'}`);
      throw err;
    }
  };

  const handleRenameOrganization = async (organizationId: string, organizationName: string) => {
    try {
      await firestoreService.updateOrganizationName(organizationId, organizationName);
      if (currentUser) await loadDataForOrganization(currentUser.organizationId, isDemo, currentUser.role);
      showToast('Nom de l’organisation mis à jour.');
    } catch (err) {
      showToast(`Modification impossible : ${err instanceof Error ? err.message : 'erreur inconnue'}`);
    }
  };

  const handleToggleOrganizationSuspension = async (organizationId: string, suspended: boolean) => {
    try {
      await firestoreService.setOrganizationSuspended(organizationId, suspended);
      if (currentUser) await loadDataForOrganization(currentUser.organizationId, isDemo, currentUser.role);
      showToast(suspended ? 'Organisation suspendue.' : 'Organisation réactivée.');
    } catch (err) {
      showToast(`Opération impossible : ${err instanceof Error ? err.message : 'erreur inconnue'}`);
    }
  };

  const handleAssignUserToOrganization = async (userId: string, organizationId: string) => {
    try {
      await firestoreService.assignUserToOrganization(userId, organizationId);
      if (currentUser) await loadDataForOrganization(currentUser.organizationId, isDemo, currentUser.role);
      showToast('Responsable affecté à l’organisation. Il doit se reconnecter pour voir les données.');
    } catch (err) {
      showToast(`Opération impossible : ${err instanceof Error ? err.message : 'erreur inconnue'}`);
    }
  };

  const currentPlan = plans.find(p => p.id === subscription.planId) || plans[1];

  // Handlers for Properties
  // Handlers for Properties
  const handleSaveProperty = async (prop: Property) => {
    if (isExpired && currentUser?.role !== 'super_admin') {
      showToast("⚠️ Compte expiré : votre espace est en mode lecture seule.");
      throw new Error("Compte expiré : votre espace est en mode lecture seule.");
    }
    try {
      if (!isDemo) {
        // Firestore d'abord : ne pas annoncer ni mettre en cache une sauvegarde refusée.
        await firestoreService.saveProperty(prop);
      }
      storage.saveProperty(prop);
      if (currentUser) {
        await loadDataForOrganization(currentUser.organizationId, isDemo, currentUser.role);
      }
      showToast(`Bien « ${prop.title} » sauvegardé.`);
    } catch (err) {
      console.error('Échec de sauvegarde du bien:', err);
      const message = err instanceof Error ? err.message : "Erreur inconnue";
      showToast(`Échec de l'enregistrement : ${message}`);
      throw err;
    }
  };

  const handleDeleteProperty = async (id: string) => {
    const propertyToDelete = properties.find(p => p.id === id);
    if (!propertyToDelete) {
      showToast("Bien introuvable dans la liste actuelle.");
      return;
    }
    if (isExpired && currentUser?.role !== 'super_admin') {
      showToast("⚠️ Compte expiré : votre espace est en mode lecture seule.");
      return;
    }
    try {
      if (!isDemo) await firestoreService.deleteProperty(id);
      storage.deleteProperty(propertyToDelete.organizationId, id);
      if (currentUser) {
        await loadDataForOrganization(currentUser.organizationId, isDemo, currentUser.role);
      }
      showToast('Bien supprimé du parc immobilier.');
    } catch (err) {
      console.error('Échec de suppression du bien:', err);
      showToast(`Échec de suppression : ${err instanceof Error ? err.message : 'erreur inconnue'}`);
    }
  };

  // Handlers for Tenants
  const handleSaveTenant = async (t: Tenant) => {
    checkReadOnlyOrExecute(async () => {
      storage.saveTenant(t);
      if (!isDemo) {
        await firestoreService.saveTenant(t);
      }
      if (currentUser) loadDataForOrganization(currentUser.organizationId, isDemo);
      showToast(`Locataire « ${t.fullName} » enregistré.`);
    });
  };

  const handleDeleteTenant = async (id: string) => {
    checkReadOnlyOrExecute(async () => {
      if (currentUser) {
        storage.deleteTenant(currentUser.organizationId, id);
        if (!isDemo) {
          await firestoreService.deleteTenant(id);
        }
        loadDataForOrganization(currentUser.organizationId, isDemo);
        showToast('Dossier locataire retiré.');
      }
    });
  };

  // Handlers for Leases
  const handleSaveLease = async (lease: Lease) => {
    checkReadOnlyOrExecute(async () => {
      storage.saveLease(lease);
      if (!isDemo) {
        await firestoreService.saveLease(lease);
      }
      if (currentUser) loadDataForOrganization(currentUser.organizationId, isDemo);
      showToast(`Contrat de bail ${lease.leaseNumber} généré.`);
    });
  };

  // Handlers for Rents & Payments (échéances + versements)
  const handleSavePayment = async (payment: RentPayment, due?: RentDue) => {
    checkReadOnlyOrExecute(async () => {
      // Si une échéance est fournie (création ou mise à jour), la sauvegarder d'abord
      if (due) {
        storage.saveRentDue(due);
        if (!isDemo) {
          await firestoreService.saveRentDue(due);
        }
        // S'assurer que le versement pointe bien vers cette échéance
        payment = { ...payment, dueId: due.id };
      }

      // Validation montant
      if ((payment.amountPaid || 0) <= 0 && payment.status !== 'annule') {
        showToast('Le montant du versement doit être strictement positif.');
        return;
      }

      storage.saveRentPayment(payment);
      if (!isDemo) {
        await firestoreService.saveRentPayment(payment);
      }
      if (currentUser) await loadDataForOrganization(currentUser.organizationId, isDemo);
      showToast(`Quittance ${payment.receiptNumber} enregistrée avec succès.`);
      if (payment.status === 'paye' || payment.status === 'partiel' || payment.status === 'valide') {
        setActiveReceiptPayment(payment);
      }
    });
  };

  const handleCancelPayment = async (paymentId: string, reason: string) => {
    checkReadOnlyOrExecute(async () => {
      const cancelled = storage.cancelRentPayment(paymentId, reason, currentUser?.fullName);
      if (cancelled && !isDemo) {
        await firestoreService.saveRentPayment(cancelled);
      }
      if (currentUser) await loadDataForOrganization(currentUser.organizationId, isDemo);
      showToast('Versement annulé. Le solde a été recalculé.');
    });
  };

  // Handlers for Expenses
  const handleSaveExpense = async (expense: Expense) => {
    checkReadOnlyOrExecute(async () => {
      storage.saveExpense(expense);
      if (!isDemo) {
        await firestoreService.saveExpense(expense);
      }
      if (currentUser) loadDataForOrganization(currentUser.organizationId, isDemo);
      showToast(`Dépense de ${expense.amount.toLocaleString('fr-FR')} FCFA enregistrée.`);
    });
  };

  const handleDeleteExpense = async (id: string) => {
    checkReadOnlyOrExecute(async () => {
      if (currentUser) {
        storage.deleteExpense(currentUser.organizationId, id);
        if (!isDemo) {
          await firestoreService.deleteExpense(id);
        }
        loadDataForOrganization(currentUser.organizationId, isDemo);
        showToast('Dépense supprimée.');
      }
    });
  };

  // Handlers for Repairs
  const handleSaveRepair = async (repair: RepairTicket) => {
    checkReadOnlyOrExecute(async () => {
      storage.saveRepair(repair);
      if (!isDemo) {
        await firestoreService.saveRepair(repair);
      }
      if (currentUser) loadDataForOrganization(currentUser.organizationId, isDemo);
      showToast(`Ticket d'intervention « ${repair.title} » enregistré.`);
    });
  };

  const handleResolveRepair = async (repair: RepairTicket) => {
    checkReadOnlyOrExecute(async () => {
      const updated: RepairTicket = {
        ...repair,
        status: 'resolu',
        resolvedAt: new Date().toISOString()
      };
      storage.saveRepair(updated);
      if (!isDemo) {
        await firestoreService.saveRepair(updated);
      }
      if (currentUser) loadDataForOrganization(currentUser.organizationId, isDemo);
      showToast(`Intervention sur ${repair.propertyTitle} marquée comme résolue.`);
    });
  };

  // Handlers for Agency Members
  const handleInviteMember = async (memberData: Omit<AgencyMember, 'id' | 'joinedAt'>) => {
    checkReadOnlyOrExecute(async () => {
      const newMember: AgencyMember = {
        ...memberData,
        id: `agent_${Date.now()}`,
        joinedAt: new Date().toISOString().split('T')[0]
      };
      storage.saveAgencyMember(newMember);
      if (!isDemo) {
        await firestoreService.saveAgencyMember(newMember);
      }
      if (currentUser) loadDataForOrganization(currentUser.organizationId, isDemo);
      showToast(`Invitation transmise à ${newMember.fullName}.`);
    });
  };

  const handleUpdateMemberStatus = async (id: string, status: 'actif' | 'suspendu') => {
    checkReadOnlyOrExecute(async () => {
      const m = agencyMembers.find(mem => mem.id === id);
      if (m) {
        const updated = { ...m, status };
        storage.saveAgencyMember(updated);
        if (!isDemo) {
          await firestoreService.saveAgencyMember(updated);
        }
        if (currentUser) loadDataForOrganization(currentUser.organizationId, isDemo);
        showToast(`Statut de l'agent mis à jour.`);
      }
    });
  };

  // Handlers for Subscriptions & Payments
  const handleSubmitSubscriptionPayment = async (req: SubscriptionPaymentRequest) => {
    storage.createPaymentRequest(req);
    if (!isDemo) {
      await firestoreService.savePaymentRequest(req);
    }
    if (currentUser) loadDataForOrganization(currentUser.organizationId, isDemo);
    showToast('Demande de règlement transmise à DARIMMO.');
  };

  // Super Admin actions
  const handleReviewPayment = async (requestId: string, status: 'approved' | 'rejected', notes: string) => {
    storage.reviewPaymentRequest(
      requestId, 
      status, 
      notes, 
      currentUser?.email || 'super_admin'
    );
    if (!isDemo) {
      const req = paymentRequests.find(r => r.id === requestId);
      if (req) {
        const updatedReq: SubscriptionPaymentRequest = {
          ...req,
          status,
          adminNotes: notes,
          reviewedBy: currentUser?.email || 'super_admin',
          reviewedAt: new Date().toISOString()
        };
        await firestoreService.savePaymentRequest(updatedReq);

        if (status === 'approved') {
          const daysToAdd = req.billingCycle === 'annual' ? 365 : 30;
          const currentExp = new Date();
          currentExp.setDate(currentExp.getDate() + daysToAdd);
          
          const newSub: SubscriptionState = {
            organizationId: req.organizationId,
            planId: req.planId,
            status: 'active',
            trialStartsAt: new Date().toISOString(),
            trialEndsAt: new Date().toISOString(),
            currentPeriodStart: new Date().toISOString(),
            currentPeriodEnd: currentExp.toISOString(),
            billingCycle: req.billingCycle,
            expiresAt: currentExp.toISOString(),
            maxProperties: req.planId === 'essentiel' ? 5 : req.planId === 'pro' ? 30 : -1,
            maxTenants: req.planId === 'essentiel' ? 10 : -1,
            maxAgents: req.planId === 'essentiel' ? 1 : req.planId === 'pro' ? 3 : 15,
            autoRenew: false
          };
          await firestoreService.saveSubscription(newSub);
        }
      }
    }
    if (currentUser) loadDataForOrganization(currentUser.organizationId, isDemo);
    showToast(status === 'approved' ? 'Paiement validé et formule activée !' : 'Paiement rejeté.');
  };

  const handleUpdatePlans = (newPlans: PlanConfig[]) => {
    storage.savePlans(newPlans);
    setPlans(newPlans);
    showToast('Grille tarifaire mise à jour avec succès.');
  };

  const handleUpdateConfig = async (newCfg: AppConfig) => {
    storage.saveConfig(newCfg);
    setConfig(newCfg);
    try {
      await firestoreService.updateMaintenanceConfig({
        maintenanceMode: newCfg.maintenanceMode,
        maintenanceMessage: newCfg.maintenanceMessage,
        maintenanceExpectedEnd: newCfg.maintenanceExpectedEnd
      });
    } catch (err) {
      console.warn('Erreur synchronisation Firestore maintenance:', err);
    }
    showToast(newCfg.maintenanceMode ? 'Mode Maintenance ACTIVÉ en direct sur Firestore.' : 'Mode Maintenance DÉSACTIVÉ : plateforme en ligne.');
  };

  const handleDisableMaintenanceQuick = async () => {
    const updatedCfg: AppConfig = {
      ...config,
      maintenanceMode: false
    };
    storage.saveConfig(updatedCfg);
    setConfig(updatedCfg);
    try {
      await firestoreService.updateMaintenanceConfig({
        maintenanceMode: false,
        maintenanceMessage: config.maintenanceMessage,
        maintenanceExpectedEnd: config.maintenanceExpectedEnd
      });
    } catch (err) {
      console.warn('Erreur désactivation rapide maintenance:', err);
    }
    showToast('Mode Maintenance DÉSACTIVÉ : accès public immédiatement rétabli.');
  };

  const handleExportBackup = () => {
    const dataStr = storage.exportFullDatabase();
    const blob = new Blob([dataStr], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `DARIMMO_SAUVEGARDE_${new Date().toISOString().slice(0, 10)}.json`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    showToast('Sauvegarde complète exportée en JSON.');
  };

  const handleImportBackup = (jsonContent: string) => {
    const res = storage.importDatabase(jsonContent);
    if (res.success) {
      if (currentUser) loadDataForOrganization(currentUser.organizationId, isDemo);
      showToast('Restauration des données réussie sans perte.');
    } else {
      showToast(`Erreur : ${res.message}`);
    }
  };

  const handleResetFactory = () => {
    storage.resetToFactoryDefaults();
    if (currentUser) loadDataForOrganization(currentUser.organizationId, isDemo);
    showToast('Données initiales rechargées.');
  };

  // Notifications
  const handleMarkNotificationRead = (id: string) => {
    storage.markNotificationAsRead(id);
    if (currentUser) setNotifications(storage.getNotifications(currentUser.organizationId));
  };

  const handleMarkAllNotificationsRead = () => {
    if (currentUser) {
      storage.markAllNotificationsAsRead(currentUser.organizationId);
      setNotifications(storage.getNotifications(currentUser.organizationId));
    }
  };

  // Check Simulated Error (Section 14 - Dev testing)
  if (simulatedError) {
    return (
      <div className="min-h-screen bg-slate-50 flex flex-col justify-center items-center">
        <ErrorView
          code={simulatedError.code}
          message={simulatedError.message}
          onGoHome={() => setSimulatedError(null)}
          onRetry={() => {
            showToast('Rétablissement de la session normale.');
            setSimulatedError(null);
          }}
        />
      </div>
    );
  }

  // Check Maintenance Mode (Locked for visitors and non-super-admins)
  if (config.maintenanceMode && currentUser?.role !== 'super_admin') {
    return (
      <>
        {showSplash && <SplashScreen onFinished={() => setShowSplash(false)} />}
        <MaintenancePage
          message={config.maintenanceMessage}
          expectedEnd={config.maintenanceExpectedEnd}
          onAdminLogin={() => {
            setAuthInitialMode('login');
            setAuthModalOpen(true);
          }}
        />
        <AuthModal
          isOpen={authModalOpen}
          initialMode={authInitialMode}
          onClose={() => setAuthModalOpen(false)}
          onStartDemo={() => {
            auth.startDemoMode('super_admin');
          }}
          onSuccess={() => {
            const user = auth.getCurrentUser();
            const demoState = auth.isDemoMode();
            setCurrentUser(user);
            setIsDemo(demoState);
            if (user) loadDataForOrganization(user.organizationId, demoState, user.role);
          }}
        />
      </>
    );
  }

  // If user is not logged in, render Public Landing Page
  if (!currentUser) {
    return (
      <>
        {showSplash && <SplashScreen onFinished={() => setShowSplash(false)} />}
        <LandingPage
          plans={plans}
          onOpenLogin={() => {
            setAuthInitialMode('login');
            setAuthModalOpen(true);
          }}
          onOpenSignup={() => {
            setAuthInitialMode('signup');
            setAuthModalOpen(true);
          }}
          onStartTrial={() => {
            setAuthInitialMode('signup');
            setAuthModalOpen(true);
          }}
          onStartDemo={() => {
            auth.startDemoMode('owner');
          }}
        />
        <AuthModal
          isOpen={authModalOpen}
          initialMode={authInitialMode}
          onClose={() => setAuthModalOpen(false)}
          onStartDemo={() => {
            auth.startDemoMode('owner');
          }}
          onSuccess={() => {
            const user = auth.getCurrentUser();
            const demoState = auth.isDemoMode();
            setCurrentUser(user);
            setIsDemo(demoState);
            if (user) loadDataForOrganization(user.organizationId, demoState, user.role);
          }}
        />
      </>
    );
  }

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col font-sans text-slate-800 antialiased selection:bg-emerald-100 selection:text-emerald-900">
      {/* Luxurious Initial Splash Screen */}
      {showSplash && <SplashScreen onFinished={() => setShowSplash(false)} />}

      {/* Super Admin Maintenance Warning Sticky Banner */}
      {config.maintenanceMode && currentUser.role === 'super_admin' && (
        <div className="bg-gradient-to-r from-rose-900 via-rose-800 to-slate-900 text-white px-4 py-2.5 text-xs font-semibold flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 border-b border-rose-600/50 shadow-md sticky top-0 z-50">
          <div className="flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded-full bg-rose-400 animate-ping shrink-0" />
            <span>
              <strong>ATTENTION : Mode Maintenance ACTIF pour les utilisateurs et visiteurs</strong> · L'accès public est actuellement bloqué sur Firestore. Vous naviguez avec les privilèges Super Admin.
            </span>
          </div>
          <button
            type="button"
            onClick={handleDisableMaintenanceQuick}
            className="px-3 py-1 bg-white hover:bg-rose-50 text-rose-800 rounded-lg text-xs font-bold cursor-pointer transition-colors shadow-xs shrink-0 self-end sm:self-auto"
          >
            Désactiver la maintenance (Rétablir l'accès)
          </button>
        </div>
      )}

      {/* Toast Notification */}
      {toastMessage && (
        <div className="fixed bottom-6 right-6 z-50 bg-slate-900 text-white text-xs font-semibold px-4 py-3 rounded-xl shadow-xl border border-slate-700 animate-in fade-in slide-in-from-bottom-3 flex items-center gap-2">
          <span className="w-2 h-2 rounded-full bg-emerald-400" />
          <span>{toastMessage}</span>
        </div>
      )}

      {/* Amber Banner when in Isolated Demo Sandbox */}
      {isDemo && (
        <div className="bg-amber-500 text-amber-950 px-4 py-2 text-xs font-semibold flex flex-col sm:flex-row items-start sm:items-center justify-between gap-2 border-b border-amber-600/30">
          <div className="flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded-full bg-amber-900 animate-pulse shrink-0" />
            <span>
              <strong>Mode Démonstration Bac à Sable :</strong> Vous visualisez des données fictives de Niamey. Les modifications ne sont pas envoyées à Firebase.
            </span>
          </div>
          <div className="flex items-center gap-2 shrink-0">
            <button
              type="button"
              onClick={() => {
                auth.exitDemoMode();
                setAuthInitialMode('signup');
                setAuthModalOpen(true);
              }}
              className="px-2.5 py-1 bg-amber-950 hover:bg-slate-900 text-white rounded-md text-[11px] font-bold cursor-pointer transition-colors"
            >
              Créer mon vrai compte Firebase
            </button>
            <button
              type="button"
              onClick={() => auth.exitDemoMode()}
              className="px-2.5 py-1 bg-amber-100/90 hover:bg-amber-200 text-amber-900 rounded-md text-[11px] font-semibold cursor-pointer transition-colors"
            >
              Quitter la démo
            </button>
          </div>
        </div>
      )}

      {/* Red Read-Only Banner when Subscription is Expired */}
      {isExpired && !isDemo && (
        <div className="bg-rose-600 text-white px-4 py-2.5 text-xs font-semibold flex flex-col sm:flex-row items-start sm:items-center justify-between gap-2 border-b border-rose-700">
          <div className="flex items-center gap-2">
            <ShieldAlert className="w-4 h-4 shrink-0 text-white" />
            <span>
              <strong>Accès en Lecture Seule :</strong> Votre période d'essai ou formule a expiré. Les créations de biens, locataires et quittances sont suspendues.
            </span>
          </div>
          <button
            type="button"
            onClick={() => setCurrentView('subscription')}
            className="px-3 py-1 bg-white hover:bg-rose-50 text-rose-700 rounded-md text-[11px] font-bold cursor-pointer shrink-0 transition-colors"
          >
            Renouveler mon abonnement
          </button>
        </div>
      )}

      {/* Main Top Header */}
      <Header
        user={currentUser}
        subscription={subscription}
        notifications={notifications}
        isDemo={isDemo}
        onOpenMobileMenu={() => setIsMobileMenuOpen(true)}
        onSwitchDemoRole={(r) => {
          auth.switchDemoRole(r);
          setCurrentView('dashboard');
        }}
        onExitDemo={() => auth.exitDemoMode()}
        onLogout={() => auth.logout()}
        onMarkNotificationRead={handleMarkNotificationRead}
        onMarkAllNotificationsRead={handleMarkAllNotificationsRead}
        onNavigate={setCurrentView}
        currentView={currentView}
      />

      <div className="flex-1 flex overflow-hidden">
        {/* Sidebar */}
        <Sidebar
          currentView={currentView}
          onNavigate={setCurrentView}
          user={currentUser}
          subscription={subscription}
          isOpen={isMobileMenuOpen}
          onClose={() => setIsMobileMenuOpen(false)}
        />

        {/* Content Viewport */}
        <main className="flex-1 overflow-y-auto px-4 sm:px-8 py-6">
          {/* Tenant Portal Specific Screen */}
          {currentUser.role === 'tenant' ? (
            <TenantPortalView
              tenant={tenants[0] || {
                id: 'ten_default',
                organizationId: currentUser.organizationId,
                fullName: currentUser.fullName,
                email: currentUser.email,
                phone: currentUser.phone,
                idCardNumber: 'CNI-NER-2022-849102',
                profession: 'Ingénieur',
                emergencyContact: '+227 96 00 00 00',
                propertyId: properties[0]?.id || 'prop_1',
                propertyTitle: properties[0]?.title || 'Villa Moderne',
                leaseStartDate: '2025-06-01',
                entryDate: '2025-06-01',
                monthlyRent: properties[0]?.monthlyRent || 650000,
                depositAmount: (properties[0]?.monthlyRent || 650000) * 2,
                status: 'actif',
                createdAt: '2025-06-01'
              }}
              property={properties[0] || null}
              lease={leases[0] || null}
              payments={payments}
              repairs={repairs}
              onViewReceipt={(p) => setActiveReceiptPayment(p)}
              onOpenReportRepair={() => {
                setEditingRepair(null);
                setRepairModalOpen(true);
              }}
            />
          ) : (
            <>
              {/* Dashboard View */}
              {currentView === 'dashboard' && (
                <DashboardOverview
                  properties={properties}
                  tenants={tenants}
                  payments={payments}
                  expenses={expenses}
                  repairs={repairs}
                  subscription={subscription}
                  onNavigate={setCurrentView}
                  onOpenAddProperty={() => {
                    setEditingProperty(null);
                    setPropertyModalOpen(true);
                  }}
                  onOpenAddTenant={() => {
                    setEditingTenant(null);
                    setTenantModalOpen(true);
                  }}
                  onOpenCollectRent={() => {
                    setEditingPayment(null);
                    setRentModalOpen(true);
                  }}
                  onOpenAddExpense={() => {
                    setEditingExpense(null);
                    setExpenseModalOpen(true);
                  }}
                  onOpenAddRepair={() => {
                    setEditingRepair(null);
                    setRepairModalOpen(true);
                  }}
                  onViewReceipt={(p) => setActiveReceiptPayment(p)}
                />
              )}

              {/* Properties List View */}
              {currentView === 'properties' && (
                <PropertiesList
                  properties={properties}
                  currentPlan={currentPlan}
                  onAddProperty={() => {
                    setEditingProperty(null);
                    setPropertyModalOpen(true);
                  }}
                  onEditProperty={(p) => {
                    setEditingProperty(p);
                    setPropertyModalOpen(true);
                  }}
                  onDeleteProperty={handleDeleteProperty}
                  onViewProperty={(p) => setActiveDetailProperty(p)}
                  onUpgradePlan={() => setCurrentView('subscription')}
                />
              )}

              {/* Tenants List View */}
              {currentView === 'tenants' && (
                <TenantsList
                  tenants={tenants}
                  onAddTenant={() => {
                    setEditingTenant(null);
                    setTenantModalOpen(true);
                  }}
                  onEditTenant={(t) => {
                    setEditingTenant(t);
                    setTenantModalOpen(true);
                  }}
                  onDeleteTenant={handleDeleteTenant}
                />
              )}

              {/* Leases List View */}
              {currentView === 'leases' && (
                <LeasesList
                  leases={leases}
                  onAddLease={() => {
                    setEditingLease(null);
                    setLeaseModalOpen(true);
                  }}
                  onEditLease={(l) => {
                    setEditingLease(l);
                    setLeaseModalOpen(true);
                  }}
                  onViewLeaseDocument={(l) => setActiveLeaseDocument(l)}
                />
              )}

              {/* Rents & Receipts Ledger View */}
              {currentView === 'rents' && (
                <RentsList
                  payments={payments}
                  onAddPayment={() => {
                    setEditingPayment(null);
                    setSelectedRentDue(null);
                    setRentModalOpen(true);
                  }}
                  onAddInstallment={(p) => {
                    const existing = rentDues.find(d => d.id === p.dueId)
                      || rentDues.find(d => d.tenantId === p.tenantId && d.periodMonth === p.periodMonth);
                    const due: RentDue = existing || {
                      id: p.dueId || `due_${p.tenantId}_${p.periodMonth.replace(/\s+/g, '_')}`,
                      organizationId: p.organizationId,
                      tenantId: p.tenantId,
                      tenantName: p.tenantName,
                      propertyId: p.propertyId,
                      propertyTitle: p.propertyTitle,
                      periodMonth: p.periodMonth,
                      dueDate: p.dueDate,
                      amountExpected: p.amountExpected || tenants.find(t => t.id === p.tenantId)?.monthlyRent || 0,
                      status: 'partiel',
                      createdAt: p.createdAt,
                      updatedAt: new Date().toISOString()
                    };
                    setEditingPayment(null);
                    setSelectedRentDue(due);
                    setRentModalOpen(true);
                  }}
                  onViewReceipt={(p) => setActiveReceiptPayment(p)}
                  onSendReminder={(p) => setActiveReminderPayment(p)}
                />
              )}

              {/* Expenses List View */}
              {currentView === 'expenses' && (
                <ExpensesList
                  expenses={expenses}
                  onAddExpense={() => {
                    setEditingExpense(null);
                    setExpenseModalOpen(true);
                  }}
                  onEditExpense={(e) => {
                    setEditingExpense(e);
                    setExpenseModalOpen(true);
                  }}
                  onDeleteExpense={handleDeleteExpense}
                />
              )}

              {/* Repairs List View */}
              {currentView === 'repairs' && (
                <RepairsList
                  repairs={repairs}
                  onAddRepair={() => {
                    setEditingRepair(null);
                    setRepairModalOpen(true);
                  }}
                  onEditRepair={(r) => {
                    setEditingRepair(r);
                    setRepairModalOpen(true);
                  }}
                  onResolveRepair={handleResolveRepair}
                />
              )}

              {/* Reports & Analytics View */}
              {currentView === 'reports' && (
                <ReportsView
                  properties={properties}
                  tenants={tenants}
                  payments={payments}
                  expenses={expenses}
                  organizationName={currentUser.organizationName}
                />
              )}

              {/* Agency View */}
              {currentView === 'agency' && (
                <AgencyTeamView
                  members={agencyMembers}
                  properties={properties}
                  onInviteMember={handleInviteMember}
                  onUpdateStatus={handleUpdateMemberStatus}
                />
              )}

              {/* Subscription & Local Payments View */}
              {currentView === 'subscription' && (
                <SubscriptionView
                  subscription={subscription}
                  plans={plans}
                  config={config}
                  userEmail={currentUser.email}
                  userPhone={currentUser.phone}
                  organizationName={currentUser.organizationName}
                  organizationId={currentUser.organizationId}
                  paymentRequests={paymentRequests.filter(r => r.organizationId === currentUser.organizationId)}
                  onSubmitPayment={handleSubmitSubscriptionPayment}
                />
              )}

              {/* Super Admin Console */}
              {(currentView === 'admin' || currentView === 'admin_pricing') && (
                <SuperAdminView
                  paymentRequests={paymentRequests}
                  plans={plans}
                  config={config}
                  auditLogs={auditLogs}
                  properties={properties}
                  organizations={organizations}
                  users={allUsers}
                  onAssignUser={handleAssignUserToOrganization}
                  onCreatePropertyForOrganization={(organizationId) => {
                    setEditingProperty(null);
                    setPropertyModalOpen(true);
                    setAdminTargetOrganizationId(organizationId);
                  }}
                  onCreateOrganization={handleCreateOrganization}
                  onEditGlobalProperty={(property) => {
                    setEditingProperty(property);
                    setPropertyModalOpen(true);
                    setAdminTargetOrganizationId(property.organizationId);
                  }}
                  onDeleteGlobalProperty={handleDeleteProperty}
                  onRenameOrganization={handleRenameOrganization}
                  onToggleOrganizationSuspension={handleToggleOrganizationSuspension}
                  onReviewPayment={handleReviewPayment}
                  onUpdatePlans={handleUpdatePlans}
                  onUpdateConfig={handleUpdateConfig}
                  onExportBackup={handleExportBackup}
                  onImportBackup={handleImportBackup}
                  onResetFactory={handleResetFactory}
                />
              )}
            </>
          )}
        </main>
      </div>

      {/* Mobile Navigation Thumb Bar */}
      <MobileNav
        currentView={currentView}
        onNavigate={setCurrentView}
        onOpenMore={() => setIsMobileMenuOpen(true)}
      />

      {/* Official Quittance Print / PDF Modal */}
      <ReceiptModal
        payment={activeReceiptPayment}
        onClose={() => setActiveReceiptPayment(null)}
        landlordName={currentUser.organizationType === 'agency' ? currentUser.organizationName : currentUser.fullName}
        agencyName={currentUser.organizationName}
      />

      {/* Property Modal */}
      <PropertyModal
        isOpen={propertyModalOpen}
        property={editingProperty}
        onClose={() => {
          setPropertyModalOpen(false);
          setEditingProperty(null);
          setAdminTargetOrganizationId('');
        }}
        onSave={handleSaveProperty}
        organizationId={currentUser.role === 'super_admin' && adminTargetOrganizationId ? adminTargetOrganizationId : currentUser.organizationId}
        isSuperAdmin={currentUser.role === 'super_admin'}
        organizations={organizations}
      />

      {/* Tenant Modal */}
      <TenantModal
        isOpen={tenantModalOpen}
        tenant={editingTenant}
        properties={properties}
        onClose={() => {
          setTenantModalOpen(false);
          setEditingTenant(null);
        }}
        onSave={handleSaveTenant}
        organizationId={currentUser.organizationId}
      />

      {/* Lease Modal */}
      <LeaseModal
        isOpen={leaseModalOpen}
        lease={editingLease}
        properties={properties}
        tenants={tenants}
        onClose={() => {
          setLeaseModalOpen(false);
          setEditingLease(null);
        }}
        onSave={handleSaveLease}
        organizationId={currentUser.organizationId}
      />

      {/* Rent Payment Modal */}
      <RentPaymentModal
        isOpen={rentModalOpen}
        payment={editingPayment}
        tenants={tenants}
        onClose={() => {
          setRentModalOpen(false);
          setEditingPayment(null);
          setSelectedRentDue(null);
        }}
        existingDue={selectedRentDue}
        onSave={handleSavePayment}
        organizationId={currentUser.organizationId}
        generateReceiptNumber={(orgId, period) => storage.generateReceiptNumber(orgId, period)}
        rentDues={rentDues}
        payments={payments}
      />

      {/* Expense Modal */}
      <ExpenseModal
        isOpen={expenseModalOpen}
        expense={editingExpense}
        properties={properties}
        onClose={() => {
          setExpenseModalOpen(false);
          setEditingExpense(null);
        }}
        onSave={handleSaveExpense}
        organizationId={currentUser.organizationId}
      />

      {/* Repair Modal */}
      <RepairModal
        isOpen={repairModalOpen}
        repair={editingRepair}
        properties={properties}
        onClose={() => {
          setRepairModalOpen(false);
          setEditingRepair(null);
        }}
        onSave={handleSaveRepair}
        organizationId={currentUser.organizationId}
      />

      {/* Official OHADA Lease Agreement Modal */}
      <LeaseDocumentModal
        lease={activeLeaseDocument}
        property={properties.find(p => p.id === activeLeaseDocument?.propertyId) || null}
        tenant={tenants.find(t => t.id === activeLeaseDocument?.tenantId) || null}
        landlordName={currentUser.organizationType === 'agency' ? currentUser.organizationName : currentUser.fullName}
        agencyName={currentUser.organizationName}
        onClose={() => setActiveLeaseDocument(null)}
      />

      {/* Property Detail Modal */}
      <PropertyDetailModal
        property={activeDetailProperty}
        tenants={tenants}
        leases={leases}
        payments={payments}
        repairs={repairs}
        onClose={() => setActiveDetailProperty(null)}
        onEdit={(p) => {
          setActiveDetailProperty(null);
          setEditingProperty(p);
          setPropertyModalOpen(true);
        }}
        onViewReceipt={(pay) => {
          setActiveDetailProperty(null);
          setActiveReceiptPayment(pay);
        }}
      />

      {/* WhatsApp & SMS Rent Reminder Modal */}
      <WhatsAppReminderModal
        payment={activeReminderPayment}
        tenant={tenants.find(t => t.id === activeReminderPayment?.tenantId) || null}
        landlordName={currentUser.organizationType === 'agency' ? currentUser.organizationName : currentUser.fullName}
        onClose={() => setActiveReminderPayment(null)}
        onLogReminder={(msg) => {
          showToast('Rappel de loyer consigné.');
          storage.logAction(currentUser.organizationId, 'RAPPEL_LOYER', msg);
        }}
      />

      {/* Discrete Dev QA & Error Simulator Trigger (Section 14) */}
      <div className="no-print fixed bottom-16 sm:bottom-4 right-4 z-30">
        <button
          type="button"
          onClick={() => setDevSimulatorOpen(true)}
          className="px-2.5 py-1.5 bg-slate-900/80 hover:bg-slate-900 text-slate-300 hover:text-white rounded-lg text-[10px] font-mono border border-slate-700 shadow-sm backdrop-blur-xs transition-colors cursor-pointer flex items-center gap-1.5"
          title="Ouvrir le banc de test et de simulation d'erreurs (404, 403, 500, réseau)"
        >
          <span>🧪 Tests QA</span>
        </button>
      </div>

      {/* Dev Error Simulator Modal (Section 14) */}
      <DevErrorSimulatorModal
        isOpen={devSimulatorOpen}
        onClose={() => setDevSimulatorOpen(false)}
        onTriggerError={(code, message) => setSimulatedError({ code, message })}
        onSimulateOffline={() => {
          showToast('Mode hors-ligne simulé (3G/4G instable).');
          setSimulatedError({ code: 500, message: 'Coupure réseau cellulaire détectée. Les données locales demeurent intègres.' });
        }}
        onSimulateSlowResponse={() => {
          showToast('Simulation de latence réseau activée (délai 2.5s)...');
        }}
      />
    </div>
  );
}
