/**
 * DARIMMO - Service de Persistance et Base de Données Multi-Tenant
 * Conforme aux règles d'isolation par organisation, migrations versionnées
 * et sauvegardes sans perte de données.
 */

import {
  Property,
  Tenant,
  Lease,
  RentPayment,
  RentDue,
  RentDueStatus,
  Expense,
  RepairTicket,
  AgencyMember,
  SubscriptionState,
  SubscriptionPaymentRequest,
  AppNotification,
  AuditLog,
  AppConfig,
  PlanConfig,
  PlanId
} from '../types';

const DB_VERSION_KEY = 'DARIMMO_DB_VERSION';
const DB_VERSION = '2.0.0'; // v2 : séparation RentDue / RentPayment (versements multiples)
const STORAGE_PREFIX = 'darimmo_db_v1_';

export const INITIAL_PLANS: PlanConfig[] = [
  {
    id: 'essentiel',
    name: 'Essentiel',
    tagline: 'Pour les petits propriétaires indépendants',
    monthlyPrice: 2500,
    annualPrice: 25000, // 2 mois offerts
    maxProperties: 5,
    maxTenants: 10,
    maxAgents: 1,
    features: [
      'Jusqu’à 5 biens immobiliers',
      'Jusqu’à 10 locataires',
      'Gestion des baux & contrats simples',
      'Enregistrement manuel des loyers',
      'Tableau de bord financier simplifié',
      'Historique des opérations',
      'Support par e-mail'
    ]
  },
  {
    id: 'pro',
    name: 'Pro',
    tagline: 'Pour les propriétaires avec plusieurs biens',
    monthlyPrice: 5000,
    annualPrice: 50000,
    maxProperties: 30,
    maxTenants: -1, // illimité
    maxAgents: 3,
    recommended: true,
    features: [
      'Jusqu’à 30 biens immobiliers',
      'Locataires illimités',
      'Toutes les fonctionnalités Essentiel',
      'Génération & Impression des Quittances de loyer PDF',
      'Gestion détaillée des dépenses & justificatifs',
      'Suivi des pannes & réparations',
      'Rappels automatiques d’échéances de loyer',
      'Rapports financiers & exports CSV',
      'Support prioritaire WhatsApp & Téléphone'
    ]
  },
  {
    id: 'business',
    name: 'Business',
    tagline: 'Pour les agences immobilières et cabinets de gestion',
    monthlyPrice: 12000,
    annualPrice: 120000,
    maxProperties: -1, // illimité
    maxTenants: -1,
    maxAgents: 15,
    features: [
      'Biens immobiliers illimités',
      'Gestion d’équipe (jusqu’à 15 agents & gestionnaires)',
      'Attribution de biens par agent',
      'Calcul & suivi des commissions d’agence',
      'Gestion multi-bailleurs / propriétaires mandants',
      'Journal d’audit et d’activité des agents',
      'Rapports financiers consolidés d’agence',
      'Personnalisation des quittances avec logo agence',
      'Accompagnement et formation de votre équipe'
    ]
  },
  {
    id: 'enterprise',
    name: 'Entreprise',
    tagline: 'Pour les promoteurs, foncières et grands réseaux',
    monthlyPrice: 35000,
    annualPrice: 350000,
    maxProperties: -1,
    maxTenants: -1,
    maxAgents: -1,
    features: [
      'Tout ce qui est inclus dans Business',
      'Gestion multi-agences / filiales',
      'Comptabilité OHADA approfondie',
      'Intégration API personnalisée',
      'Gestionnaire de compte dédié DARIMMO à Niamey',
      'SLA contractuel garanti 99.9%'
    ]
  }
];

export const INITIAL_CONFIG: AppConfig = {
  maintenanceMode: false,
  maintenanceMessage: 'DARIMMO est en cours de maintenance technique planifiée. Nos équipes optimisent actuellement la plateforme. Vos données sont parfaitement sécurisées.',
  maintenanceExpectedEnd: '2026-11-04 18:00 (Heure de Niamey)',
  paymentInstructions: {
    nita: {
      accountName: 'DARIMMO TECHNOLOGIES SARL',
      accountNumber: 'NITA-8842-NIGER',
      city: 'Niamey - Agence Principale Rond-point Maourey',
      phone: '+227 90 00 12 34'
    },
    amana: {
      accountName: 'DARIMMO TECH SERVICES',
      accountNumber: 'AMANA-7731-NIAMEY',
      city: 'Niamey - Agence Katako',
      phone: '+227 96 11 22 33'
    },
    airtelMoney: {
      merchantNumber: 'AIRTEL-MERCHANT-5049',
      merchantName: 'DARIMMO NIGER',
      ussdCode: '*436*1*5049# puis saisissez le montant'
    }
  },
  version: '1.2.0',
  lastDeployedAt: '2026-11-04'
};

// Seed Data for default organization 'org_owner_1' and 'org_agency_1'
function getSeedProperties(): Property[] {
  return [
    {
      id: 'prop_1',
      organizationId: 'org_owner_1',
      title: 'Villa Moderne avec Piscine & Jardin',
      type: 'Maison',
      address: 'Rue des Ambassades, Villa 24',
      neighborhood: 'Plateau',
      city: 'Niamey',
      rooms: 6,
      surface: 350,
      monthlyRent: 650000,
      charges: 50000,
      status: 'occupe',
      description: 'Superbe villa sécurisée de haut standing avec groupe électrogène, forage d’eau, gardiennage et finitions soignées.',
      imageUrl: '/src/assets/images/darimmo_hero_property_1793803599938.jpg',
      createdAt: '2026-01-15T10:00:00Z',
      updatedAt: '2026-03-01T14:30:00Z'
    },
    {
      id: 'prop_2',
      organizationId: 'org_owner_1',
      title: 'Appartement F4 Standing Résidence Sahel',
      type: 'Appartement',
      address: 'Boulevard Mali Béro, Imm. Sahel 3ème étage',
      neighborhood: 'Koubia',
      city: 'Niamey',
      rooms: 4,
      surface: 140,
      monthlyRent: 350000,
      charges: 25000,
      status: 'occupe',
      description: 'Appartement spacieux climatisé, cuisine équipée, balcon avec vue dégagée, ascenseur et place de parking couverte.',
      imageUrl: '/src/assets/images/darimmo_hero_property_1793803599938.jpg',
      createdAt: '2026-01-20T11:00:00Z',
      updatedAt: '2026-02-15T09:00:00Z'
    },
    {
      id: 'prop_3',
      organizationId: 'org_owner_1',
      title: 'Studio Meublé Tout Confort',
      type: 'Studio',
      address: 'Près de l’Université Abdou Moumouni',
      neighborhood: 'Yantala',
      city: 'Niamey',
      rooms: 2,
      surface: 45,
      monthlyRent: 150000,
      charges: 15000,
      status: 'disponible',
      description: 'Idéal pour cadre expatrié ou professionnel en mission. Meublé, Wifi, climatiseur et chauffe-eau.',
      imageUrl: '/src/assets/images/darimmo_hero_property_1793803599938.jpg',
      createdAt: '2026-02-01T08:00:00Z',
      updatedAt: '2026-03-02T16:00:00Z'
    },
    {
      id: 'prop_4',
      organizationId: 'org_owner_1',
      title: 'Local Commercial & Boutique Pignon sur Rue',
      type: 'Boutique',
      address: 'Avenue de l’Islam',
      neighborhood: 'Grand Marché',
      city: 'Niamey',
      rooms: 2,
      surface: 65,
      monthlyRent: 280000,
      charges: 10000,
      status: 'occupe',
      description: 'Emplacement stratégique à fort passage commercial, double rideau métallique, compteur prépayé Nigelec individuel.',
      imageUrl: '/src/assets/images/darimmo_hero_property_1793803599938.jpg',
      createdAt: '2026-02-10T12:00:00Z',
      updatedAt: '2026-02-10T12:00:00Z'
    },
    {
      id: 'prop_5',
      organizationId: 'org_owner_1',
      title: 'Immeuble R+2 de 6 Appartements',
      type: 'Immeuble',
      address: 'Zone Résidentielle',
      neighborhood: 'Harobanda',
      city: 'Niamey',
      rooms: 18,
      surface: 550,
      monthlyRent: 1200000,
      charges: 60000,
      status: 'maintenance',
      description: 'En cours de rafraîchissement peinture et révision générale de la plomberie avant remise en location.',
      imageUrl: '/src/assets/images/darimmo_hero_property_1793803599938.jpg',
      createdAt: '2026-01-05T09:00:00Z',
      updatedAt: '2026-03-03T11:00:00Z'
    }
  ];
}

function getSeedTenants(): Tenant[] {
  return [
    {
      id: 'ten_1',
      organizationId: 'org_owner_1',
      fullName: 'Ibrahim Moussa',
      email: 'ibrahim.moussa@niger-consult.ne',
      phone: '+227 90 25 44 88',
      idCardNumber: 'CNI-NER-2022-849102',
      profession: 'Ingénieur Télécoms chez Airtel Niger',
      emergencyContact: 'Aïssata Moussa (Épouse) : +227 96 44 11 22',
      propertyId: 'prop_1',
      propertyTitle: 'Villa Moderne avec Piscine & Jardin (Plateau)',
      leaseStartDate: '2025-06-01',
      entryDate: '2025-06-01',
      monthlyRent: 650000,
      depositAmount: 1300000, // 2 mois de caution
      status: 'actif',
      notes: 'Locataire exemplaire, paiement toujours avant le 5 du mois via virement.',
      createdAt: '2025-05-20T10:00:00Z'
    },
    {
      id: 'ten_2',
      organizationId: 'org_owner_1',
      fullName: 'Dr. Fatouma Abdoulaye',
      email: 'f.abdoulaye@oms-niger.org',
      phone: '+227 91 78 33 55',
      idCardNumber: 'PASSPORT-NER-P039482',
      profession: 'Médecin Coordinatrice Santé Publique',
      emergencyContact: 'Salifou Abdoulaye : +227 92 10 20 30',
      propertyId: 'prop_2',
      propertyTitle: 'Appartement F4 Standing Résidence Sahel (Koubia)',
      leaseStartDate: '2025-09-01',
      entryDate: '2025-09-01',
      monthlyRent: 350000,
      depositAmount: 700000,
      status: 'actif',
      notes: 'Paiement effectué ponctuellement par Airtel Money.',
      createdAt: '2025-08-25T14:00:00Z'
    },
    {
      id: 'ten_3',
      organizationId: 'org_owner_1',
      fullName: 'Elhadj Mamane Sani',
      email: 'mamane.sani@commerce-niamey.ne',
      phone: '+227 94 55 66 77',
      idCardNumber: 'CNI-NER-2019-114499',
      profession: 'Commerçant Grossiste Import-Export',
      emergencyContact: 'Mahamadou Sani (Frère) : +227 90 12 34 56',
      propertyId: 'prop_4',
      propertyTitle: 'Local Commercial & Boutique Pignon sur Rue (Grand Marché)',
      leaseStartDate: '2025-01-01',
      entryDate: '2025-01-01',
      monthlyRent: 280000,
      depositAmount: 840000, // 3 mois de caution commercial
      status: 'actif',
      notes: 'Bail commercial conforme OHADA.',
      createdAt: '2024-12-15T09:00:00Z'
    }
  ];
}

function getSeedLeases(): Lease[] {
  return [
    {
      id: 'lease_1',
      organizationId: 'org_owner_1',
      leaseNumber: 'CONTRAT-DAR-2025-001',
      tenantId: 'ten_1',
      tenantName: 'Ibrahim Moussa',
      propertyId: 'prop_1',
      propertyTitle: 'Villa Moderne avec Piscine & Jardin (Plateau)',
      startDate: '2025-06-01',
      endDate: '2026-05-31',
      monthlyRent: 650000,
      deposit: 1300000,
      paymentDueDay: 5,
      clauses: [
        'Le loyer est payable d’avance au plus tard le 5 de chaque mois.',
        'La caution de deux mois ne peut en aucun cas être imputée aux derniers loyers.',
        'Entretien courant et réparations locatives à la charge du preneur.',
        'Sous-location strictement interdite sans autorisation écrite préalable.'
      ],
      status: 'actif',
      createdAt: '2025-05-20T10:00:00Z'
    },
    {
      id: 'lease_2',
      organizationId: 'org_owner_1',
      leaseNumber: 'CONTRAT-DAR-2025-002',
      tenantId: 'ten_2',
      tenantName: 'Dr. Fatouma Abdoulaye',
      propertyId: 'prop_2',
      propertyTitle: 'Appartement F4 Standing Résidence Sahel (Koubia)',
      startDate: '2025-09-01',
      endDate: '2026-08-31',
      monthlyRent: 350000,
      deposit: 700000,
      paymentDueDay: 5,
      clauses: [
        'Paiement par virement bancaire ou Airtel Money au plus tard le 5.',
        'Respect scrupuleux du règlement de copropriété de la Résidence Sahel.',
        'Consommation électrique Nigelec à régler directement par le locataire.'
      ],
      status: 'actif',
      createdAt: '2025-08-25T14:00:00Z'
    },
    {
      id: 'lease_3',
      organizationId: 'org_owner_1',
      leaseNumber: 'CONTRAT-DAR-2025-003',
      tenantId: 'ten_3',
      tenantName: 'Elhadj Mamane Sani',
      propertyId: 'prop_4',
      propertyTitle: 'Local Commercial & Boutique Pignon sur Rue (Grand Marché)',
      startDate: '2025-01-01',
      endDate: '2027-12-31',
      monthlyRent: 280000,
      deposit: 840000,
      paymentDueDay: 1,
      clauses: [
        'Bail commercial régi par l’Acte Uniforme OHADA portant sur le droit commercial général.',
        'Activité autorisée : Commerce général et distribution de produits manufacturés.',
        'Taxes municipales d’occupation à la charge du preneur.'
      ],
      status: 'actif',
      createdAt: '2024-12-15T09:00:00Z'
    }
  ];
}

function getSeedRentDues(): RentDue[] {
  return [
    {
      id: 'due_1',
      organizationId: 'org_owner_1',
      tenantId: 'ten_1',
      tenantName: 'Ibrahim Moussa',
      propertyId: 'prop_1',
      propertyTitle: 'Villa Moderne avec Piscine & Jardin (Plateau)',
      periodMonth: 'Mars 2026',
      dueDate: '2026-03-05',
      amountExpected: 650000,
      status: 'paye',
      createdAt: '2026-03-01T08:00:00Z',
      updatedAt: '2026-03-03T11:00:00Z'
    },
    {
      id: 'due_2',
      organizationId: 'org_owner_1',
      tenantId: 'ten_2',
      tenantName: 'Dr. Fatouma Abdoulaye',
      propertyId: 'prop_2',
      propertyTitle: 'Appartement F4 Standing Résidence Sahel (Koubia)',
      periodMonth: 'Mars 2026',
      dueDate: '2026-03-05',
      amountExpected: 350000,
      status: 'paye',
      createdAt: '2026-03-01T08:00:00Z',
      updatedAt: '2026-03-04T09:15:00Z'
    },
    {
      id: 'due_3',
      organizationId: 'org_owner_1',
      tenantId: 'ten_3',
      tenantName: 'Elhadj Mamane Sani',
      propertyId: 'prop_4',
      propertyTitle: 'Local Commercial & Boutique Pignon sur Rue (Grand Marché)',
      periodMonth: 'Mars 2026',
      dueDate: '2026-03-01',
      amountExpected: 280000,
      status: 'retard',
      notes: 'Rappel téléphonique envoyé le 03 Mars.',
      createdAt: '2026-03-01T08:00:00Z',
      updatedAt: '2026-03-01T08:00:00Z'
    },
    {
      id: 'due_4',
      organizationId: 'org_owner_1',
      tenantId: 'ten_1',
      tenantName: 'Ibrahim Moussa',
      propertyId: 'prop_1',
      propertyTitle: 'Villa Moderne avec Piscine & Jardin (Plateau)',
      periodMonth: 'Février 2026',
      dueDate: '2026-02-05',
      amountExpected: 650000,
      status: 'paye',
      createdAt: '2026-02-01T08:00:00Z',
      updatedAt: '2026-02-04T10:00:00Z'
    },
    {
      id: 'due_5',
      organizationId: 'org_owner_1',
      tenantId: 'ten_2',
      tenantName: 'Dr. Fatouma Abdoulaye',
      propertyId: 'prop_2',
      propertyTitle: 'Appartement F4 Standing Résidence Sahel (Koubia)',
      periodMonth: 'Février 2026',
      dueDate: '2026-02-05',
      amountExpected: 350000,
      status: 'paye',
      createdAt: '2026-02-01T08:00:00Z',
      updatedAt: '2026-02-05T14:30:00Z'
    },
    {
      id: 'due_6',
      organizationId: 'org_owner_1',
      tenantId: 'ten_3',
      tenantName: 'Elhadj Mamane Sani',
      propertyId: 'prop_4',
      propertyTitle: 'Local Commercial & Boutique Pignon sur Rue (Grand Marché)',
      periodMonth: 'Février 2026',
      dueDate: '2026-02-01',
      amountExpected: 280000,
      status: 'paye',
      createdAt: '2026-02-01T08:00:00Z',
      updatedAt: '2026-02-03T16:00:00Z'
    }
  ];
}

function getSeedRentPayments(): RentPayment[] {
  return [
    {
      id: 'pay_1',
      organizationId: 'org_owner_1',
      dueId: 'due_1',
      receiptNumber: 'QUIT-DAR-2026-03-01',
      tenantId: 'ten_1',
      tenantName: 'Ibrahim Moussa',
      propertyId: 'prop_1',
      propertyTitle: 'Villa Moderne avec Piscine & Jardin (Plateau)',
      periodMonth: 'Mars 2026',
      dueDate: '2026-03-05',
      paymentDate: '2026-03-03',
      amountPaid: 650000,
      amountExpected: 650000,
      paymentMethod: 'virement',
      transactionReference: 'VIR-BOA-NER-99410',
      status: 'paye',
      notes: 'Loyer encaissé sur compte BOA Niger.',
      balanceAfter: 0,
      createdAt: '2026-03-03T11:00:00Z'
    },
    {
      id: 'pay_2',
      organizationId: 'org_owner_1',
      dueId: 'due_2',
      receiptNumber: 'QUIT-DAR-2026-03-02',
      tenantId: 'ten_2',
      tenantName: 'Dr. Fatouma Abdoulaye',
      propertyId: 'prop_2',
      propertyTitle: 'Appartement F4 Standing Résidence Sahel (Koubia)',
      periodMonth: 'Mars 2026',
      dueDate: '2026-03-05',
      paymentDate: '2026-03-04',
      amountPaid: 350000,
      amountExpected: 350000,
      paymentMethod: 'airtel_money',
      transactionReference: 'AIRTEL-MO-260304-9812',
      status: 'paye',
      notes: 'Reçu via Airtel Money Niger.',
      balanceAfter: 0,
      createdAt: '2026-03-04T09:15:00Z'
    },
    {
      id: 'pay_4',
      organizationId: 'org_owner_1',
      dueId: 'due_4',
      receiptNumber: 'QUIT-DAR-2026-02-01',
      tenantId: 'ten_1',
      tenantName: 'Ibrahim Moussa',
      propertyId: 'prop_1',
      propertyTitle: 'Villa Moderne avec Piscine & Jardin (Plateau)',
      periodMonth: 'Février 2026',
      dueDate: '2026-02-05',
      paymentDate: '2026-02-04',
      amountPaid: 650000,
      amountExpected: 650000,
      paymentMethod: 'virement',
      transactionReference: 'VIR-BOA-NER-88129',
      status: 'paye',
      balanceAfter: 0,
      createdAt: '2026-02-04T10:00:00Z'
    },
    {
      id: 'pay_5',
      organizationId: 'org_owner_1',
      dueId: 'due_5',
      receiptNumber: 'QUIT-DAR-2026-02-02',
      tenantId: 'ten_2',
      tenantName: 'Dr. Fatouma Abdoulaye',
      propertyId: 'prop_2',
      propertyTitle: 'Appartement F4 Standing Résidence Sahel (Koubia)',
      periodMonth: 'Février 2026',
      dueDate: '2026-02-05',
      paymentDate: '2026-02-05',
      amountPaid: 350000,
      amountExpected: 350000,
      paymentMethod: 'nita',
      transactionReference: 'NITA-TX-0226-771',
      status: 'paye',
      balanceAfter: 0,
      createdAt: '2026-02-05T14:30:00Z'
    },
    {
      id: 'pay_6',
      organizationId: 'org_owner_1',
      dueId: 'due_6',
      receiptNumber: 'QUIT-DAR-2026-02-03',
      tenantId: 'ten_3',
      tenantName: 'Elhadj Mamane Sani',
      propertyId: 'prop_4',
      propertyTitle: 'Local Commercial & Boutique Pignon sur Rue (Grand Marché)',
      periodMonth: 'Février 2026',
      dueDate: '2026-02-01',
      paymentDate: '2026-02-03',
      amountPaid: 280000,
      amountExpected: 280000,
      paymentMethod: 'especes',
      transactionReference: 'REC-MANUEL-02',
      status: 'paye',
      balanceAfter: 0,
      createdAt: '2026-02-03T16:00:00Z'
    }
  ];
}

function getSeedExpenses(): Expense[] {
  return [
    {
      id: 'exp_1',
      organizationId: 'org_owner_1',
      propertyId: 'prop_1',
      propertyTitle: 'Villa Moderne avec Piscine & Jardin (Plateau)',
      category: 'Gardiennage & Sécurité',
      amount: 80000,
      date: '2026-03-01',
      beneficiary: 'Société Nigérienne de Sécurité (SNS)',
      description: 'Prestation mensuelle agent de sécurité de nuit',
      receiptRef: 'FACTURE-SNS-2026-03',
      createdAt: '2026-03-01T09:00:00Z'
    },
    {
      id: 'exp_2',
      organizationId: 'org_owner_1',
      propertyId: 'prop_5',
      propertyTitle: 'Immeuble R+2 de 6 Appartements (Harobanda)',
      category: 'Maçonnerie & Peinture',
      amount: 145000,
      date: '2026-02-24',
      beneficiary: 'Entreprise de Rénovation Sahel Décor',
      description: 'Enduit et peinture façade extérieure et hall d’entrée',
      receiptRef: 'RECU-SD-882',
      createdAt: '2026-02-24T15:00:00Z'
    },
    {
      id: 'exp_3',
      organizationId: 'org_owner_1',
      propertyId: 'prop_2',
      propertyTitle: 'Appartement F4 Standing Résidence Sahel (Koubia)',
      category: 'Plomberie & Sanitaire',
      amount: 35000,
      date: '2026-02-18',
      beneficiary: 'Artisan Plombier Ousseini',
      description: 'Remplacement mitigeur douche principale et joint robinet',
      receiptRef: 'BON-INTERV-104',
      createdAt: '2026-02-18T11:30:00Z'
    }
  ];
}

function getSeedRepairs(): RepairTicket[] {
  return [
    {
      id: 'rep_1',
      organizationId: 'org_owner_1',
      propertyId: 'prop_2',
      propertyTitle: 'Appartement F4 Standing Résidence Sahel (Koubia)',
      reportedBy: 'Dr. Fatouma Abdoulaye (Locataire)',
      contactPhone: '+227 91 78 33 55',
      title: 'Baisse de pression d’eau dans la salle de bain',
      description: 'La pression d’eau a diminué depuis 2 jours dans la douche du fond. Le surpresseur semble désamorcé.',
      priority: 'haute',
      status: 'en_cours',
      estimatedCost: 25000,
      technicianName: 'Oumarou (Technicien Forage & Surpresseurs)',
      createdAt: '2026-03-02T08:30:00Z'
    },
    {
      id: 'rep_2',
      organizationId: 'org_owner_1',
      propertyId: 'prop_5',
      propertyTitle: 'Immeuble R+2 de 6 Appartements (Harobanda)',
      reportedBy: 'Gestionnaire DARIMMO',
      contactPhone: '+227 90 00 12 34',
      title: 'Éclairage des escaliers et minuterie défectueuse',
      description: 'Deux luminaires LED grillés au 2ème étage et le bouton poussoir reste bloqué.',
      priority: 'moyenne',
      status: 'signale',
      estimatedCost: 15000,
      createdAt: '2026-03-03T14:00:00Z'
    }
  ];
}

function getSeedAgencyMembers(): AgencyMember[] {
  return [
    {
      id: 'agent_1',
      organizationId: 'org_agency_1',
      fullName: 'Amina Dan Koussou',
      email: 'amina.koussou@sahel-immo.ne',
      phone: '+227 90 44 88 12',
      role: 'agency_admin',
      assignedPropertiesCount: 8,
      commissionRate: 10,
      status: 'actif',
      joinedAt: '2025-01-10'
    },
    {
      id: 'agent_2',
      organizationId: 'org_agency_1',
      fullName: 'Hassane Garba',
      email: 'hassane.garba@sahel-immo.ne',
      phone: '+227 96 33 22 11',
      role: 'agency_agent',
      assignedPropertiesCount: 14,
      commissionRate: 8,
      status: 'actif',
      joinedAt: '2025-03-01'
    }
  ];
}

function getSeedSubscription(orgId: string): SubscriptionState {
  // Free 14-day trial started 3 days ago for org_owner_1
  const now = new Date();
  const trialStart = new Date(now.getTime() - 3 * 24 * 60 * 60 * 1000);
  const trialEnd = new Date(trialStart.getTime() + 14 * 24 * 60 * 60 * 1000);

  return {
    organizationId: orgId,
    planId: 'pro',
    status: 'trial',
    trialStartsAt: trialStart.toISOString(),
    trialEndsAt: trialEnd.toISOString(),
    currentPeriodStart: trialStart.toISOString(),
    currentPeriodEnd: trialEnd.toISOString(),
    billingCycle: 'monthly',
    autoRenew: false
  };
}

function getSeedPaymentRequests(): SubscriptionPaymentRequest[] {
  return [
    {
      id: 'sub_pay_demo_1',
      organizationId: 'org_agency_1',
      organizationName: 'Sahel Immobilier SARL',
      userEmail: 'direction@sahel-immo.ne',
      userPhone: '+227 90 11 22 33',
      planId: 'business',
      billingCycle: 'annual',
      amount: 120000,
      provider: 'airtel_money',
      transactionReference: 'TX-AM-2026-904812',
      senderName: 'Moustapha Diallo',
      senderPhone: '+227 90 11 22 33',
      status: 'pending',
      submittedAt: '2026-03-03T16:45:00Z'
    },
    {
      id: 'sub_pay_demo_2',
      organizationId: 'org_demo_past',
      organizationName: 'Immobilière du Fleuve',
      userEmail: 'contact@fleuve-immo.ne',
      userPhone: '+227 96 55 44 33',
      planId: 'pro',
      billingCycle: 'monthly',
      amount: 5000,
      provider: 'nita',
      transactionReference: 'NITA-202602-0941',
      senderName: 'Ali Oumarou',
      senderPhone: '+227 96 55 44 33',
      status: 'approved',
      adminNotes: 'Paiement vérifié sur relevé Nita Agence Maourey.',
      submittedAt: '2026-02-28T10:00:00Z',
      reviewedAt: '2026-02-28T11:15:00Z',
      reviewedBy: 'Super Admin DARIMMO'
    }
  ];
}

function getSeedNotifications(orgId: string): AppNotification[] {
  return [
    {
      id: 'notif_1',
      organizationId: orgId,
      title: 'Loyer en retard détecté',
      message: 'Le loyer de Mars pour le "Local Commercial Grand Marché" (280 000 FCFA) n’a pas encore été enregistré.',
      type: 'warning',
      link: 'rents',
      read: false,
      createdAt: '2026-03-03T08:00:00Z'
    },
    {
      id: 'notif_2',
      organizationId: orgId,
      title: 'Paiement de loyer enregistré',
      message: 'Quittance QUIT-DAR-2026-03-02 émise pour Dr. Fatouma Abdoulaye (350 000 FCFA).',
      type: 'success',
      link: 'rents',
      read: true,
      createdAt: '2026-03-04T09:15:00Z'
    },
    {
      id: 'notif_3',
      organizationId: orgId,
      title: 'Essai gratuit DARIMMO PRO',
      message: 'Il vous reste 11 jours d’essai gratuit pour tester toutes les fonctionnalités avancées.',
      type: 'info',
      link: 'subscription',
      read: false,
      createdAt: '2026-03-01T12:00:00Z'
    }
  ];
}

// -------------------------------------------------------------
// Storage Engine Implementation
// -------------------------------------------------------------

class StorageEngine {
  private initialized = false;

  constructor() {
    this.ensureInitialized();
  }

  private getKey(collection: string): string {
    return `${STORAGE_PREFIX}${collection}`;
  }

  private read<T>(collection: string, fallback: T): T {
    try {
      const data = localStorage.getItem(this.getKey(collection));
      if (!data) return fallback;
      return JSON.parse(data) as T;
    } catch (e) {
      console.warn(`[DARIMMO Storage] Erreur de lecture sur ${collection}:`, e);
      return fallback;
    }
  }

  private write<T>(collection: string, data: T): void {
    try {
      localStorage.setItem(this.getKey(collection), JSON.stringify(data));
    } catch (e) {
      console.error(`[DARIMMO Storage] Erreur d'écriture sur ${collection}:`, e);
    }
  }

  private ensureInitialized(): void {
    if (this.initialized) return;

    try {
      const existingVersion = localStorage.getItem(DB_VERSION_KEY);
      if (!existingVersion) {
        // Initial bootstrap with realistic Niger Sahel real estate data
        this.write('properties', getSeedProperties());
        this.write('tenants', getSeedTenants());
        this.write('leases', getSeedLeases());
        this.write('rent_dues', getSeedRentDues());
        this.write('rent_payments', getSeedRentPayments());
        this.write('expenses', getSeedExpenses());
        this.write('repairs', getSeedRepairs());
        this.write('agency_members', getSeedAgencyMembers());
        this.write('subscriptions', {
          'org_owner_1': getSeedSubscription('org_owner_1'),
          'org_agency_1': {
            ...getSeedSubscription('org_agency_1'),
            planId: 'business',
            status: 'active'
          }
        });
        this.write('payment_requests', getSeedPaymentRequests());
        this.write('notifications', getSeedNotifications('org_owner_1'));
        this.write('audit_logs', [
          {
            id: 'log_1',
            organizationId: 'org_owner_1',
            userEmail: 'ousmane.proprietaire@darimmo.ne',
            action: 'INITIALISATION_COMPTE',
            details: 'Compte initialisé avec essai gratuit Pro de 14 jours.',
            timestamp: new Date().toISOString()
          }
        ]);
        this.write('plans', INITIAL_PLANS);
        this.write('config', INITIAL_CONFIG);

        localStorage.setItem(DB_VERSION_KEY, DB_VERSION);
      } else if (existingVersion !== DB_VERSION) {
        // Migration idempotente v1 → v2 : séparer échéances et versements
        this.migrateRentPaymentsToDues();
        localStorage.setItem(DB_VERSION_KEY, DB_VERSION);
      }
      this.initialized = true;
    } catch (e) {
      console.error('[DARIMMO Storage] Impossible d’initialiser le stockage:', e);
    }
  }

  /**
   * Migration idempotente : transforme les anciens RentPayment (qui mélangeaient
   * échéance + versement) en paires RentDue + RentPayment.
   * - Ne crée jamais de doublons (clé due = org+tenant+periodMonth)
   * - Conserve les numéros de reçu et montants existants
   * - Les anciennes données sans dueId sont migrées une seule fois
   */
  private migrateRentPaymentsToDues(): void {
    const payments = this.read<RentPayment[]>('rent_payments', []);
    let dues = this.read<RentDue[]>('rent_dues', []);
    if (!Array.isArray(dues)) dues = [];

    const dueKey = (p: { organizationId: string; tenantId: string; periodMonth: string }) =>
      `${p.organizationId}::${p.tenantId}::${p.periodMonth}`;

    const existingDueKeys = new Set(dues.map(d => dueKey(d)));
    let changed = false;

    for (const p of payments) {
      // Déjà migré
      if (p.dueId && dues.some(d => d.id === p.dueId)) continue;

      const key = dueKey(p);
      let due = dues.find(d => dueKey(d) === key);

      if (!due) {
        // Créer l'échéance à partir des données disponibles
        const amountExpected = typeof p.amountExpected === 'number' && p.amountExpected > 0
          ? p.amountExpected
          : (p.amountPaid || 0);
        const status: RentDueStatus =
          p.status === 'paye' ? 'paye' :
          p.status === 'partiel' ? 'partiel' :
          p.status === 'retard' ? 'retard' : 'en_attente';

        due = {
          id: `due_mig_${p.id}`,
          organizationId: p.organizationId,
          tenantId: p.tenantId,
          tenantName: p.tenantName,
          propertyId: p.propertyId,
          propertyTitle: p.propertyTitle,
          periodMonth: p.periodMonth,
          dueDate: p.dueDate || p.createdAt?.slice(0, 10) || new Date().toISOString().slice(0, 10),
          amountExpected,
          status,
          notes: p.notes,
          createdAt: p.createdAt || new Date().toISOString(),
          updatedAt: new Date().toISOString()
        };
        dues.push(due);
        existingDueKeys.add(key);
        changed = true;
      }

      // Lier le versement à l'échéance
      if (!p.dueId) {
        (p as RentPayment).dueId = due.id;
        // Si amountPaid == 0 et pas de paymentDate, ce n'était qu'une échéance sans versement
        if (!p.paymentDate && (p.amountPaid || 0) === 0) {
          // Pas de versement réel — on laisse le document mais on pourra le filtrer côté UI
        }
        changed = true;
      }
    }

    if (changed) {
      this.write('rent_dues', dues);
      this.write('rent_payments', payments);
      console.info('[DARIMMO Storage] Migration v2 rent_dues/rent_payments effectuée.');
    }
  }

  // --- Properties ---
  getProperties(orgId: string): Property[] {
    const all = this.read<Property[]>('properties', []);
    return all.filter(p => p.organizationId === orgId);
  }

  getAllProperties(): Property[] {
    return this.read<Property[]>('properties', []);
  }

  saveProperty(prop: Property): Property {
    const all = this.read<Property[]>('properties', []);
    const index = all.findIndex(p => p.id === prop.id);
    if (index >= 0) {
      all[index] = { ...prop, updatedAt: new Date().toISOString() };
    } else {
      all.unshift({ ...prop, createdAt: new Date().toISOString(), updatedAt: new Date().toISOString() });
    }
    this.write('properties', all);
    this.logAction(prop.organizationId, 'GESTION_BIEN', `Bien sauvegardé: ${prop.title}`);
    return prop;
  }

  deleteProperty(orgId: string, propId: string): boolean {
    const all = this.read<Property[]>('properties', []);
    const filtered = all.filter(p => !(p.id === propId && p.organizationId === orgId));
    this.write('properties', filtered);
    this.logAction(orgId, 'SUPPRESSION_BIEN', `Bien supprimé: ID ${propId}`);
    return true;
  }

  // --- Tenants ---
  getTenants(orgId: string): Tenant[] {
    const all = this.read<Tenant[]>('tenants', []);
    return all.filter(t => t.organizationId === orgId);
  }

  saveTenant(tenant: Tenant): Tenant {
    const all = this.read<Tenant[]>('tenants', []);
    const index = all.findIndex(t => t.id === tenant.id);
    if (index >= 0) {
      all[index] = tenant;
    } else {
      all.unshift({ ...tenant, createdAt: new Date().toISOString() });
    }
    this.write('tenants', all);
    this.logAction(tenant.organizationId, 'GESTION_LOCATAIRE', `Locataire enregistré: ${tenant.fullName}`);
    return tenant;
  }

  deleteTenant(orgId: string, tenantId: string): boolean {
    const all = this.read<Tenant[]>('tenants', []);
    const filtered = all.filter(t => !(t.id === tenantId && t.organizationId === orgId));
    this.write('tenants', filtered);
    this.logAction(orgId, 'SUPPRESSION_LOCATAIRE', `Locataire retiré: ID ${tenantId}`);
    return true;
  }

  // --- Leases ---
  getLeases(orgId: string): Lease[] {
    const all = this.read<Lease[]>('leases', []);
    return all.filter(l => l.organizationId === orgId);
  }

  saveLease(lease: Lease): Lease {
    const all = this.read<Lease[]>('leases', []);
    const index = all.findIndex(l => l.id === lease.id);
    if (index >= 0) {
      all[index] = lease;
    } else {
      all.unshift({ ...lease, createdAt: new Date().toISOString() });
    }
    this.write('leases', all);
    this.logAction(lease.organizationId, 'GESTION_CONTRAT', `Bail/Contrat généré: ${lease.leaseNumber}`);
    return lease;
  }

  // --- Rent Dues (échéances) ---
  getRentDues(orgId: string): RentDue[] {
    this.ensureInitialized();
    const all = this.read<RentDue[]>('rent_dues', []);
    return all.filter(d => d.organizationId === orgId);
  }

  saveRentDue(due: RentDue): RentDue {
    this.ensureInitialized();
    const all = this.read<RentDue[]>('rent_dues', []);
    const index = all.findIndex(d => d.id === due.id);
    const now = new Date().toISOString();
    if (index >= 0) {
      all[index] = { ...due, updatedAt: now };
    } else {
      all.unshift({ ...due, createdAt: due.createdAt || now, updatedAt: now });
    }
    this.write('rent_dues', all);
    this.logAction(due.organizationId, 'ECHEANCE_LOYER', `Échéance ${due.periodMonth} – ${due.tenantName} (${due.amountExpected} FCFA)`);
    return all[index >= 0 ? index : 0];
  }

  /**
   * Recalcule le statut d'une échéance à partir de ses versements valides.
   */
  recalculateDueStatus(dueId: string): RentDue | null {
    const dues = this.read<RentDue[]>('rent_dues', []);
    const due = dues.find(d => d.id === dueId);
    if (!due) return null;

    const payments = this.read<RentPayment[]>('rent_payments', [])
      .filter(p => p.dueId === dueId && p.status !== 'annule' && (p.amountPaid || 0) > 0);

    const totalPaid = payments.reduce((s, p) => s + (p.amountPaid || 0), 0);
    const expected = due.amountExpected || 0;
    let status: RentDueStatus;
    if (totalPaid >= expected && expected > 0) {
      status = 'paye';
    } else if (totalPaid > 0) {
      status = 'partiel';
    } else {
      const dueDate = new Date(due.dueDate);
      const today = new Date();
      today.setHours(0, 0, 0, 0);
      status = dueDate < today ? 'retard' : 'en_attente';
    }

    const updated: RentDue = { ...due, status, updatedAt: new Date().toISOString() };
    const idx = dues.findIndex(d => d.id === dueId);
    if (idx >= 0) {
      dues[idx] = updated;
      this.write('rent_dues', dues);
    }
    return updated;
  }

  // --- Rent Payments (versements) & Ledger ---
  getRentPayments(orgId: string): RentPayment[] {
    this.ensureInitialized();
    const all = this.read<RentPayment[]>('rent_payments', []);
    return all.filter(r => r.organizationId === orgId);
  }

  getPaymentsForDue(dueId: string): RentPayment[] {
    this.ensureInitialized();
    return this.read<RentPayment[]>('rent_payments', [])
      .filter(p => p.dueId === dueId)
      .sort((a, b) => (a.paymentDate || a.createdAt).localeCompare(b.paymentDate || b.createdAt));
  }

  /**
   * Enregistre un versement. Met à jour automatiquement le statut de l'échéance.
   * Empêche les doublons de soumission (même id).
   */
  saveRentPayment(payment: RentPayment): RentPayment {
    this.ensureInitialized();
    const all = this.read<RentPayment[]>('rent_payments', []);
    const index = all.findIndex(r => r.id === payment.id);

    // Validation basique
    if ((payment.amountPaid || 0) < 0) {
      throw new Error('Le montant du versement doit être positif ou nul.');
    }

    const toSave: RentPayment = {
      ...payment,
      createdAt: payment.createdAt || new Date().toISOString()
    };

    if (index >= 0) {
      all[index] = toSave;
    } else {
      all.unshift(toSave);
    }
    this.write('rent_payments', all);

    // Recalcul statut échéance
    if (toSave.dueId) {
      this.recalculateDueStatus(toSave.dueId);
    }

    this.logAction(
      payment.organizationId,
      payment.status === 'annule' ? 'ANNULATION_VERSEMENT' : 'ENCAISSEMENT_LOYER',
      `Quittance ${payment.receiptNumber} – ${payment.amountPaid} FCFA`
    );
    return toSave;
  }

  /**
   * Annule un versement (soft) : conserve l'historique, recalcule le solde.
   */
  cancelRentPayment(paymentId: string, reason: string, cancelledBy?: string): RentPayment | null {
    this.ensureInitialized();
    const all = this.read<RentPayment[]>('rent_payments', []);
    const idx = all.findIndex(p => p.id === paymentId);
    if (idx < 0) return null;
    const original = all[idx];
    if (original.status === 'annule') return original;

    const cancelled: RentPayment = {
      ...original,
      status: 'annule',
      cancelledAt: new Date().toISOString(),
      cancelledBy,
      cancelReason: reason
    };
    all[idx] = cancelled;
    this.write('rent_payments', all);
    if (cancelled.dueId) this.recalculateDueStatus(cancelled.dueId);
    this.logAction(original.organizationId, 'ANNULATION_VERSEMENT', `Quittance ${original.receiptNumber} annulée : ${reason}`);
    return cancelled;
  }

  /** Génère un numéro de reçu unique et stable (évite collisions Date.now) */
  generateReceiptNumber(orgId: string, periodMonth?: string): string {
    this.ensureInitialized();
    const year = new Date().getFullYear();
    const all = this.read<RentPayment[]>('rent_payments', [])
      .filter(p => p.organizationId === orgId && p.receiptNumber?.includes(String(year)));
    const seq = all.length + 1;
    const monthPart = periodMonth
      ? periodMonth.replace(/\s+/g, '-').toUpperCase().slice(0, 8)
      : String(new Date().getMonth() + 1).padStart(2, '0');
    return `QUIT-DAR-${year}-${monthPart}-${String(seq).padStart(4, '0')}`;
  }

  /** Calcule total encaissé et solde pour une échéance */
  getDueBalance(dueId: string): { totalPaid: number; balance: number; expected: number } {
    const due = this.read<RentDue[]>('rent_dues', []).find(d => d.id === dueId);
    const expected = due?.amountExpected || 0;
    const payments = this.getPaymentsForDue(dueId).filter(p => p.status !== 'annule');
    const totalPaid = payments.reduce((s, p) => s + (p.amountPaid || 0), 0);
    return { totalPaid, balance: Math.max(0, expected - totalPaid), expected };
  }

  // --- Expenses ---
  getExpenses(orgId: string): Expense[] {
    const all = this.read<Expense[]>('expenses', []);
    return all.filter(e => e.organizationId === orgId);
  }

  saveExpense(expense: Expense): Expense {
    const all = this.read<Expense[]>('expenses', []);
    const index = all.findIndex(e => e.id === expense.id);
    if (index >= 0) {
      all[index] = expense;
    } else {
      all.unshift({ ...expense, createdAt: new Date().toISOString() });
    }
    this.write('expenses', all);
    this.logAction(expense.organizationId, 'DEPENSE_ENREGISTREE', `Dépense: ${expense.category} - ${expense.amount} FCFA`);
    return expense;
  }

  deleteExpense(orgId: string, id: string): void {
    const all = this.read<Expense[]>('expenses', []);
    const filtered = all.filter(e => !(e.organizationId === orgId && e.id === id));
    this.write('expenses', filtered);
    this.logAction(orgId, 'DEPENSE_SUPPRIMEE', `Dépense supprimée: ${id}`);
  }

  // --- Repairs & Maintenance ---
  getRepairs(orgId: string): RepairTicket[] {
    const all = this.read<RepairTicket[]>('repairs', []);
    return all.filter(r => r.organizationId === orgId);
  }

  saveRepair(repair: RepairTicket): RepairTicket {
    const all = this.read<RepairTicket[]>('repairs', []);
    const index = all.findIndex(r => r.id === repair.id);
    if (index >= 0) {
      all[index] = repair;
    } else {
      all.unshift({ ...repair, createdAt: new Date().toISOString() });
    }
    this.write('repairs', all);
    this.logAction(repair.organizationId, 'SIGNALEMENT_PANNE', `Intervention: ${repair.title} [${repair.priority}]`);
    return repair;
  }

  // --- Agency Team Members ---
  getAgencyMembers(orgId: string): AgencyMember[] {
    const all = this.read<AgencyMember[]>('agency_members', []);
    return all.filter(m => m.organizationId === orgId);
  }

  saveAgencyMember(member: AgencyMember): AgencyMember {
    const all = this.read<AgencyMember[]>('agency_members', []);
    const index = all.findIndex(m => m.id === member.id);
    if (index >= 0) {
      all[index] = member;
    } else {
      all.unshift(member);
    }
    this.write('agency_members', all);
    this.logAction(member.organizationId, 'COLLABORATEUR_AGENCE', `Agent mis à jour: ${member.fullName}`);
    return member;
  }

  // --- Subscriptions & Trials ---
  getSubscription(orgId: string): SubscriptionState {
    const all = this.read<Record<string, SubscriptionState>>('subscriptions', {});
    if (all[orgId]) return all[orgId];
    
    // Auto provision 14-day trial for new organization
    const newSub = getSeedSubscription(orgId);
    all[orgId] = newSub;
    this.write('subscriptions', all);
    return newSub;
  }

  saveSubscription(sub: SubscriptionState): void {
    const all = this.read<Record<string, SubscriptionState>>('subscriptions', {});
    all[sub.organizationId] = sub;
    this.write('subscriptions', all);
  }

  getPlans(): PlanConfig[] {
    return this.read<PlanConfig[]>('plans', INITIAL_PLANS);
  }

  savePlans(plans: PlanConfig[]): void {
    this.write('plans', plans);
  }

  // --- Payment Requests (Nita, Amana, Airtel Money) ---
  getPaymentRequests(): SubscriptionPaymentRequest[] {
    return this.read<SubscriptionPaymentRequest[]>('payment_requests', []);
  }

  createPaymentRequest(req: SubscriptionPaymentRequest): SubscriptionPaymentRequest {
    const all = this.read<SubscriptionPaymentRequest[]>('payment_requests', []);
    all.unshift(req);
    this.write('payment_requests', all);

    // Notify super admin & organization
    this.addNotification({
      id: `notif_${Date.now()}`,
      organizationId: req.organizationId,
      title: 'Demande de paiement envoyée',
      message: `Votre versement de ${req.amount.toLocaleString('fr-FR')} FCFA via ${req.provider.toUpperCase()} est en cours de vérification par DARIMMO.`,
      type: 'info',
      read: false,
      createdAt: new Date().toISOString()
    });

    this.logAction(req.organizationId, 'DEMANDE_PAIEMENT_SOUMISE', `Paiement ${req.provider.toUpperCase()} réf ${req.transactionReference} soumis.`);
    return req;
  }

  reviewPaymentRequest(
    requestId: string,
    status: 'approved' | 'rejected',
    adminNotes: string,
    reviewerEmail: string
  ): boolean {
    const all = this.read<SubscriptionPaymentRequest[]>('payment_requests', []);
    const req = all.find(r => r.id === requestId);
    if (!req) return false;

    req.status = status;
    req.adminNotes = adminNotes;
    req.reviewedAt = new Date().toISOString();
    req.reviewedBy = reviewerEmail;
    this.write('payment_requests', all);

    if (status === 'approved') {
      // Activate or extend subscription
      const sub = this.getSubscription(req.organizationId);
      const monthsToAdd = req.billingCycle === 'annual' ? 12 : 1;
      const baseDate = new Date(sub.status === 'active' && new Date(sub.currentPeriodEnd) > new Date() 
        ? sub.currentPeriodEnd 
        : new Date()
      );
      baseDate.setMonth(baseDate.getMonth() + monthsToAdd);

      sub.planId = req.planId;
      sub.status = 'active';
      sub.currentPeriodStart = new Date().toISOString();
      sub.currentPeriodEnd = baseDate.toISOString();
      sub.billingCycle = req.billingCycle;
      this.saveSubscription(sub);

      this.addNotification({
        id: `notif_${Date.now()}`,
        organizationId: req.organizationId,
        title: 'Paiement Validé - Abonnement Activé !',
        message: `Félicitations ! Votre abonnement DARIMMO ${req.planId.toUpperCase()} est actif jusqu’au ${baseDate.toLocaleDateString('fr-FR')}.`,
        type: 'success',
        read: false,
        createdAt: new Date().toISOString()
      });
    } else {
      this.addNotification({
        id: `notif_${Date.now()}`,
        organizationId: req.organizationId,
        title: 'Paiement non validé',
        message: `Votre demande de règlement n’a pas pu être validée : "${adminNotes}". Veuillez contacter l’assistance DARIMMO.`,
        type: 'danger',
        read: false,
        createdAt: new Date().toISOString()
      });
    }

    this.logAction(req.organizationId, `PAIEMENT_${status.toUpperCase()}`, `Paiement vérifié par ${reviewerEmail}: ${adminNotes}`);
    return true;
  }

  // --- Notifications ---
  getNotifications(orgId: string): AppNotification[] {
    const all = this.read<AppNotification[]>('notifications', []);
    return all.filter(n => n.organizationId === orgId);
  }

  addNotification(notif: AppNotification): void {
    const all = this.read<AppNotification[]>('notifications', []);
    all.unshift(notif);
    this.write('notifications', all.slice(0, 100)); // Keep last 100
  }

  markNotificationAsRead(id: string): void {
    const all = this.read<AppNotification[]>('notifications', []);
    const found = all.find(n => n.id === id);
    if (found) {
      found.read = true;
      this.write('notifications', all);
    }
  }

  markAllNotificationsAsRead(orgId: string): void {
    const all = this.read<AppNotification[]>('notifications', []);
    all.forEach(n => {
      if (n.organizationId === orgId) n.read = true;
    });
    this.write('notifications', all);
  }

  // --- Audit Logs ---
  getAuditLogs(orgId?: string): AuditLog[] {
    const all = this.read<AuditLog[]>('audit_logs', []);
    if (!orgId) return all;
    return all.filter(l => l.organizationId === orgId);
  }

  logAction(orgId: string, action: string, details: string): void {
    const all = this.read<AuditLog[]>('audit_logs', []);
    all.unshift({
      id: `log_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
      organizationId: orgId,
      userEmail: 'user@darimmo.ne',
      action,
      details,
      timestamp: new Date().toISOString()
    });
    this.write('audit_logs', all.slice(0, 500));
  }

  // --- System Configuration & Maintenance ---
  getConfig(): AppConfig {
    return this.read<AppConfig>('config', INITIAL_CONFIG);
  }

  saveConfig(cfg: AppConfig): void {
    this.write('config', cfg);
  }

  // --- Backup & Restore (Zero Data Loss Protection - Exigence 20) ---
  exportFullDatabase(): string {
    const exportData = {
      version: DB_VERSION,
      exportedAt: new Date().toISOString(),
      properties: this.read('properties', []),
      tenants: this.read('tenants', []),
      leases: this.read('leases', []),
      rent_dues: this.read('rent_dues', []),
      rent_payments: this.read('rent_payments', []),
      expenses: this.read('expenses', []),
      repairs: this.read('repairs', []),
      agency_members: this.read('agency_members', []),
      subscriptions: this.read('subscriptions', {}),
      payment_requests: this.read('payment_requests', []),
      notifications: this.read('notifications', []),
      audit_logs: this.read('audit_logs', []),
      plans: this.read('plans', INITIAL_PLANS),
      config: this.read('config', INITIAL_CONFIG)
    };
    return JSON.stringify(exportData, null, 2);
  }

  importDatabase(jsonData: string): { success: boolean; message: string } {
    try {
      const parsed = JSON.parse(jsonData);
      if (!parsed.properties || !parsed.tenants) {
        return { success: false, message: 'Format de sauvegarde non valide ou incomplet.' };
      }

      this.write('properties', parsed.properties);
      this.write('tenants', parsed.tenants);
      this.write('leases', parsed.leases || []);
      this.write('rent_dues', parsed.rent_dues || []);
      this.write('rent_payments', parsed.rent_payments || []);
      this.write('expenses', parsed.expenses || []);
      this.write('repairs', parsed.repairs || []);
      this.write('agency_members', parsed.agency_members || []);
      this.write('subscriptions', parsed.subscriptions || {});
      this.write('payment_requests', parsed.payment_requests || []);
      this.write('notifications', parsed.notifications || []);
      this.write('audit_logs', parsed.audit_logs || []);
      if (parsed.plans) this.write('plans', parsed.plans);
      if (parsed.config) this.write('config', parsed.config);

      // Si ancienne sauvegarde sans rent_dues → migrer
      if (!parsed.rent_dues || (parsed.rent_dues as any[]).length === 0) {
        this.migrateRentPaymentsToDues();
      }

      return { success: true, message: 'Restauration complète réussie sans perte de données.' };
    } catch (e: any) {
      return { success: false, message: `Échec d'importation: ${e?.message || 'Erreur JSON'}` };
    }
  }

  // Reset to demo data if user explicitly requests it in Super Admin
  resetToFactoryDefaults(): void {
    localStorage.removeItem(DB_VERSION_KEY);
    this.initialized = false;
    this.ensureInitialized();
  }
}

export const storage = new StorageEngine();
