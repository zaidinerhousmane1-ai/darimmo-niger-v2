import type { RentPayment } from '../types';

const money = (value: number) => `${Math.round(Number(value) || 0).toLocaleString('fr-FR')} FCFA`;
const dateFr = (value?: string) => {
  if (!value) return new Date().toLocaleDateString('fr-FR');
  const d = new Date(`${value.slice(0, 10)}T12:00:00`);
  return Number.isNaN(d.getTime()) ? value : d.toLocaleDateString('fr-FR');
};

// PDF standard fonts use WinAnsiEncoding. Encode accented French characters as CP1252 bytes.
function toWinAnsi(input: string): number[] {
  const map: Record<string, number> = {
    '€': 0x80, '‚': 0x82, 'ƒ': 0x83, '„': 0x84, '…': 0x85, '†': 0x86, '‡': 0x87,
    'ˆ': 0x88, '‰': 0x89, 'Š': 0x8a, '‹': 0x8b, 'Œ': 0x8c, 'Ž': 0x8e, '‘': 0x91,
    '’': 0x92, '“': 0x93, '”': 0x94, '•': 0x95, '–': 0x96, '—': 0x97, '˜': 0x98,
    '™': 0x99, 'š': 0x9a, '›': 0x9b, 'œ': 0x9c, 'ž': 0x9e, 'Ÿ': 0x9f
  };
  const bytes: number[] = [];
  for (const ch of input) {
    const code = ch.codePointAt(0) || 32;
    if (code <= 0xff) bytes.push(code);
    else if (map[ch] !== undefined) bytes.push(map[ch]);
    else bytes.push(63);
  }
  return bytes;
}
function pdfString(value: string): string {
  return toWinAnsi(value).map((b) => {
    if (b === 40 || b === 41 || b === 92) return `\\${String.fromCharCode(b)}`;
    if (b < 32 || b > 126) return `\\${b.toString(8).padStart(3, '0')}`;
    return String.fromCharCode(b);
  }).join('');
}

export function generateReceiptPdf(payment: RentPayment, landlordName: string, agencyName: string): Blob {
  const expected = Math.max(0, Number(payment.amountExpected) || 0);
  const paid = Math.max(0, Number(payment.amountPaid) || 0);
  const balance = Math.max(0, Number(payment.balanceAfter ?? (expected - paid)) || 0);
  const partial = balance > 0;
  const rows = [
    { text: 'DARIMMO — GESTION IMMOBILIÈRE', size: 18, bold: true, color: '0.05 0.32 0.24' },
    { text: 'QUITTANCE / REÇU DE PAIEMENT', size: 13, bold: true },
    { text: `N° ${payment.receiptNumber}`, size: 10 },
    { text: `Émis le : ${dateFr(payment.paymentDate)}`, size: 10 },
    { text: '' },
    { text: `Bailleur / Gestionnaire : ${landlordName}`, size: 10 },
    { text: `Agence : ${agencyName}`, size: 10 },
    { text: `Locataire : ${payment.tenantName}`, size: 11, bold: true },
    { text: `Bien immobilier : ${payment.propertyTitle}`, size: 10 },
    { text: `Période concernée : ${payment.periodMonth}`, size: 10 },
    { text: `Date d'échéance : ${dateFr(payment.dueDate)}`, size: 10 },
    { text: '' },
    { text: `Loyer attendu : ${money(expected)}`, size: 11 },
    { text: `Versement encaissé : ${money(paid)}`, size: 13, bold: true, color: '0.05 0.42 0.30' },
    { text: `Total déjà réglé (après ce versement) : ${money(Math.max(0, expected - balance))}`, size: 10 },
    { text: `Solde restant : ${money(balance)}`, size: 11, bold: true, color: partial ? '0.65 0.32 0.02' : '0.05 0.42 0.30' },
    { text: '' },
    { text: `Mode de paiement : ${(payment.paymentMethod || 'Espèces').replace(/_/g, ' ')}`, size: 10 },
    { text: `Référence de transaction : ${payment.transactionReference || 'Non renseignée'}`, size: 10 },
    { text: `Statut : ${partial ? 'PAIEMENT PARTIEL — CE REÇU NE VAUT PAS QUITTANCE DE SOLDE' : 'LOYER INTÉGRALEMENT ACQUITTÉ'}`, size: 10, bold: true, color: partial ? '0.65 0.32 0.02' : '0.05 0.42 0.30' },
    { text: '' },
    { text: 'Document généré par DARIMMO-NIGER. À conserver comme preuve du versement.', size: 9 }
  ];
  let y = 790;
  const commands: string[] = [];
  for (const row of rows) {
    if (!row.text) { y -= 12; continue; }
    const color = row.color || '0.12 0.16 0.20';
    commands.push(`BT /${row.bold ? 'F2' : 'F1'} ${row.size || 10} Tf ${color} rg 48 ${y} Td (${pdfString(row.text)}) Tj ET`);
    y -= (row.size || 10) + 12;
  }
  commands.push('0.75 0.78 0.80 RG 48 755 m 547 755 l S');
  const stream = commands.join('\n');
  const objects = [
    '<< /Type /Catalog /Pages 2 0 R >>',
    '<< /Type /Pages /Kids [3 0 R] /Count 1 >>',
    '<< /Type /Page /Parent 2 0 R /MediaBox [0 0 595 842] /Resources << /Font << /F1 4 0 R /F2 5 0 R >> >> /Contents 6 0 R >>',
    '<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica /Encoding /WinAnsiEncoding >>',
    '<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica-Bold /Encoding /WinAnsiEncoding >>',
    `<< /Length ${new TextEncoder().encode(stream).length} >>\nstream\n${stream}\nendstream`
  ];
  let pdf = '%PDF-1.4\n%âãÏÓ\n';
  const offsets = [0];
  objects.forEach((obj, i) => {
    offsets.push(new TextEncoder().encode(pdf).length);
    pdf += `${i + 1} 0 obj\n${obj}\nendobj\n`;
  });
  const xref = new TextEncoder().encode(pdf).length;
  pdf += `xref\n0 ${objects.length + 1}\n0000000000 65535 f \n`;
  for (let i = 1; i < offsets.length; i++) pdf += `${String(offsets[i]).padStart(10, '0')} 00000 n \n`;
  pdf += `trailer\n<< /Size ${objects.length + 1} /Root 1 0 R >>\nstartxref\n${xref}\n%%EOF`;
  return new Blob([new TextEncoder().encode(pdf)], { type: 'application/pdf' });
}

export async function downloadReceiptPdf(payment: RentPayment, landlordName: string, agencyName: string): Promise<void> {
  const blob = generateReceiptPdf(payment, landlordName, agencyName);
  const safeNumber = (payment.receiptNumber || 'DARIMMO-RECU').replace(/[^a-zA-Z0-9_-]/g, '-');
  const fileName = `${safeNumber}.pdf`;
  const nav = navigator as Navigator & { canShare?: (data: ShareData) => boolean };
  if (typeof File !== 'undefined' && typeof nav.share === 'function') {
    try {
      const file = new File([blob], fileName, { type: 'application/pdf' });
      if (!nav.canShare || nav.canShare({ files: [file] })) {
        await nav.share({ files: [file], title: `Reçu ${payment.receiptNumber}`, text: 'Reçu de paiement DARIMMO-NIGER' });
        return;
      }
    } catch (error) {
      if ((error as DOMException)?.name === 'AbortError') return;
      // Si le partage natif n'est pas pris en charge, on passe au téléchargement navigateur.
    }
  }
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = fileName;
  link.style.display = 'none';
  document.body.appendChild(link);
  link.click();
  link.remove();
  window.setTimeout(() => URL.revokeObjectURL(url), 30000);
}
