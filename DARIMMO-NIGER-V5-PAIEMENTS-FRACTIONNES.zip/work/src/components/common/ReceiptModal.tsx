import React from 'react';
import { X, Printer, Download, CheckCircle2, Building2 } from 'lucide-react';
import { RentPayment } from '../../types';
import { downloadReceiptPdf } from '../../utils/generateReceiptPdf';

interface ReceiptModalProps {
  payment: RentPayment | null;
  onClose: () => void;
  landlordName?: string;
  agencyName?: string;
}

export const ReceiptModal: React.FC<ReceiptModalProps> = ({
  payment,
  onClose,
  landlordName = 'Ousmane Mamadou',
  agencyName = 'DARIMMO Gestion Immobilière'
}) => {
  if (!payment) return null;

  const handlePrint = async () => {
    try {
      await downloadReceiptPdf(payment, landlordName, agencyName);
    } catch (error) {
      console.error('Erreur génération PDF :', error);
      window.alert('Impossible de générer le PDF. Réessayez ou vérifiez les autorisations de partage du téléphone.');
    }
  };

  const formattedAmount = payment.amountPaid.toLocaleString('fr-FR');
  const remainingBalance = Math.max(0, Number(payment.balanceAfter ?? ((payment.amountExpected || 0) - payment.amountPaid)) || 0);
  const isPartial = remainingBalance > 0;
  const paymentDateStr = payment.paymentDate 
    ? new Date(payment.paymentDate).toLocaleDateString('fr-FR', { day: '2-digit', month: 'long', year: 'numeric' })
    : new Date().toLocaleDateString('fr-FR', { day: '2-digit', month: 'long', year: 'numeric' });

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/60 backdrop-blur-xs overflow-y-auto">
      <div className="bg-white rounded-2xl shadow-2xl border border-slate-200 max-w-2xl w-full overflow-hidden my-8 animate-in fade-in zoom-in-95 duration-200">
        {/* Top Modal Controls (Hidden in Print) */}
        <div className="no-print flex items-center justify-between px-6 py-4 border-b border-slate-100 bg-slate-50/70">
          <div className="flex items-center gap-2">
            <span className="text-xs font-semibold uppercase tracking-wider text-emerald-700 bg-emerald-50 px-2.5 py-1 rounded-md border border-emerald-100">
              Quittance Officielle
            </span>
            <span className="text-xs text-slate-500 font-mono">{payment.receiptNumber}</span>
          </div>
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={handlePrint}
              className="inline-flex items-center gap-1.5 px-3.5 py-1.5 text-xs font-medium text-slate-700 bg-white hover:bg-slate-50 border border-slate-200 rounded-lg shadow-2xs transition-colors cursor-pointer"
            >
              <Printer className="w-3.5 h-3.5 text-slate-500" />
              Télécharger / Partager PDF
            </button>
            <button
              type="button"
              onClick={onClose}
              className="p-1.5 text-slate-400 hover:text-slate-600 rounded-lg hover:bg-slate-100 transition-colors cursor-pointer"
              aria-label="Fermer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Printable Quittance Document Body */}
        <div className="p-8 sm:p-10 font-sans text-slate-800 bg-white" id="printable-receipt">
          {/* Header */}
          <div className="flex justify-between items-start border-b border-slate-200 pb-6 mb-6">
            <div>
              <div className="flex items-center gap-2 mb-1.5">
                <div className="w-8 h-8 rounded-lg bg-emerald-700 text-white flex items-center justify-center font-bold text-base">
                  D
                </div>
                <span className="text-xl font-bold tracking-tight text-slate-900">DARIMMO</span>
              </div>
              <p className="text-xs text-slate-500">Gestion Immobilière & Patrimoine</p>
              <p className="text-xs text-slate-500">Niamey, République du Niger</p>
            </div>
            <div className="text-right">
              <h2 className="text-lg font-bold text-slate-900 tracking-tight uppercase">Quittance de Loyer</h2>
              <p className="text-xs font-mono font-medium text-emerald-800">N° {payment.receiptNumber}</p>
              <p className="text-xs text-slate-500 mt-1">Date d'émission : {paymentDateStr}</p>
            </div>
          </div>

          {/* Parties information */}
          <div className="grid grid-cols-2 gap-6 p-4 rounded-xl bg-slate-50/70 border border-slate-100 text-xs mb-6">
            <div>
              <span className="font-semibold text-slate-500 uppercase tracking-wider block mb-1">Bailleur / Gestionnaire</span>
              <p className="font-semibold text-slate-900 text-sm">{landlordName}</p>
              <p className="text-slate-600">{agencyName}</p>
              <p className="text-slate-500">Niamey, Niger</p>
            </div>
            <div>
              <span className="font-semibold text-slate-500 uppercase tracking-wider block mb-1">Locataire (Preneur)</span>
              <p className="font-semibold text-slate-900 text-sm">{payment.tenantName}</p>
              <p className="text-slate-600">{payment.propertyTitle}</p>
            </div>
          </div>

          {/* Rental Period & Object */}
          <div className="mb-6 text-xs space-y-2">
            <p className="text-slate-700 leading-relaxed">
              Je soussigné certifie avoir reçu de <strong>{payment.tenantName}</strong> la somme de{' '}
              <strong className="text-emerald-800 font-mono">{formattedAmount} FCFA</strong> en règlement du loyer et des charges pour la période de :
            </p>
            <div className="p-3 bg-emerald-50/50 border border-emerald-100 rounded-lg flex items-center justify-between font-medium">
              <span className="text-emerald-900">Terme : {payment.periodMonth}</span>
              <span className="text-slate-600 font-mono">Échéance : {payment.dueDate}</span>
            </div>
          </div>

          {/* Breakdown Table */}
          <div className="border border-slate-200 rounded-xl overflow-hidden mb-6 text-xs">
            <table className="w-full text-left">
              <thead className="bg-slate-50 text-slate-600 border-b border-slate-200 font-medium">
                <tr>
                  <th className="py-2.5 px-4">Désignation</th>
                  <th className="py-2.5 px-4 text-right">Montant (FCFA)</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 font-mono text-slate-700">
                <tr>
                  <td className="py-2 px-4 font-sans text-slate-800">Montant du versement encaissé</td>
                  <td className="py-2 px-4 text-right">{formattedAmount} FCFA</td>
                </tr>
                <tr>
                  <td className="py-2 px-4 font-sans text-slate-800">Loyer total attendu</td>
                  <td className="py-2 px-4 text-right">{(payment.amountExpected || 0).toLocaleString('fr-FR')} FCFA</td>
                </tr>
                <tr className="bg-slate-50/80 font-bold text-slate-900 text-sm">
                  <td className="py-3 px-4 font-sans">Solde restant après ce versement</td>
                  <td className="py-3 px-4 text-right text-amber-700">{remainingBalance.toLocaleString('fr-FR')} FCFA</td>
                </tr>
              </tbody>
            </table>
          </div>

          {/* Payment Method Details */}
          <div className="grid grid-cols-2 gap-4 text-xs text-slate-600 mb-8 p-3 rounded-lg border border-dashed border-slate-200">
            <div>
              <span className="text-slate-400 block mb-0.5">Mode de règlement :</span>
              <span className="font-semibold text-slate-800 uppercase">
                {payment.paymentMethod ? payment.paymentMethod.replace('_', ' ') : 'Espèces'}
              </span>
            </div>
            <div>
              <span className="text-slate-400 block mb-0.5">Réf. transaction :</span>
              <span className="font-mono font-medium text-slate-800">
                {payment.transactionReference || 'RÈGLEMENT-DIRECT-NIAMEY'}
              </span>
            </div>
          </div>

          {/* Stamp & Signature */}
          <div className="flex justify-between items-end pt-4 border-t border-slate-200">
            <div className="text-[11px] text-slate-400 max-w-xs">
              <p>
                {isPartial
                  ? 'Reçu de paiement partiel. Ce document ne constitue pas une quittance de solde complet pour la période.'
                  : 'Cette quittance atteste du règlement intégral pour la période indiquée. Document délivré sous réserve d\'encaissement définitif.'}
              </p>
            </div>
            <div className="text-center">
              <p className="text-xs font-semibold text-slate-700 mb-2">Signature & Cachet</p>
              {(isPartial) ? (
                <div className="inline-flex flex-col items-center justify-center p-3 rounded-xl border-2 border-amber-500 text-amber-700 bg-amber-50/40 rotate-[-2deg]">
                  <div className="flex items-center gap-1 font-bold text-xs uppercase tracking-wider">
                    PAIEMENT PARTIEL
                  </div>
                  <span className="text-[9px] font-mono mt-0.5">Solde restant : {remainingBalance.toLocaleString('fr-FR')} FCFA</span>
                </div>
              ) : (
                <div className="inline-flex flex-col items-center justify-center p-3 rounded-xl border-2 border-emerald-600 text-emerald-700 bg-emerald-50/30 rotate-[-2deg]">
                  <div className="flex items-center gap-1 font-bold text-xs uppercase tracking-wider">
                    <CheckCircle2 className="w-3.5 h-3.5" />
                    ACQUITTÉ
                  </div>
                  <span className="text-[9px] font-mono mt-0.5">DARIMMO SAAS NIGER</span>
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Modal Bottom Bar */}
        <div className="no-print flex justify-end gap-3 px-6 py-4 bg-slate-50 border-t border-slate-100">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 text-xs font-medium text-slate-600 hover:text-slate-800 bg-white border border-slate-200 rounded-lg hover:bg-slate-50 transition-colors cursor-pointer"
          >
            Fermer
          </button>
          <button
            type="button"
            onClick={handlePrint}
            className="inline-flex items-center gap-2 px-4 py-2 text-xs font-semibold text-white bg-emerald-700 hover:bg-emerald-800 rounded-lg shadow-sm transition-colors cursor-pointer"
          >
            <Download className="w-3.5 h-3.5" />
            Télécharger / Partager le PDF
          </button>
        </div>
      </div>
    </div>
  );
};
