import React, { useState } from 'react';
import { X, Send, Copy, Check, MessageSquare, Phone } from 'lucide-react';
import { RentPayment, Tenant } from '../../types';

interface WhatsAppReminderModalProps {
  payment: RentPayment | null;
  tenant: Tenant | null;
  landlordName?: string;
  onClose: () => void;
  onLogReminder?: (message: string) => void;
}

export const WhatsAppReminderModal: React.FC<WhatsAppReminderModalProps> = ({
  payment,
  tenant,
  landlordName = 'DARIMMO Gestion',
  onClose,
  onLogReminder
}) => {
  const [copied, setCopied] = useState(false);

  if (!payment) return null;

  const tenantName = tenant?.fullName || payment.tenantName;
  const rawPhone = tenant?.phone || '+227 90 00 00 00';
  const cleanPhone = rawPhone.replace(/[^0-9]/g, '');

  const amountFormatted = (typeof payment.amountExpected === 'number' ? payment.amountExpected : 0).toLocaleString('fr-FR');

  const defaultMessage = `Bonjour ${tenantName},\n\nSauf erreur ou omission de notre part, le loyer du terme de *${payment.periodMonth}* pour le logement *${payment.propertyTitle}*, d'un montant de *${amountFormatted} FCFA*, est arrivé à échéance.\n\nMerci de bien vouloir procéder au règlement via Airtel Money, Nita ou virement selon nos accords.\n\nUne quittance électronique officielle DARIMMO vous sera immédiatement transmise dès validation.\n\nCordialement,\n*${landlordName}*`;

  const [message, setMessage] = useState(defaultMessage);

  const handleCopy = () => {
    navigator.clipboard.writeText(message);
    setCopied(true);
    setTimeout(() => setCopied(false), 2500);
    if (onLogReminder) {
      onLogReminder(`Rappel loyer copié pour ${tenantName} (${payment.periodMonth})`);
    }
  };

  const handleOpenWhatsApp = () => {
    const encoded = encodeURIComponent(message);
    const waUrl = `https://wa.me/${cleanPhone}?text=${encoded}`;
    window.open(waUrl, '_blank');
    if (onLogReminder) {
      onLogReminder(`Rappel WhatsApp envoyé à ${tenantName} (${payment.periodMonth})`);
    }
    onClose();
  };

  const handleOpenSMS = () => {
    const encoded = encodeURIComponent(message);
    const smsUrl = `sms:${rawPhone}?body=${encoded}`;
    window.location.href = smsUrl;
    if (onLogReminder) {
      onLogReminder(`Rappel SMS envoyé à ${tenantName} (${payment.periodMonth})`);
    }
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/60 backdrop-blur-xs overflow-y-auto">
      <div className="bg-white rounded-2xl shadow-2xl border border-slate-200 max-w-lg w-full overflow-hidden my-6 animate-in fade-in zoom-in-95">
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-100 bg-slate-50">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-emerald-600 text-white flex items-center justify-center font-bold">
              <MessageSquare className="w-4 h-4" />
            </div>
            <div>
              <h3 className="font-bold text-slate-900 text-sm">Rappel Loyer WhatsApp & SMS</h3>
              <p className="text-[10px] text-slate-500 font-mono">Destinataire : {tenantName} ({rawPhone})</p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-slate-600 rounded-lg"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <div className="p-6 space-y-4 text-xs">
          <div>
            <label className="block font-semibold text-slate-700 mb-1">
              Message pré-rédigé courtois (modifiable) :
            </label>
            <textarea
              rows={8}
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              className="w-full p-3 rounded-xl border border-slate-200 text-xs leading-relaxed focus:outline-hidden focus:ring-1 focus:ring-emerald-500 bg-slate-50/50"
            />
          </div>

          <div className="flex items-center justify-between pt-2">
            <button
              type="button"
              onClick={handleCopy}
              className="inline-flex items-center gap-1.5 px-3 py-2 rounded-lg border border-slate-200 text-slate-700 hover:bg-slate-50 font-medium transition-colors cursor-pointer"
            >
              {copied ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5 text-slate-500" />}
              <span>{copied ? 'Copié dans le presse-papier !' : 'Copier le texte'}</span>
            </button>

            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={handleOpenSMS}
                className="inline-flex items-center gap-1.5 px-3 py-2 rounded-lg border border-slate-200 text-slate-700 hover:bg-slate-50 font-medium transition-colors cursor-pointer"
              >
                <Phone className="w-3.5 h-3.5 text-blue-600" />
                <span>Envoyer SMS</span>
              </button>
              <button
                type="button"
                onClick={handleOpenWhatsApp}
                className="inline-flex items-center gap-1.5 px-4 py-2 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white font-semibold shadow-xs transition-colors cursor-pointer"
              >
                <Send className="w-3.5 h-3.5" />
                <span>Ouvrir WhatsApp</span>
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
