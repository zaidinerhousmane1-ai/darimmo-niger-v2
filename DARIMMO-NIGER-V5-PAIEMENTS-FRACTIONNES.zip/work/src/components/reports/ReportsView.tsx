import React, { useState } from 'react';
import { 
  TrendingUp, 
  TrendingDown, 
  DollarSign, 
  Calendar, 
  Download, 
  Printer, 
  Building2, 
  Users, 
  PieChart, 
  FileSpreadsheet,
  CheckCircle2,
  AlertCircle
} from 'lucide-react';
import { Property, RentPayment, Expense, Tenant } from '../../types';

interface ReportsViewProps {
  properties: Property[];
  tenants: Tenant[];
  payments: RentPayment[];
  expenses: Expense[];
  organizationName: string;
}

export const ReportsView: React.FC<ReportsViewProps> = ({
  properties,
  tenants,
  payments,
  expenses,
  organizationName
}) => {
  const [period, setPeriod] = useState<'month' | 'year' | 'all'>('month');

  // Filter based on period
  const filteredPayments = payments.filter(p => {
    if (period === 'month') return p.periodMonth.toLowerCase().includes('mars');
    if (period === 'year') return p.dueDate.startsWith('2026') || p.periodMonth.includes('2026');
    return true;
  });

  const filteredExpenses = expenses.filter(e => {
    if (period === 'month') return e.date.startsWith('2026-03');
    if (period === 'year') return e.date.startsWith('2026');
    return true;
  });

  // Financial aggregates — grouper par échéance (dueId) pour ne pas compter plusieurs fois le montant attendu
  const dueAgg = new Map<string, { expected: number; paid: number }>();
  filteredPayments.filter(p => p.status !== 'annule').forEach(p => {
    const key = p.dueId || `${p.tenantId}::${p.periodMonth}`;
    const cur = dueAgg.get(key) || { expected: 0, paid: 0 };
    const exp = typeof p.amountExpected === 'number' ? p.amountExpected : 0;
    if (cur.expected === 0 && exp > 0) cur.expected = exp;
    cur.paid += (p.amountPaid || 0);
    dueAgg.set(key, cur);
  });
  const dueValues = Array.from(dueAgg.values());
  const totalExpected = dueValues.reduce((acc, d) => acc + d.expected, 0);
  const totalCollected = dueValues.reduce((acc, d) => acc + d.paid, 0);
  const totalUnpaid = Math.max(0, totalExpected - totalCollected);
  const collectionRate = totalExpected > 0 ? Math.round((totalCollected / totalExpected) * 100) : 0;

  const totalExpenseAmount = filteredExpenses.reduce((acc, e) => acc + e.amount, 0);
  const netOperatingIncome = totalCollected - totalExpenseAmount;

  // Occupancy rate
  const totalProps = properties.length;
  const occupiedProps = properties.filter(p => p.status === 'occupe').length;
  const occupancyRate = totalProps > 0 ? Math.round((occupiedProps / totalProps) * 100) : 0;

  // CSV Exporters
  const exportRentsCSV = () => {
    const headers = ['N° Quittance', 'Locataire', 'Bien', 'Mois', 'Loyer Attendu (FCFA)', 'Montant Réglé (FCFA)', 'Mode de Paiement', 'Statut', 'Date Règlement'];
    const rows = filteredPayments.map(p => [
      `"${p.receiptNumber}"`,
      `"${p.tenantName}"`,
      `"${p.propertyTitle}"`,
      `"${p.periodMonth}"`,
      (typeof p.amountExpected === 'number' ? p.amountExpected : 0),
      (p.amountPaid || 0),
      `"${p.paymentMethod || 'Non spécifié'}"`,
      `"${p.status}"`,
      `"${p.paymentDate || 'En attente'}"`
    ]);

    const csvContent = 'data:text/csv;charset=utf-8,\uFEFF' + [headers.join(';'), ...rows.map(e => e.join(';'))].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `DARIMMO_GRAND_LIVRE_LOYERS_${period.toUpperCase()}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const exportExpensesCSV = () => {
    const headers = ['Date', 'Catégorie', 'Bénéficiaire', 'Bien Concerné', 'Montant (FCFA)', 'Description', 'Réf Facture'];
    const rows = filteredExpenses.map(e => [
      `"${e.date}"`,
      `"${e.category}"`,
      `"${e.beneficiary}"`,
      `"${e.propertyTitle || 'Général'}"`,
      e.amount,
      `"${e.description}"`,
      `"${e.receiptRef || ''}"`
    ]);

    const csvContent = 'data:text/csv;charset=utf-8,\uFEFF' + [headers.join(';'), ...rows.map(e => e.join(';'))].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `DARIMMO_REGISTRE_DEPENSES_${period.toUpperCase()}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="space-y-6 max-w-7xl mx-auto pb-12">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold text-slate-900 tracking-tight">Rapports Financiers & Performance</h2>
          <p className="text-xs text-slate-500 mt-0.5">
            Analytique des flux de trésorerie, taux de recouvrement et export comptable CSV.
          </p>
        </div>

        {/* Period Selector & Export Actions */}
        <div className="flex flex-wrap items-center gap-2">
          <div className="inline-flex p-1 bg-white rounded-xl border border-slate-200 shadow-2xs text-xs font-semibold">
            <button
              type="button"
              onClick={() => setPeriod('month')}
              className={`px-3 py-1.5 rounded-lg transition-all cursor-pointer ${
                period === 'month' ? 'bg-emerald-700 text-white shadow-2xs' : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Mars 2026
            </button>
            <button
              type="button"
              onClick={() => setPeriod('year')}
              className={`px-3 py-1.5 rounded-lg transition-all cursor-pointer ${
                period === 'year' ? 'bg-emerald-700 text-white shadow-2xs' : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Année 2026
            </button>
            <button
              type="button"
              onClick={() => setPeriod('all')}
              className={`px-3 py-1.5 rounded-lg transition-all cursor-pointer ${
                period === 'all' ? 'bg-emerald-700 text-white shadow-2xs' : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Historique Complet
            </button>
          </div>

          <button
            type="button"
            onClick={exportRentsCSV}
            className="inline-flex items-center gap-1.5 px-3 py-2 bg-white hover:bg-slate-50 border border-slate-200 rounded-xl text-xs font-semibold text-slate-700 shadow-2xs transition-colors cursor-pointer"
            title="Exporter les loyers en CSV"
          >
            <FileSpreadsheet className="w-3.5 h-3.5 text-emerald-700" />
            <span>Export Loyers CSV</span>
          </button>

          <button
            type="button"
            onClick={exportExpensesCSV}
            className="inline-flex items-center gap-1.5 px-3 py-2 bg-white hover:bg-slate-50 border border-slate-200 rounded-xl text-xs font-semibold text-slate-700 shadow-2xs transition-colors cursor-pointer"
            title="Exporter les dépenses en CSV"
          >
            <Download className="w-3.5 h-3.5 text-amber-600" />
            <span>Export Dépenses CSV</span>
          </button>

          <button
            type="button"
            onClick={() => window.print()}
            className="inline-flex items-center gap-1.5 px-3 py-2 bg-slate-900 hover:bg-slate-800 text-white rounded-xl text-xs font-semibold shadow-2xs transition-colors cursor-pointer"
          >
            <Printer className="w-3.5 h-3.5" />
            <span>Imprimer Bilan</span>
          </button>
        </div>
      </div>

      {/* Primary KPI Strip */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="p-5 rounded-2xl bg-white border border-slate-200/80 shadow-2xs">
          <span className="text-xs font-medium text-slate-500 block mb-1">Loyers Encaissés</span>
          <div className="flex items-baseline gap-1">
            <span className="text-2xl font-bold text-emerald-800 font-mono tracking-tight">
              {totalCollected.toLocaleString('fr-FR')}
            </span>
            <span className="text-xs font-semibold text-slate-500">FCFA</span>
          </div>
          <span className="text-[11px] text-slate-400 mt-1 block">
            Sur un total attendu de {totalExpected.toLocaleString('fr-FR')} FCFA
          </span>
        </div>

        <div className="p-5 rounded-2xl bg-white border border-slate-200/80 shadow-2xs">
          <span className="text-xs font-medium text-slate-500 block mb-1">Taux de Recouvrement</span>
          <div className="flex items-baseline gap-1">
            <span className="text-2xl font-bold text-slate-900 font-mono tracking-tight">
              {collectionRate}%
            </span>
          </div>
          <div className="w-full bg-slate-100 h-1.5 rounded-full mt-2 overflow-hidden">
            <div className="bg-emerald-600 h-full rounded-full" style={{ width: `${collectionRate}%` }} />
          </div>
        </div>

        <div className="p-5 rounded-2xl bg-white border border-slate-200/80 shadow-2xs">
          <span className="text-xs font-medium text-slate-500 block mb-1">Dépenses & Entretien</span>
          <div className="flex items-baseline gap-1">
            <span className="text-2xl font-bold text-amber-700 font-mono tracking-tight">
              {totalExpenseAmount.toLocaleString('fr-FR')}
            </span>
            <span className="text-xs font-semibold text-slate-500">FCFA</span>
          </div>
          <span className="text-[11px] text-slate-400 mt-1 block">
            {filteredExpenses.length} écriture(s) de charge
          </span>
        </div>

        <div className="p-5 rounded-2xl bg-white border border-slate-200/80 shadow-2xs">
          <span className="text-xs font-medium text-slate-500 block mb-1">Marge Nette d'Exploitation</span>
          <div className="flex items-baseline gap-1">
            <span className="text-2xl font-bold text-slate-900 font-mono tracking-tight">
              {netOperatingIncome.toLocaleString('fr-FR')}
            </span>
            <span className="text-xs font-semibold text-slate-500">FCFA</span>
          </div>
          <span className="text-[11px] text-emerald-700 font-medium mt-1 block">
            Revenus nets avant impôt
          </span>
        </div>
      </div>

      {/* Detailed Breakdown Grids */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Breakdown by Property */}
        <div className="bg-white rounded-2xl border border-slate-200/80 shadow-2xs p-5 space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-slate-100">
            <h3 className="text-sm font-bold text-slate-900">Rendement par Bien Immobilier</h3>
            <span className="text-xs text-slate-400 font-mono">{properties.length} biens</span>
          </div>

          <div className="space-y-3 text-xs">
            {properties.map(p => {
              const pPayments = filteredPayments.filter(pay => pay.propertyId === p.id);
              const pCollected = pPayments.reduce((acc, pay) => acc + pay.amountPaid, 0);
              const pExpenses = filteredExpenses.filter(e => e.propertyId === p.id);
              const pSpent = pExpenses.reduce((acc, e) => acc + e.amount, 0);
              const pNet = pCollected - pSpent;

              return (
                <div key={p.id} className="p-3 rounded-xl bg-slate-50 border border-slate-100 flex items-center justify-between gap-3">
                  <div className="min-w-0 flex-1">
                    <p className="font-bold text-slate-900 truncate">{p.title}</p>
                    <p className="text-[10px] text-slate-500">{p.neighborhood} · {p.type}</p>
                  </div>

                  <div className="text-right">
                    <span className="font-mono font-bold text-slate-900 block">
                      +{pCollected.toLocaleString('fr-FR')} F
                    </span>
                    {pSpent > 0 && (
                      <span className="text-[10px] text-amber-600 font-mono block">
                        -{pSpent.toLocaleString('fr-FR')} F ch.
                      </span>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Breakdown of Expenses by Category */}
        <div className="bg-white rounded-2xl border border-slate-200/80 shadow-2xs p-5 space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-slate-100">
            <h3 className="text-sm font-bold text-slate-900">Répartition des Charges Locatives</h3>
            <span className="text-xs font-mono text-slate-500 font-semibold">{totalExpenseAmount.toLocaleString('fr-FR')} FCFA</span>
          </div>

          <div className="space-y-3 text-xs">
            {[
              { cat: 'Gardiennage & Sécurité', color: 'bg-purple-600' },
              { cat: 'Maçonnerie & Peinture', color: 'bg-amber-600' },
              { cat: 'Plomberie & Sanitaire', color: 'bg-blue-600' },
              { cat: 'Facture Eau / Nigelec', color: 'bg-cyan-600' }
            ].map(item => {
              const catExpenses = filteredExpenses.filter(e => e.category === item.cat);
              const amount = catExpenses.reduce((acc, e) => acc + e.amount, 0);
              const pct = totalExpenseAmount > 0 ? Math.round((amount / totalExpenseAmount) * 100) : 0;

              return (
                <div key={item.cat} className="space-y-1">
                  <div className="flex justify-between font-medium text-slate-700">
                    <span>{item.cat}</span>
                    <span className="font-mono font-bold">{amount.toLocaleString('fr-FR')} FCFA ({pct}%)</span>
                  </div>
                  <div className="w-full bg-slate-100 h-2 rounded-full overflow-hidden">
                    <div className={`${item.color} h-full rounded-full transition-all duration-300`} style={{ width: `${pct}%` }} />
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
};
