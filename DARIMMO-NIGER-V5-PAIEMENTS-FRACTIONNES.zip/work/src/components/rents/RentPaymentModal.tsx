import React, { useState, useEffect } from 'react';
import { X, Receipt, DollarSign, Calendar, CreditCard, AlertCircle } from 'lucide-react';
import { RentPayment, RentDue, Tenant, PaymentMethod } from '../../types';

interface RentPaymentModalProps {
  isOpen: boolean;
  payment: RentPayment | null;
  tenants: Tenant[];
  onClose: () => void;
  onSave: (payment: RentPayment, due?: RentDue) => void;
  organizationId: string;
  /** Si fourni, on ajoute un versement à une échéance existante */
  existingDue?: RentDue | null;
  /** Générateur de numéro de reçu (injecté depuis storage) */
  generateReceiptNumber?: (orgId: string, period?: string) => string;
  rentDues?: RentDue[];
  payments?: RentPayment[];
}

const MONTH_NAMES = ['Janvier', 'Février', 'Mars', 'Avril', 'Mai', 'Juin', 'Juillet', 'Août', 'Septembre', 'Octobre', 'Novembre', 'Décembre'];
const todayISO = () => {
  const now = new Date();
  return `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}-${String(now.getDate()).padStart(2, '0')}`;
};
const currentPeriod = () => { const now = new Date(); return `${MONTH_NAMES[now.getMonth()]} ${now.getFullYear()}`; };
const defaultDueDate = () => `${todayISO().slice(0, 7)}-05`;
const MONTHS = Array.from({ length: 25 }, (_, index) => {
  const date = new Date();
  date.setDate(1);
  date.setMonth(date.getMonth() - 12 + index);
  return `${MONTH_NAMES[date.getMonth()]} ${date.getFullYear()}`;
});

export const RentPaymentModal: React.FC<RentPaymentModalProps> = ({
  isOpen,
  payment,
  tenants,
  onClose,
  onSave,
  organizationId,
  existingDue = null,
  generateReceiptNumber,
  rentDues = [],
  payments = []
}) => {
  const [tenantId, setTenantId] = useState('');
  const [periodMonth, setPeriodMonth] = useState(currentPeriod());
  const [dueDate, setDueDate] = useState(defaultDueDate());
  const [paymentDate, setPaymentDate] = useState(todayISO());
  const [amountExpected, setAmountExpected] = useState(0);
  const [amountPaid, setAmountPaid] = useState(0);
  const [paymentMethod, setPaymentMethod] = useState<PaymentMethod>('airtel_money');
  const [transactionReference, setTransactionReference] = useState('');
  const [notes, setNotes] = useState('');
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (payment) {
      setTenantId(payment.tenantId);
      setPeriodMonth(payment.periodMonth);
      setDueDate(payment.dueDate);
      setPaymentDate(payment.paymentDate || todayISO());
      setAmountExpected(payment.amountExpected ?? existingDue?.amountExpected ?? 0);
      setAmountPaid(payment.amountPaid);
      setPaymentMethod(payment.paymentMethod || 'airtel_money');
      setTransactionReference(payment.transactionReference || '');
      setNotes(payment.notes || '');
    } else if (existingDue) {
      setTenantId(existingDue.tenantId);
      setPeriodMonth(existingDue.periodMonth);
      setDueDate(existingDue.dueDate);
      setPaymentDate(todayISO());
      setAmountExpected(existingDue.amountExpected);
      // Solde restant par défaut comme montant du versement
      const alreadyPaid = payments.filter(p => p.dueId === existingDue.id && p.status !== 'annule' && p.id !== payment?.id).reduce((sum, p) => sum + (p.amountPaid || 0), 0);
      setAmountPaid(Math.max(0, existingDue.amountExpected - alreadyPaid));
      setPaymentMethod('airtel_money');
      setTransactionReference(`TX-${Date.now().toString().slice(-8)}`);
      setNotes('');
    } else {
      const firstTenant = tenants[0];
      setTenantId(firstTenant?.id || '');
      setPeriodMonth(currentPeriod());
      setDueDate(defaultDueDate());
      setPaymentDate(todayISO());
      setAmountExpected(firstTenant?.monthlyRent || 0);
      setAmountPaid(firstTenant?.monthlyRent || 0);
      setPaymentMethod('airtel_money');
      setTransactionReference(`TX-${Date.now().toString().slice(-8)}`);
      setNotes('');
    }
    setError(null);
  }, [payment, tenants, isOpen, existingDue, payments]);

  if (!isOpen) return null;

  const selectedDueForPreview = rentDues.find(d => d.tenantId === tenantId && d.periodMonth === periodMonth);
  const paidBeforePreview = selectedDueForPreview
    ? payments.filter(p => p.dueId === selectedDueForPreview.id && p.status !== 'annule' && p.id !== payment?.id).reduce((sum, p) => sum + (p.amountPaid || 0), 0)
    : 0;
  const expectedForPreview = selectedDueForPreview?.amountExpected ?? amountExpected;
  const balancePreview = Math.max(0, expectedForPreview - paidBeforePreview - (Number(amountPaid) || 0));

  const handleTenantSelect = (id: string) => {
    setTenantId(id);
    const selected = tenants.find(t => t.id === id);
    if (selected) {
      const due = rentDues.find(d => d.tenantId === id && d.periodMonth === periodMonth);
      setAmountExpected(due?.amountExpected ?? selected.monthlyRent);
      const paid = due ? payments.filter(p => p.dueId === due.id && p.status !== 'annule').reduce((sum, p) => sum + (p.amountPaid || 0), 0) : 0;
      setAmountPaid(Math.max(0, (due?.amountExpected ?? selected.monthlyRent) - paid));
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!tenantId) {
      setError('Veuillez sélectionner un locataire.');
      return;
    }

    const paid = Number(amountPaid) || 0;
    if (paid <= 0) {
      setError('Le montant du versement doit être strictement positif.');
      return;
    }

    const expected = Number(amountExpected) || 0;
    if (expected <= 0) {
      setError('Le montant attendu de l\'échéance doit être positif.');
      return;
    }

    const selectedTenant = tenants.find(t => t.id === tenantId);
    if (!selectedTenant) return;

    const receiptNum = payment
      ? payment.receiptNumber
      : (generateReceiptNumber
          ? generateReceiptNumber(organizationId, periodMonth)
          : `QUIT-DAR-${new Date().getFullYear()}-${String(Date.now()).slice(-6)}`);

    const matchingDue = existingDue || rentDues.find(d => d.tenantId === tenantId && d.periodMonth === periodMonth);
    const dueId = matchingDue?.id || payment?.dueId || `due_${Date.now()}`;

    const due: RentDue = matchingDue || {
      id: dueId,
      organizationId,
      tenantId,
      tenantName: selectedTenant.fullName,
      propertyId: selectedTenant.propertyId,
      propertyTitle: selectedTenant.propertyTitle,
      periodMonth,
      dueDate,
      amountExpected: expected,
      status: paid >= expected ? 'paye' : paid > 0 ? 'partiel' : 'en_attente',
      notes: notes.trim() || undefined,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };

    // Si existingDue, on ne change pas amountExpected (déjà fixé)
    if (existingDue) {
      // statut sera recalculé après
    } else if (payment?.dueId) {
      // édition d'un versement existant
    }

    const dueExpected = matchingDue?.amountExpected ?? expected;
    const previouslyPaid = matchingDue ? payments.filter(p => p.dueId === matchingDue.id && p.status !== 'annule' && p.id !== payment?.id).reduce((sum, p) => sum + (p.amountPaid || 0), 0) : 0;
    const outstandingBefore = Math.max(0, dueExpected - previouslyPaid);
    if (paid > outstandingBefore) {
      setError(`Le versement dépasse le solde restant (${outstandingBefore.toLocaleString('fr-FR')} FCFA).`);
      return;
    }
    const balanceAfter = Math.max(0, outstandingBefore - paid);
    // Le statut du reçu dépend du solde global après ce versement, pas de la comparaison
    // entre ce versement isolé et le loyer total. Le dernier versement peut être partiel
    // en montant tout en soldant intégralement l'échéance.
    const payStatus: PaymentStatus = balanceAfter === 0 ? 'paye' : 'partiel';

    const saved: RentPayment = {
      id: payment ? payment.id : `pay_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`,
      organizationId,
      dueId: due.id,
      receiptNumber: receiptNum,
      tenantId,
      tenantName: selectedTenant.fullName,
      propertyId: selectedTenant.propertyId,
      propertyTitle: selectedTenant.propertyTitle,
      periodMonth,
      dueDate,
      paymentDate: paymentDate,
      amountPaid: paid,
      amountExpected: dueExpected, // montant total de l'échéance, pas le montant de ce versement
      paymentMethod,
      transactionReference: transactionReference.trim() || undefined,
      status: payStatus,
      notes: notes.trim() || undefined,
      balanceAfter,
      createdAt: payment ? payment.createdAt : new Date().toISOString()
    };

    onSave(saved, due);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/60 backdrop-blur-xs overflow-y-auto">
      <div className="bg-white rounded-2xl shadow-2xl border border-slate-200 max-w-lg w-full overflow-hidden my-6 animate-in fade-in zoom-in-95">
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-100 bg-slate-50">
          <div className="flex items-center gap-2">
            <Receipt className="w-5 h-5 text-emerald-700" />
            <h3 className="font-bold text-slate-900 text-sm sm:text-base">
              {payment ? 'Modifier le versement' : existingDue ? 'Ajouter un versement au loyer' : 'Enregistrer un Encaissement de Loyer'}
            </h3>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-slate-600 rounded-lg hover:bg-slate-200/50"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-4 text-xs">
          {error && (
            <div className="p-3 rounded-lg bg-rose-50 border border-rose-200 text-rose-700 flex items-center gap-2">
              <AlertCircle className="w-4 h-4 shrink-0" />
              <span>{error}</span>
            </div>
          )}

          <div>
            <label className="block font-semibold text-slate-700 mb-1">
              Locataire concerné *
            </label>
            {tenants.length === 0 && (
              <p className="mb-2 p-3 rounded-lg bg-amber-50 border border-amber-200 text-amber-800 text-xs">
                Aucun locataire enregistré pour le moment. Ajoutez d'abord un bien (menu « Biens »), puis un locataire (menu « Locataires ») pour pouvoir enregistrer un loyer.
              </p>
            )}
            <select
              required
              value={tenantId}
              onChange={(e) => handleTenantSelect(e.target.value)}
              className="w-full px-3 py-2 rounded-lg border border-slate-200 focus:outline-hidden focus:ring-1 focus:ring-emerald-500 text-xs bg-white"
            >
              <option value="">Sélectionnez un locataire...</option>
              {tenants.map(t => (
                <option key={t.id} value={t.id}>
                  {t.fullName} — {t.propertyTitle} ({t.monthlyRent.toLocaleString('fr-FR')} FCFA)
                </option>
              ))}
            </select>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block font-semibold text-slate-700 mb-1">
                Période / Mois de loyer
              </label>
              <select
                value={periodMonth}
                onChange={(e) => {
                  const month = e.target.value;
                  setPeriodMonth(month);
                  const due = rentDues.find(d => d.tenantId === tenantId && d.periodMonth === month);
                  const tenant = tenants.find(t => t.id === tenantId);
                  const expected = due?.amountExpected ?? tenant?.monthlyRent ?? amountExpected;
                  const paid = due ? payments.filter(p => p.dueId === due.id && p.status !== 'annule').reduce((sum, p) => sum + (p.amountPaid || 0), 0) : 0;
                  setAmountExpected(expected);
                  setAmountPaid(Math.max(0, expected - paid));
                }}
                className="w-full px-3 py-2 rounded-lg border border-slate-200 focus:outline-hidden focus:ring-1 focus:ring-emerald-500 text-xs bg-white"
              >
                {MONTHS.map(m => (
                  <option key={m} value={m}>{m}</option>
                ))}
              </select>
            </div>

            <div className="flex flex-col justify-center rounded-lg border border-emerald-100 bg-emerald-50/60 px-3 py-2">
              <span className="font-semibold text-emerald-900">Statut calculé automatiquement</span>
              <span className="text-[10px] text-emerald-800">Selon le solde restant après ce versement.</span>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block font-semibold text-slate-700 mb-1">
                Montant attendu (FCFA) *
              </label>
              <input
                type="number"
                step={5000}
                required
                value={amountExpected}
                onChange={(e) => setAmountExpected(Number(e.target.value))}
                className="w-full px-3 py-2 rounded-lg border border-slate-200 focus:outline-hidden focus:ring-1 focus:ring-emerald-500 text-xs font-mono"
              />
            </div>

            <div>
              <label className="block font-semibold text-slate-700 mb-1">
                Montant encaissé (FCFA) *
              </label>
              <input
                type="number"
                step={5000}
                required
                value={amountPaid}
                onChange={(e) => setAmountPaid(Number(e.target.value))}
                className="w-full px-3 py-2 rounded-lg border border-slate-200 focus:outline-hidden focus:ring-1 focus:ring-emerald-500 text-xs font-mono font-bold text-emerald-800"
              />
            </div>
          </div>

          <div className="rounded-lg border border-slate-200 bg-slate-50 p-3 space-y-1">
            <div className="flex justify-between text-[11px]"><span className="text-slate-500">Déjà encaissé</span><strong>{paidBeforePreview.toLocaleString('fr-FR')} FCFA</strong></div>
            <div className="flex justify-between text-[11px]"><span className="text-slate-500">Solde après ce versement</span><strong className={balancePreview > 0 ? 'text-amber-700' : 'text-emerald-700'}>{balancePreview.toLocaleString('fr-FR')} FCFA</strong></div>
            <p className="text-[10px] text-slate-500">{balancePreview > 0 ? 'Le reçu indiquera un paiement partiel.' : 'Ce versement soldera l’échéance.'}</p>
          </div>

          <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">
                    Mode de paiement (Niger)
                  </label>
                  <select
                    value={paymentMethod}
                    onChange={(e) => setPaymentMethod(e.target.value as PaymentMethod)}
                    className="w-full px-3 py-2 rounded-lg border border-slate-200 focus:outline-hidden focus:ring-1 focus:ring-emerald-500 text-xs bg-white"
                  >
                    <option value="airtel_money">Airtel Money Niger</option>
                    <option value="nita">Nita Transfert</option>
                    <option value="amana">Amana Express</option>
                    <option value="virement">Virement bancaire (BOA, BIA, Sonibank)</option>
                    <option value="especes">Espèces / Cash</option>
                  </select>
                </div>

                <div>
                  <label className="block font-semibold text-slate-700 mb-1">
                    Date de règlement
                  </label>
                  <input
                    type="date"
                    required
                    value={paymentDate}
                    onChange={(e) => setPaymentDate(e.target.value)}
                    className="w-full px-3 py-2 rounded-lg border border-slate-200 focus:outline-hidden focus:ring-1 focus:ring-emerald-500 text-xs"
                  />
                </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">
                  Réf. Transaction / Bordereau
                </label>
                <input
                  type="text"
                  value={transactionReference}
                  onChange={(e) => setTransactionReference(e.target.value)}
                  placeholder="Ex: AIRTEL-TX-984102 ou Reçu Nita N° 4410"
                  className="w-full px-3 py-2 rounded-lg border border-slate-200 focus:outline-hidden focus:ring-1 focus:ring-emerald-500 text-xs font-mono"
                />
              </div>
          </div>

          <div>
            <label className="block font-semibold text-slate-700 mb-1">
              Observations / Notes internes
            </label>
            <input
              type="text"
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="Ex: Règlement déposé à l'agence de Niamey..."
              className="w-full px-3 py-2 rounded-lg border border-slate-200 focus:outline-hidden focus:ring-1 focus:ring-emerald-500 text-xs"
            />
          </div>

          <div className="flex justify-end gap-2 pt-3 border-t border-slate-100">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 rounded-lg border border-slate-200 text-slate-600 hover:bg-slate-50 transition-colors font-medium text-xs cursor-pointer"
            >
              Annuler
            </button>
            <button
              type="submit"
              className="px-4 py-2 rounded-lg bg-emerald-700 hover:bg-emerald-800 text-white font-semibold text-xs transition-colors cursor-pointer"
            >
              {payment ? 'Enregistrer les modifications' : existingDue ? 'Enregistrer ce versement' : 'Valider & Émettre la Quittance'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
