# DARIMMO-NIGER V5 — Gestion Immobilière SaaS

Application SaaS multi-tenant de gestion immobilière pour le Niger et l'Afrique francophone.

## Nouveautés V5 (priorité loyers & paiements)

### Architecture financière retenue

- **RentDue** (échéance) : ce qu'un locataire doit pour une période (montant attendu unique).
- **RentPayment** (versement) : chaque encaissement réel, lié à une échéance via `dueId`.
- Plusieurs versements possibles pour une même échéance (ex. 100k + 50k + 100k = 250k).
- Le montant attendu n'est **jamais** comptabilisé plusieurs fois.
- Solde = amountExpected(due) − Σ amountPaid(versements valides).
- Annulation soft des versements (status `annule`) avec traçabilité (date, motif, auteur).
- Numéros de reçu stables générés via `storage.generateReceiptNumber()` (séquence annuelle, pas seulement Date.now).

### Migration des données existantes

- Locale (localStorage) : exécutée automatiquement au démarrage si `DB_VERSION` < 2.0.0.
- Firestore : `firestoreService.migrateOrgRentPaymentsToDues(orgId)` appelée au chargement si des paiements n'ont pas encore de `dueId`.
- Idempotente : ré-exécution sans créer de doublons.
- Anciens numéros de reçu et montants conservés.

### Commandes de reconstruction

```bash
# Installation
npm install --legacy-peer-deps
# ou
bun install

# Vérification TypeScript
npm run lint

# Build production
npm run build

# Développement
npm run dev
```

### Capacitor / Android

Si le dossier `android/` est présent dans votre environnement de build :

```bash
npx cap sync android
```

Le présent ZIP ne contient pas forcément le dossier Android généré ; les configs Capacitor d'origine sont préservées lorsqu'elles existaient.

### Structure principale

- `src/types/index.ts` — modèles RentDue / RentPayment
- `src/services/storage.ts` — persistance locale + migration + generateReceiptNumber + recalculateDueStatus
- `src/services/firestoreService.ts` — collections `rent_dues` + `rent_payments` + migration cloud
- `src/components/rents/*` — liste et modal d'encaissement
- `src/components/common/ReceiptModal.tsx` — reçu partiel vs quittance intégrale
- `firestore.rules` — règles pour `rent_dues`

### Tests manuels recommandés

1. Créer une échéance 250 000 FCFA.
2. Versement 100 000 → solde 150 000.
3. Versement 50 000 → solde 100 000.
4. Versement 100 000 → solde 0, statut payé.
5. Trois reçus distincts.
6. Annulation d'un versement → recalcul du solde.
7. Isolation inter-organisations.

Voir `TECHNICAL-REPORT-V5.md` pour le détail des modifications.


### Paiements fractionnés
Une même échéance de loyer peut recevoir plusieurs versements indépendants. Depuis la ligne d'un paiement partiel, utilisez « Ajouter un versement ». Chaque encaissement génère son propre reçu ; le solde restant est recalculé et l'échéance n'est comptée qu'une fois dans les statistiques.
