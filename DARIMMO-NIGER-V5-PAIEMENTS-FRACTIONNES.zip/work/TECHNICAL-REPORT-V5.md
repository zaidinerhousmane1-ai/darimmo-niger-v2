# Rapport technique — DARIMMO-NIGER V5

Date : 2026-11-06
Objectif : correction architecture loyers/paiements (échéances vs versements multiples)

## Fichiers modifiés

- src/types/index.ts — introduction RentDue, refonte RentPayment (dueId, balanceAfter, annulation)
- src/services/storage.ts — seed dues, migration v2, get/save RentDue, recalculateDueStatus, cancelRentPayment, generateReceiptNumber, getDueBalance, export/import
- src/services/firestoreService.ts — get/save RentDue, migrateOrgRentPaymentsToDues
- src/App.tsx — état rentDues, chargement dual, handleSavePayment(payment, due?), handleCancelPayment, migration auto Firestore
- src/components/rents/RentsList.tsx — agrégation par dueId (anti double-comptage), protections null
- src/components/rents/RentPaymentModal.tsx — support existingDue, génération reçu injectée, validation montant > 0, création due+payment
- src/components/common/ReceiptModal.tsx — distinction paiement partiel / ACQUITTÉ
- src/components/common/WhatsAppReminderModal.tsx — safe amountExpected
- src/components/dashboard/DashboardOverview.tsx — agrégation par échéance
- src/components/reports/ReportsView.tsx — agrégation par échéance + CSV safe
- firestore.rules — match /rent_dues/{id}
- README.md — documentation V5

## Fichiers créés

- TECHNICAL-REPORT-V5.md (ce fichier)

## Architecture financière

RentDue = échéance unique (amountExpected fixe)
RentPayment = versement (amountPaid, dueId, receiptNumber unique)
Statuts due recalculés automatiquement après chaque versement / annulation.
Annulation = soft (status=annule), n'entre plus dans les totaux.

## Migration

- Locale : ensureInitialized détecte DB_VERSION != 2.0.0 → migrateRentPaymentsToDues()
- Cloud : au loadData, si paiements sans dueId → migrateOrgRentPaymentsToDues
- Idempotente (clé org+tenant+periodMonth)

## Tests réellement exécutés dans cet environnement

- Extraction et analyse de l'archive originale : OK
- Modifications structurelles types / storage / firestore / App / UI clés : OK
- npm install (partiel, node_modules présent) : OK avec --legacy-peer-deps
- tsc / npm run lint / npm run build : non finalisés dans la session (dépendance TypeScript / peer esbuild) — à relancer localement
- Tests unitaires automatisés des 12 scénarios financiers : non exécutés (pas de runner de tests configuré dans le projet d'origine)
- Génération APK Android : non effectuée (pas d'environnement Android complet)

## Problèmes restants / limites

1. Les composants tenant-portal et certains détails (PropertyDetailModal) utilisent encore amountExpected de façon naïve ; à harmoniser si besoin.
2. L'historique multi-versements dans l'UI RentsList n'est pas encore un panneau "expandable" dédié ; les lignes restent au niveau versement.
3. jsPDF non ajouté : la génération PDF reste via window.print() (comportement d'origine amélioré pour partiel/acquitté).
4. Capacitor Android : dossier android/ absent de l'archive d'origine ; à régénérer côté build machine.

## Livrable

DARIMMO-NIGER-V5-COMPLETE.zip — projet complet prêt à reconstruire (sans node_modules).


## Correctifs complémentaires — révision locale après audit

- Remplacement de `window.print()` comme mécanisme principal par un générateur PDF autonome (`src/utils/generateReceiptPdf.ts`) : fichier PDF A4 construit côté client, sans dépendance npm supplémentaire, partage natif Web Share si disponible et téléchargement navigateur en repli.
- Le reçu affiche désormais le montant attendu, le versement encaissé et le solde restant. Suppression de la ventilation arbitraire 90 % / 10 % entre loyer et charges, qui n'était fondée sur aucune donnée contractuelle.
- Le statut visuel du reçu dépend du solde restant après le versement : un dernier versement inférieur au loyer total peut solder l'échéance et doit alors être marqué comme intégralement réglé.
- Les champs de date et de mode de paiement restent visibles pour les versements partiels.
- Le formulaire de paiement réutilise automatiquement une échéance existante du même locataire et de la même période, calcule le solde avant le nouveau versement et refuse un montant supérieur au solde restant. Les paiements antérieurs sont exclus du calcul lors de la modification du versement courant.

## Limites de validation de cette révision

Le réseau de l'environnement de travail n'a pas permis d'installer les dépendances npm (délai d'expiration). En conséquence, `npm run lint`, `npm run build`, les tests sur navigateur et les tests sur APK Android n'ont pas pu être exécutés ici. Le partage natif dépend du support Web Share de l'environnement Android/WebView ; le téléchargement navigateur constitue le repli. Cette révision ne doit pas être déclarée prête pour production avant compilation et essais sur un vrai appareil.


## Correctifs complémentaires — paiements fractionnés

- L'action « Ajouter un versement » ouvre maintenant un nouvel encaissement lié à la même échéance, sans modifier ni écraser le reçu précédent.
- Le formulaire affiche le total déjà encaissé et le solde prévisionnel après le versement saisi.
- Le statut du reçu est calculé à partir du solde global restant : un dernier versement inférieur au loyer total peut donc solder l'échéance et produire un reçu de règlement intégral.
- Les statistiques et la liste des retards se basent sur le solde actuel de l'échéance, et non sur le solde historique d'un ancien reçu.
- Le mois et la date par défaut sont dynamiques ; aucun montant fictif de 250 000 FCFA n'est imposé comme valeur de secours.

### Scénario fonctionnel à vérifier dans l'application

Pour une échéance de 250 000 FCFA : enregistrer 100 000 FCFA, puis 50 000 FCFA, puis 100 000 FCFA. Résultat attendu : trois numéros de reçu distincts ; soldes successifs de 150 000, 100 000 puis 0 FCFA ; une seule échéance de 250 000 FCFA dans les totaux. Ce scénario décrit un test manuel à réaliser dans l'application : il n'a pas été exécuté automatiquement dans cet environnement.
