import React, { useState } from 'react';
import { 
  CreditCard, 
  Check, 
  Sparkles, 
  AlertCircle, 
  CheckCircle2, 
  Smartphone, 
  Building, 
  Clock, 
  HelpCircle,
  FileCheck,
  ChevronRight
} from 'lucide-react';
import { 
  SubscriptionState, 
  PlanConfig, 
  PlanId, 
  LocalPaymentProvider, 
  SubscriptionPaymentRequest, 
  AppConfig 
} from '../../types';

interface SubscriptionViewProps {
  subscription: SubscriptionState;
  plans: PlanConfig[];
  config: AppConfig;
  userEmail: string;
  userPhone: string;
  organizationName: string;
  organizationId: string;
  paymentRequests: SubscriptionPaymentRequest[];
  onSubmitPayment: (request: SubscriptionPaymentRequest) => void;
}

export const SubscriptionView: React.FC<SubscriptionViewProps> = ({
  subscription,
  plans,
  config,
  userEmail,
  userPhone,
  organizationName,
  organizationId,
  paymentRequests,
  onSubmitPayment
}) => {
  const [selectedPlanId, setSelectedPlanId] = useState<PlanId>(subscription.planId || 'pro');
  const [billingCycle, setBillingCycle] = useState<'monthly' | 'annual'>(subscription.billingCycle || 'monthly');
  
  // Payment Submission Modal
  const [showPaymentModal, setShowPaymentModal] = useState(false);
  const [selectedProvider, setSelectedProvider] = useState<LocalPaymentProvider>('airtel_money');
  const [transactionRef, setTransactionRef] = useState('');
  const [senderName, setSenderName] = useState(organizationName || '');
  const [senderPhone, setSenderPhone] = useState(userPhone || '+227 ');
  const [submittedSuccess, setSubmittedSuccess] = useState(false);

  // Compute trial status
  const trialEnd = new Date(subscription.trialEndsAt);
  const now = new Date();
  const trialDaysRemaining = Math.max(0, Math.ceil((trialEnd.getTime() - now.getTime()) / (1000 * 60 * 60 * 24)));
  const isTrialExpired = subscription.status === 'trial' && trialDaysRemaining <= 0;

  const currentPlan = plans.find(p => p.id === selectedPlanId) || plans[1];
  const calculatedPrice = billingCycle === 'annual' ? currentPlan.annualPrice : currentPlan.monthlyPrice;

  const handleStartPayment = (planId: PlanId) => {
    setSelectedPlanId(planId);
    setShowPaymentModal(true);
    setSubmittedSuccess(false);
  };

  const handleConfirmPayment = (e: React.FormEvent) => {
    e.preventDefault();
    if (!transactionRef.trim() || !senderName.trim()) return;

    const request: SubscriptionPaymentRequest = {
      id: `sub_req_${Date.now()}`,
      organizationId,
      organizationName,
      userEmail,
      userPhone,
      planId: selectedPlanId,
      billingCycle,
      amount: calculatedPrice,
      provider: selectedProvider,
      transactionReference: transactionRef.trim(),
      senderName: senderName.trim(),
      senderPhone: senderPhone.trim(),
      status: 'pending',
      submittedAt: new Date().toISOString()
    };

    onSubmitPayment(request);
    setSubmittedSuccess(true);
  };

  return (
    <div className="space-y-6 max-w-7xl mx-auto pb-12">
      {/* Trial Countdown or Active Status Banner */}
      <div className="p-6 rounded-2xl bg-white border border-slate-200/80 shadow-2xs flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div className="flex items-start gap-4">
          <div className="w-12 h-12 rounded-xl bg-emerald-50 text-emerald-700 flex items-center justify-center shrink-0">
            <Sparkles className="w-6 h-6" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-lg font-bold text-slate-900">
                {subscription.status === 'trial' ? 'Période d\'Essai Gratuit Active' : `Abonnement ${subscription.planId.toUpperCase()} Actif`}
              </h2>
              <span className={`px-2 py-0.5 rounded text-[10px] font-semibold ${
                subscription.status === 'active' 
                  ? 'bg-emerald-50 text-emerald-800 border border-emerald-200' 
                  : 'bg-amber-50 text-amber-800 border border-amber-200'
              }`}>
                {subscription.status === 'active' ? 'Validé' : `${trialDaysRemaining} jours restants`}
              </span>
            </div>
            <p className="text-xs text-slate-500 mt-1">
              {subscription.status === 'trial' 
                ? `Votre essai sans engagement expire le ${trialEnd.toLocaleDateString('fr-FR')}. Vous bénéficiez de toutes les options de la formule Pro.`
                : `Abonnement souscrit jusqu’au ${new Date(subscription.currentPeriodEnd).toLocaleDateString('fr-FR')}. Facturation ${subscription.billingCycle === 'annual' ? 'annuelle' : 'mensuelle'}.`
              }
            </p>
          </div>
        </div>

        <button
          type="button"
          onClick={() => handleStartPayment(subscription.planId)}
          className="px-5 py-2.5 rounded-xl bg-emerald-700 hover:bg-emerald-800 text-white font-semibold text-xs shadow-xs transition-colors cursor-pointer shrink-0"
        >
          {subscription.status === 'trial' ? 'Souscrire maintenant' : 'Renouveler ou Changer de formule'}
        </button>
      </div>

      {/* Plan selection and comparison */}
      <div className="space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <h3 className="text-base font-bold text-slate-900">Formules d'Abonnement DARIMMO</h3>
            <p className="text-xs text-slate-500">Paiements locaux par Airtel Money, Nita ou Amana au Niger.</p>
          </div>

          {/* Billing Switcher */}
          <div className="inline-flex items-center p-1 bg-slate-100 rounded-xl text-xs font-semibold self-start sm:self-auto">
            <button
              type="button"
              onClick={() => setBillingCycle('monthly')}
              className={`px-3 py-1.5 rounded-lg transition-all cursor-pointer ${
                billingCycle === 'monthly' ? 'bg-white text-slate-900 shadow-2xs' : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Mensuel
            </button>
            <button
              type="button"
              onClick={() => setBillingCycle('annual')}
              className={`px-3 py-1.5 rounded-lg transition-all flex items-center gap-1.5 cursor-pointer ${
                billingCycle === 'annual' ? 'bg-white text-slate-900 shadow-2xs' : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <span>Annuel (-15%)</span>
              <span className="text-[10px] bg-emerald-100 text-emerald-800 px-1.5 py-0.5 rounded font-bold">2 mois offerts</span>
            </button>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-5">
          {plans.map(plan => {
            const price = billingCycle === 'annual' ? plan.annualPrice : plan.monthlyPrice;
            const isCurrent = subscription.planId === plan.id;
            const isEnterprise = plan.id === 'enterprise';

            return (
              <div
                key={plan.id}
                className={`bg-white rounded-2xl p-5 border flex flex-col justify-between transition-all ${
                  plan.recommended
                    ? 'border-emerald-600 ring-2 ring-emerald-600/20 shadow-sm relative'
                    : 'border-slate-200/80 shadow-2xs'
                }`}
              >
                {plan.recommended && (
                  <div className="absolute -top-3 left-1/2 -translate-x-1/2 bg-emerald-700 text-white text-[10px] font-bold uppercase tracking-wider px-2.5 py-0.5 rounded-full">
                    Formule Recommandée
                  </div>
                )}

                <div>
                  <div className="flex items-center justify-between mb-1">
                    <h4 className="text-base font-bold text-slate-900">{plan.name}</h4>
                    {isCurrent && (
                      <span className="text-[10px] bg-slate-100 text-slate-700 px-2 py-0.5 rounded font-semibold">
                        Actuel
                      </span>
                    )}
                  </div>
                  <p className="text-xs text-slate-500 mb-4 min-h-[30px]">{plan.tagline}</p>

                  <div className="pb-4 mb-4 border-b border-slate-100">
                    {isEnterprise ? (
                      <span className="text-xl font-bold text-slate-900">Sur Devis</span>
                    ) : (
                      <div className="flex items-baseline gap-1">
                        <span className="text-2xl font-bold text-slate-900 font-mono">
                          {price.toLocaleString('fr-FR')}
                        </span>
                        <span className="text-xs text-slate-500 font-semibold">FCFA</span>
                        <span className="text-[10px] text-slate-400">/{billingCycle === 'annual' ? 'an' : 'mois'}</span>
                      </div>
                    )}
                  </div>

                  <ul className="space-y-2 text-xs text-slate-600 mb-6">
                    {plan.features.map((f, i) => (
                      <li key={i} className="flex items-start gap-2">
                        <Check className="w-3.5 h-3.5 text-emerald-600 shrink-0 mt-0.5" />
                        <span>{f}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                <button
                  type="button"
                  onClick={() => handleStartPayment(plan.id)}
                  className={`w-full py-2.5 px-4 rounded-xl text-xs font-semibold transition-colors cursor-pointer ${
                    plan.recommended
                      ? 'bg-emerald-700 hover:bg-emerald-800 text-white shadow-xs'
                      : 'bg-slate-900 hover:bg-slate-800 text-white'
                  }`}
                >
                  Choisir {plan.name}
                </button>
              </div>
            );
          })}
        </div>
      </div>

      {/* Local Payment Requests History */}
      <div className="bg-white rounded-2xl border border-slate-200/80 shadow-2xs overflow-hidden">
        <div className="p-5 border-b border-slate-100">
          <h3 className="text-sm font-bold text-slate-900">Historique des Règlements d'Abonnement</h3>
          <p className="text-xs text-slate-500">Demandes de validation de paiements Nita, Amana et Airtel Money</p>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50 text-slate-500 border-b border-slate-100">
              <tr>
                <th className="py-3 px-4 font-semibold">Date</th>
                <th className="py-3 px-4 font-semibold">Formule</th>
                <th className="py-3 px-4 font-semibold">Montant</th>
                <th className="py-3 px-4 font-semibold">Moyen</th>
                <th className="py-3 px-4 font-semibold">Référence Transaction</th>
                <th className="py-3 px-4 font-semibold">Statut</th>
                <th className="py-3 px-4 font-semibold text-right">Notes Admin</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {paymentRequests.length === 0 ? (
                <tr>
                  <td colSpan={7} className="py-8 text-center text-slate-400">
                    Aucun paiement d'abonnement soumis.
                  </td>
                </tr>
              ) : (
                paymentRequests.map(r => (
                  <tr key={r.id} className="hover:bg-slate-50/60 transition-colors">
                    <td className="py-3 px-4 text-slate-600 font-mono">
                      {new Date(r.submittedAt).toLocaleDateString('fr-FR')}
                    </td>
                    <td className="py-3 px-4 font-semibold text-slate-900 uppercase">
                      {r.planId} ({r.billingCycle})
                    </td>
                    <td className="py-3 px-4 font-mono font-bold text-slate-900">
                      {r.amount.toLocaleString('fr-FR')} FCFA
                    </td>
                    <td className="py-3 px-4 uppercase font-semibold text-slate-700">
                      {r.provider.replace('_', ' ')}
                    </td>
                    <td className="py-3 px-4 font-mono text-slate-800">
                      {r.transactionReference}
                    </td>
                    <td className="py-3 px-4">
                      {r.status === 'approved' ? (
                        <span className="px-2 py-0.5 rounded text-[10px] font-semibold bg-emerald-50 text-emerald-800 border border-emerald-200">
                          Validé
                        </span>
                      ) : r.status === 'pending' ? (
                        <span className="px-2 py-0.5 rounded text-[10px] font-semibold bg-amber-50 text-amber-800 border border-amber-200">
                          En vérification
                        </span>
                      ) : (
                        <span className="px-2 py-0.5 rounded text-[10px] font-semibold bg-rose-50 text-rose-800 border border-rose-200">
                          Rejeté
                        </span>
                      )}
                    </td>
                    <td className="py-3 px-4 text-right text-slate-500">
                      {r.adminNotes || '—'}
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Local Payment Instructions & Submission Modal */}
      {showPaymentModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/60 backdrop-blur-xs overflow-y-auto">
          <div className="bg-white rounded-2xl shadow-2xl border border-slate-200 max-w-lg w-full overflow-hidden my-6 animate-in fade-in zoom-in-95">
            <div className="flex items-center justify-between px-6 py-4 border-b border-slate-100 bg-slate-50">
              <div className="flex items-center gap-2">
                <CreditCard className="w-5 h-5 text-emerald-700" />
                <h3 className="font-bold text-slate-900 text-sm">
                  Règlement Abonnement DARIMMO {currentPlan.name}
                </h3>
              </div>
              <button
                type="button"
                onClick={() => setShowPaymentModal(false)}
                className="p-1.5 text-slate-400 hover:text-slate-600 rounded-lg"
              >
                ✕
              </button>
            </div>

            {submittedSuccess ? (
              <div className="p-8 text-center space-y-4">
                <div className="w-14 h-14 rounded-full bg-emerald-50 text-emerald-700 flex items-center justify-center mx-auto">
                  <CheckCircle2 className="w-8 h-8" />
                </div>
                <h4 className="text-base font-bold text-slate-900">
                  Demande de règlement transmise avec succès !
                </h4>
                <p className="text-xs text-slate-600 max-w-md mx-auto leading-relaxed">
                  Votre référence de transaction <strong className="font-mono text-emerald-800">{transactionRef}</strong> a été enregistrée. L'administrateur DARIMMO effectue la vérification auprès de l'opérateur et activera votre formule sous peu.
                </p>
                <button
                  type="button"
                  onClick={() => setShowPaymentModal(false)}
                  className="px-5 py-2.5 rounded-xl bg-emerald-700 text-white font-semibold text-xs transition-colors cursor-pointer"
                >
                  Retour à mon espace
                </button>
              </div>
            ) : (
              <form onSubmit={handleConfirmPayment} className="p-6 space-y-4 text-xs">
                {/* Total due */}
                <div className="p-4 bg-emerald-50/70 border border-emerald-100 rounded-xl flex items-center justify-between">
                  <div>
                    <span className="text-[10px] text-emerald-800 uppercase font-semibold block">Montant total à transférer</span>
                    <span className="text-xl font-bold text-emerald-950 font-mono">
                      {calculatedPrice.toLocaleString('fr-FR')} FCFA
                    </span>
                  </div>
                  <span className="text-xs font-semibold text-emerald-800">
                    Formule {currentPlan.name} ({billingCycle})
                  </span>
                </div>

                {/* Local Provider Choice */}
                <div>
                  <label className="block font-semibold text-slate-700 mb-2">
                    Sélectionnez votre moyen de paiement au Niger :
                  </label>
                  <div className="grid grid-cols-3 gap-2">
                    <button
                      type="button"
                      onClick={() => setSelectedProvider('airtel_money')}
                      className={`p-2.5 rounded-xl border text-center transition-all cursor-pointer ${
                        selectedProvider === 'airtel_money'
                          ? 'border-red-600 bg-red-50 text-red-700 font-bold'
                          : 'border-slate-200 text-slate-700 hover:bg-slate-50'
                      }`}
                    >
                      Airtel Money
                    </button>
                    <button
                      type="button"
                      onClick={() => setSelectedProvider('nita')}
                      className={`p-2.5 rounded-xl border text-center transition-all cursor-pointer ${
                        selectedProvider === 'nita'
                          ? 'border-emerald-600 bg-emerald-50 text-emerald-800 font-bold'
                          : 'border-slate-200 text-slate-700 hover:bg-slate-50'
                      }`}
                    >
                      Nita Transfert
                    </button>
                    <button
                      type="button"
                      onClick={() => setSelectedProvider('amana')}
                      className={`p-2.5 rounded-xl border text-center transition-all cursor-pointer ${
                        selectedProvider === 'amana'
                          ? 'border-blue-600 bg-blue-50 text-blue-800 font-bold'
                          : 'border-slate-200 text-slate-700 hover:bg-slate-50'
                      }`}
                    >
                      Amana Express
                    </button>
                  </div>
                </div>

                {/* Instructions Box */}
                <div className="p-3.5 bg-slate-50 rounded-xl border border-slate-200/80 space-y-1.5 text-[11px] text-slate-700">
                  <p className="font-bold text-slate-900">Instructions de transfert :</p>
                  {selectedProvider === 'airtel_money' && (
                    <>
                      <p>1. Composez le code USSD : <strong className="font-mono text-red-700">{config.paymentInstructions.airtelMoney.ussdCode}</strong></p>
                      <p>2. Nom marchand : <strong>{config.paymentInstructions.airtelMoney.merchantName}</strong></p>
                      <p>3. Notez le code de transaction reçu par SMS.</p>
                    </>
                  )}
                  {selectedProvider === 'nita' && (
                    <>
                      <p>1. Rendez-vous dans une agence Nita ou via l'application Nita.</p>
                      <p>2. Destinataire : <strong>{config.paymentInstructions.nita.accountName}</strong></p>
                      <p>3. N° Compte : <strong className="font-mono">{config.paymentInstructions.nita.accountNumber}</strong> ({config.paymentInstructions.nita.city})</p>
                    </>
                  )}
                  {selectedProvider === 'amana' && (
                    <>
                      <p>1. Rendez-vous dans une agence Amana Express.</p>
                      <p>2. Destinataire : <strong>{config.paymentInstructions.amana.accountName}</strong></p>
                      <p>3. N° Compte : <strong className="font-mono">{config.paymentInstructions.amana.accountNumber}</strong></p>
                    </>
                  )}
                </div>

                {/* Transaction Reference & Sender Name Inputs */}
                <div className="space-y-3 pt-1">
                  <div>
                    <label className="block font-semibold text-slate-700 mb-1">
                      Référence de transaction / Code reçu par SMS *
                    </label>
                    <input
                      type="text"
                      required
                      value={transactionRef}
                      onChange={(e) => setTransactionRef(e.target.value)}
                      placeholder="Ex: TX-AIRTEL-98214 ou Bordereau Nita 84192"
                      className="w-full px-3 py-2 rounded-lg border border-slate-200 focus:outline-hidden focus:ring-1 focus:ring-emerald-500 text-xs font-mono"
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label className="block font-semibold text-slate-700 mb-1">
                        Nom de l'expéditeur *
                      </label>
                      <input
                        type="text"
                        required
                        value={senderName}
                        onChange={(e) => setSenderName(e.target.value)}
                        placeholder="Ex: Ousmane Mamadou"
                        className="w-full px-3 py-2 rounded-lg border border-slate-200 focus:outline-hidden focus:ring-1 focus:ring-emerald-500 text-xs"
                      />
                    </div>

                    <div>
                      <label className="block font-semibold text-slate-700 mb-1">
                        Numéro téléphone expéditeur
                      </label>
                      <input
                        type="tel"
                        required
                        value={senderPhone}
                        onChange={(e) => setSenderPhone(e.target.value)}
                        placeholder="+227 90 00 00 00"
                        className="w-full px-3 py-2 rounded-lg border border-slate-200 focus:outline-hidden focus:ring-1 focus:ring-emerald-500 text-xs font-mono"
                      />
                    </div>
                  </div>
                </div>

                <div className="flex justify-end gap-2 pt-4 border-t border-slate-100">
                  <button
                    type="button"
                    onClick={() => setShowPaymentModal(false)}
                    className="px-4 py-2 rounded-lg border border-slate-200 text-slate-600 hover:bg-slate-50 transition-colors"
                  >
                    Annuler
                  </button>
                  <button
                    type="submit"
                    className="px-4 py-2 rounded-lg bg-emerald-700 hover:bg-emerald-800 text-white font-semibold transition-colors cursor-pointer"
                  >
                    Soumettre pour validation
                  </button>
                </div>
              </form>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
