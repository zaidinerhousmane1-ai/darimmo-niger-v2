import React, { useState, useMemo } from 'react';
import { 
  Building2, 
  Plus, 
  Search, 
  Filter, 
  MapPin, 
  Home, 
  Edit3, 
  Trash2, 
  Eye, 
  AlertCircle,
  LayoutGrid,
  List
} from 'lucide-react';
import { Property, PropertyStatus, PropertyType, PlanConfig } from '../../types';
import { Pagination } from '../common/Pagination';
import { EmptyState } from '../common/EmptyState';

interface PropertiesListProps {
  properties: Property[];
  currentPlan: PlanConfig;
  onAddProperty: () => void;
  onEditProperty: (prop: Property) => void;
  onDeleteProperty: (id: string) => void;
  onViewProperty: (prop: Property) => void;
  onUpgradePlan: () => void;
}

export const PropertiesList: React.FC<PropertiesListProps> = ({
  properties,
  currentPlan,
  onAddProperty,
  onEditProperty,
  onDeleteProperty,
  onViewProperty,
  onUpgradePlan
}) => {
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [typeFilter, setTypeFilter] = useState<string>('all');
  const [viewMode, setViewMode] = useState<'grid' | 'table'>('grid');
  const [propertyToDelete, setPropertyToDelete] = useState<Property | null>(null);

  // Pagination state
  const [currentPage, setCurrentPage] = useState(1);
  const [pageSize, setPageSize] = useState(10);

  // Check plan limits
  const maxProps = currentPlan.maxProperties;
  const isLimitReached = maxProps !== -1 && properties.length >= maxProps;

  // Filtered properties
  const filtered = useMemo(() => {
    return properties.filter(p => {
      const matchSearch = search.trim() === '' || 
        p.title.toLowerCase().includes(search.toLowerCase()) ||
        p.neighborhood.toLowerCase().includes(search.toLowerCase()) ||
        p.address.toLowerCase().includes(search.toLowerCase());

      const matchStatus = statusFilter === 'all' || p.status === statusFilter;
      const matchType = typeFilter === 'all' || p.type === typeFilter;

      return matchSearch && matchStatus && matchType;
    });
  }, [properties, search, statusFilter, typeFilter]);

  // Paginated chunk
  const paginatedItems = useMemo(() => {
    const start = (currentPage - 1) * pageSize;
    return filtered.slice(start, start + pageSize);
  }, [filtered, currentPage, pageSize]);

  const confirmDelete = () => {
    if (propertyToDelete) {
      onDeleteProperty(propertyToDelete.id);
      setPropertyToDelete(null);
    }
  };

  const statusBadge = (st: PropertyStatus) => {
    switch (st) {
      case 'disponible':
        return <span className="px-2 py-0.5 rounded text-[10px] font-semibold bg-emerald-50 text-emerald-800 border border-emerald-200">Disponible</span>;
      case 'occupe':
        return <span className="px-2 py-0.5 rounded text-[10px] font-semibold bg-blue-50 text-blue-800 border border-blue-200">Occupé</span>;
      case 'maintenance':
        return <span className="px-2 py-0.5 rounded text-[10px] font-semibold bg-amber-50 text-amber-800 border border-amber-200">En maintenance</span>;
      case 'en_attente':
        return <span className="px-2 py-0.5 rounded text-[10px] font-semibold bg-purple-50 text-purple-800 border border-purple-200">En attente</span>;
    }
  };

  return (
    <div className="space-y-5 max-w-7xl mx-auto pb-12">
      {/* Header and Controls */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold text-slate-900 tracking-tight">Parc Immobilier</h2>
          <p className="text-xs text-slate-500 mt-0.5">
            Gérez vos appartements, villas, boutiques et immeubles au Niger.
          </p>
        </div>

        <div className="flex items-center gap-3">
          {/* Plan limit indicator */}
          <div className="text-right text-xs">
            <span className="font-semibold text-slate-700">
              {properties.length} / {maxProps === -1 ? 'Illimités' : maxProps} biens
            </span>
            <span className="text-[10px] text-slate-400 block font-mono">
              Formule {currentPlan.name}
            </span>
          </div>

          <button
            type="button"
            onClick={isLimitReached ? onUpgradePlan : onAddProperty}
            className={`inline-flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs font-semibold shadow-xs transition-colors cursor-pointer ${
              isLimitReached
                ? 'bg-amber-600 hover:bg-amber-700 text-white'
                : 'bg-emerald-700 hover:bg-emerald-800 text-white'
            }`}
          >
            <Plus className="w-4 h-4" />
            <span>{isLimitReached ? 'Augmenter ma limite' : 'Ajouter un bien'}</span>
          </button>
        </div>
      </div>

      {isLimitReached && (
        <div className="p-3.5 rounded-xl bg-amber-50 border border-amber-200 text-amber-900 text-xs flex items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <AlertCircle className="w-4 h-4 text-amber-600 shrink-0" />
            <span>
              Vous avez atteint la limite de <strong>{maxProps} biens</strong> incluse dans votre formule {currentPlan.name}.
            </span>
          </div>
          <button
            type="button"
            onClick={onUpgradePlan}
            className="font-bold underline text-amber-800 hover:text-amber-950 whitespace-nowrap cursor-pointer"
          >
            Passer à la Formule PRO →
          </button>
        </div>
      )}

      {/* Filter and Search Bar */}
      <div className="p-4 bg-white rounded-2xl border border-slate-200/80 shadow-2xs flex flex-col md:flex-row gap-3 items-stretch md:items-center justify-between">
        <div className="flex-1 relative">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
          <input
            type="text"
            value={search}
            onChange={(e) => { setSearch(e.target.value); setCurrentPage(1); }}
            placeholder="Rechercher par nom, quartier (Plateau, Koubia...), adresse..."
            className="w-full pl-9 pr-3 py-2 text-xs rounded-xl border border-slate-200 focus:outline-hidden focus:ring-1 focus:ring-emerald-500 bg-slate-50/50"
          />
        </div>

        <div className="flex items-center gap-2">
          <select
            value={statusFilter}
            onChange={(e) => { setStatusFilter(e.target.value); setCurrentPage(1); }}
            className="px-3 py-2 text-xs rounded-xl border border-slate-200 bg-white text-slate-700 focus:outline-hidden focus:ring-1 focus:ring-emerald-500"
          >
            <option value="all">Tous les statuts</option>
            <option value="disponible">Disponibles</option>
            <option value="occupe">Occupés</option>
            <option value="maintenance">En maintenance</option>
          </select>

          <select
            value={typeFilter}
            onChange={(e) => { setTypeFilter(e.target.value); setCurrentPage(1); }}
            className="px-3 py-2 text-xs rounded-xl border border-slate-200 bg-white text-slate-700 focus:outline-hidden focus:ring-1 focus:ring-emerald-500"
          >
            <option value="all">Tous les types</option>
            <option value="Maison">Maisons / Villas</option>
            <option value="Appartement">Appartements</option>
            <option value="Studio">Studios</option>
            <option value="Boutique">Boutiques</option>
            <option value="Immeuble">Immeubles</option>
          </select>

          <div className="hidden sm:flex items-center bg-slate-100 p-1 rounded-xl">
            <button
              type="button"
              onClick={() => setViewMode('grid')}
              className={`p-1.5 rounded-lg transition-colors cursor-pointer ${
                viewMode === 'grid' ? 'bg-white text-slate-900 shadow-2xs' : 'text-slate-500 hover:text-slate-900'
              }`}
              title="Vue grille"
            >
              <LayoutGrid className="w-4 h-4" />
            </button>
            <button
              type="button"
              onClick={() => setViewMode('table')}
              className={`p-1.5 rounded-lg transition-colors cursor-pointer ${
                viewMode === 'table' ? 'bg-white text-slate-900 shadow-2xs' : 'text-slate-500 hover:text-slate-900'
              }`}
              title="Vue tableau"
            >
              <List className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>

      {/* Content Rendering */}
      {filtered.length === 0 ? (
        <EmptyState
          icon={Building2}
          title="Aucun bien immobilier trouvé"
          description={
            search || statusFilter !== 'all' || typeFilter !== 'all'
              ? 'Aucun bien ne correspond à vos critères de recherche. Essayez de réinitialiser vos filtres.'
              : 'Vous n’avez pas encore enregistré de bien immobilier. Commencez dès maintenant à organiser votre patrimoine locatif.'
          }
          actionLabel="Ajouter un premier bien"
          onAction={onAddProperty}
        />
      ) : viewMode === 'grid' ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
          {paginatedItems.map(prop => (
            <div
              key={prop.id}
              className="bg-white rounded-2xl border border-slate-200/80 shadow-2xs overflow-hidden flex flex-col justify-between hover:border-slate-300 transition-all group"
            >
              <div>
                {/* Photo & Status Badge */}
                <div className="relative h-44 bg-slate-100 overflow-hidden">
                  <img
                    src={prop.imageUrl || '/src/assets/images/darimmo_hero_property_1793803599938.jpg'}
                    alt={prop.title}
                    referrerPolicy="no-referrer"
                    className="w-full h-full object-cover group-hover:scale-102 transition-transform duration-300"
                  />
                  <div className="absolute top-3 left-3">
                    {statusBadge(prop.status)}
                  </div>
                  <div className="absolute top-3 right-3 bg-slate-900/80 backdrop-blur-xs text-white text-[11px] font-semibold px-2.5 py-1 rounded-md">
                    {prop.type}
                  </div>
                </div>

                {/* Details */}
                <div className="p-4 space-y-2">
                  <div className="flex items-start justify-between gap-2">
                    <h3 className="font-bold text-slate-900 text-sm leading-snug line-clamp-1">
                      {prop.title}
                    </h3>
                  </div>

                  <p className="text-xs text-slate-500 flex items-center gap-1.5 line-clamp-1">
                    <MapPin className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                    <span>{prop.neighborhood}, {prop.address}</span>
                  </p>

                  <div className="flex items-center gap-3 pt-2 text-xs text-slate-600">
                    <span>{prop.rooms} pièces</span>
                    <span className="text-slate-300">·</span>
                    <span>{prop.surface} m²</span>
                    <span className="text-slate-300">·</span>
                    <span>{prop.city}</span>
                  </div>

                  <div className="pt-3 border-t border-slate-100 flex items-baseline justify-between">
                    <div>
                      <span className="text-[10px] text-slate-400 block">Loyer mensuel</span>
                      <span className="text-base font-bold text-slate-900 font-mono">
                        {prop.monthlyRent.toLocaleString('fr-FR')} <span className="text-xs font-normal text-slate-500">FCFA</span>
                      </span>
                    </div>
                    {prop.charges && prop.charges > 0 ? (
                      <span className="text-[11px] text-slate-500 font-mono">
                        +{prop.charges.toLocaleString('fr-FR')} F ch.
                      </span>
                    ) : null}
                  </div>
                </div>
              </div>

              {/* Actions Footer */}
              <div className="px-4 py-3 bg-slate-50/80 border-t border-slate-100 flex items-center justify-between text-xs">
                <button
                  type="button"
                  onClick={() => onViewProperty(prop)}
                  className="font-medium text-slate-700 hover:text-emerald-700 flex items-center gap-1 cursor-pointer"
                >
                  <Eye className="w-3.5 h-3.5" />
                  <span>Détails</span>
                </button>
                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={() => onEditProperty(prop)}
                    className="p-1.5 text-slate-500 hover:text-emerald-700 rounded-lg hover:bg-slate-200/50 cursor-pointer"
                    title="Modifier"
                  >
                    <Edit3 className="w-4 h-4" />
                  </button>
                  <button
                    type="button"
                    onClick={() => setPropertyToDelete(prop)}
                    className="p-1.5 text-slate-400 hover:text-rose-600 rounded-lg hover:bg-slate-200/50 cursor-pointer"
                    title="Supprimer"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      ) : (
        /* Table View */
        <div className="bg-white rounded-2xl border border-slate-200/80 shadow-2xs overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-50 text-slate-500 border-b border-slate-100">
                <tr>
                  <th className="py-3 px-4 font-semibold">Bien</th>
                  <th className="py-3 px-4 font-semibold">Type</th>
                  <th className="py-3 px-4 font-semibold">Quartier & Adresse</th>
                  <th className="py-3 px-4 font-semibold">Surface / Pièces</th>
                  <th className="py-3 px-4 font-semibold">Loyer (FCFA)</th>
                  <th className="py-3 px-4 font-semibold">Statut</th>
                  <th className="py-3 px-4 font-semibold text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {paginatedItems.map(prop => (
                  <tr key={prop.id} className="hover:bg-slate-50/60 transition-colors">
                    <td className="py-3 px-4 font-semibold text-slate-900">
                      {prop.title}
                    </td>
                    <td className="py-3 px-4 text-slate-600">{prop.type}</td>
                    <td className="py-3 px-4 text-slate-600">{prop.neighborhood}, {prop.address}</td>
                    <td className="py-3 px-4 text-slate-600">{prop.surface} m² · {prop.rooms} p.</td>
                    <td className="py-3 px-4 font-mono font-bold text-slate-900">
                      {prop.monthlyRent.toLocaleString('fr-FR')}
                    </td>
                    <td className="py-3 px-4">{statusBadge(prop.status)}</td>
                    <td className="py-3 px-4 text-right">
                      <div className="inline-flex items-center gap-1">
                        <button
                          type="button"
                          onClick={() => onEditProperty(prop)}
                          className="p-1 text-slate-500 hover:text-emerald-700"
                        >
                          <Edit3 className="w-4 h-4" />
                        </button>
                        <button
                          type="button"
                          onClick={() => setPropertyToDelete(prop)}
                          className="p-1 text-slate-400 hover:text-rose-600"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Real Pagination */}
      {filtered.length > 0 && (
        <Pagination
          currentPage={currentPage}
          totalItems={filtered.length}
          pageSize={pageSize}
          onPageChange={setCurrentPage}
          onPageSizeChange={(newSize) => {
            setPageSize(newSize);
            setCurrentPage(1);
          }}
        />
      )}

      {/* Delete Confirmation Modal */}
      {propertyToDelete && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/60 backdrop-blur-xs">
          <div className="bg-white rounded-2xl shadow-xl border border-slate-200 max-w-sm w-full p-6 text-center animate-in fade-in zoom-in-95">
            <div className="w-12 h-12 rounded-full bg-rose-50 text-rose-600 flex items-center justify-center mx-auto mb-4">
              <Trash2 className="w-6 h-6" />
            </div>
            <h3 className="font-bold text-slate-900 text-sm mb-1">
              Confirmer la suppression
            </h3>
            <p className="text-xs text-slate-500 mb-6 leading-relaxed">
              Êtes-vous certain de vouloir supprimer le bien <strong>« {propertyToDelete.title} »</strong> ? Les contrats et historiques associés seront conservés dans vos archives.
            </p>
            <div className="flex gap-2">
              <button
                type="button"
                onClick={() => setPropertyToDelete(null)}
                className="flex-1 py-2 px-3 text-xs font-semibold rounded-lg border border-slate-200 text-slate-600 hover:bg-slate-50 transition-colors"
              >
                Annuler
              </button>
              <button
                type="button"
                onClick={confirmDelete}
                className="flex-1 py-2 px-3 text-xs font-semibold rounded-lg bg-rose-600 hover:bg-rose-700 text-white transition-colors"
              >
                Supprimer
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
