import React from 'react';
import { Wrench, Shield, Clock, Phone, Mail, MessageSquare, Lock, ArrowRight } from 'lucide-react';

interface MaintenancePageProps {
  message?: string;
  expectedEnd?: string;
  onAdminLogin: () => void;
}

export const MaintenancePage: React.FC<MaintenancePageProps> = ({
  message = "Nous procédons actuellement à une opération de maintenance et d'optimisation des bases de données de DARIMMO pour vous garantir un service toujours plus rapide et sécurisé au Niger.",
  expectedEnd = "Rétablissement imminent sous peu (Heure de Niamey)",
  onAdminLogin
}) => {
  const whatsappUrl = `https://wa.me/22790123456?text=${encodeURIComponent(
    "Bonjour équipe d'assistance DARIMMO,\n\nJe vous contacte suite à l'écran de maintenance sur la plateforme. Pouvez-vous me renseigner sur le rétablissement de mon accès ?"
  )}`;

  return (
    <div className="min-h-screen bg-slate-950 text-white flex flex-col items-center justify-center p-4 sm:p-6 selection:bg-emerald-500 selection:text-slate-950 relative overflow-hidden">
      {/* Background ambient lighting */}
      <div className="absolute top-1/4 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] rounded-full bg-emerald-600/10 blur-[140px] pointer-events-none" />
      <div className="absolute -bottom-20 -right-20 w-80 h-80 rounded-full bg-amber-500/10 blur-[100px] pointer-events-none" />

      <div className="relative z-10 max-w-xl w-full bg-slate-900/90 border border-slate-800 rounded-3xl p-6 sm:p-10 text-center shadow-2xl backdrop-blur-md space-y-6 animate-in fade-in zoom-in-95">
        
        {/* Emblem with animated pulse */}
        <div className="relative inline-block mx-auto">
          <div className="absolute -inset-2 rounded-2xl bg-amber-500/20 blur-md animate-pulse" />
          <div className="relative w-16 h-16 rounded-2xl bg-gradient-to-br from-amber-500/20 to-amber-600/10 text-amber-400 border border-amber-500/30 flex items-center justify-center shadow-inner">
            <Wrench className="w-8 h-8 text-amber-400" />
          </div>
        </div>

        {/* Status Badge & Title */}
        <div className="space-y-2">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-amber-500/10 border border-amber-500/30 text-amber-300 text-xs font-semibold">
            <span className="w-2 h-2 rounded-full bg-amber-400 animate-ping" />
            <span>Mode Maintenance Temporaire</span>
          </div>

          <h1 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
            Plateforme en Cours d'Optimisation
          </h1>
          <p className="text-xs text-emerald-400 font-medium">
            DARIMMO — SaaS Immobilier Niger
          </p>
        </div>

        {/* Polite Message */}
        <div className="p-4 rounded-2xl bg-slate-800/70 border border-slate-700/60 text-xs sm:text-sm text-slate-300 leading-relaxed text-balance">
          {message}
        </div>

        {/* Expected Time */}
        <div className="p-3.5 rounded-xl bg-slate-950/70 border border-slate-800 text-xs text-slate-300 flex items-center justify-center gap-2">
          <Clock className="w-4 h-4 text-emerald-400 shrink-0" />
          <span>Fin d'intervention estimée : <strong className="text-white font-mono">{expectedEnd}</strong></span>
        </div>

        {/* WhatsApp Assistance Button (Emergency Contact) */}
        <div className="pt-2">
          <a
            href={whatsappUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="w-full inline-flex items-center justify-center gap-2.5 py-3 px-5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs shadow-lg shadow-emerald-950/50 transition-all cursor-pointer group"
          >
            <MessageSquare className="w-4 h-4 text-white fill-white/20" />
            <span>Assistance d'urgence par WhatsApp (+227 90 12 34 56)</span>
            <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-0.5 transition-transform" />
          </a>
          <p className="text-[11px] text-slate-400 mt-2">
            Notre équipe technique à Niamey reste joignable pour toute question urgente sur vos loyers.
          </p>
        </div>

        {/* Standard Contact Info */}
        <div className="pt-4 border-t border-slate-800 text-xs text-slate-400 flex flex-wrap items-center justify-center gap-4 text-[11px]">
          <a href="tel:+22790123456" className="hover:text-emerald-400 flex items-center gap-1 font-mono transition-colors">
            <Phone className="w-3.5 h-3.5 text-slate-500" /> +227 90 12 34 56
          </a>
          <span className="text-slate-700">·</span>
          <a href="mailto:support@darimmo.ne" className="hover:text-emerald-400 flex items-center gap-1 transition-colors">
            <Mail className="w-3.5 h-3.5 text-slate-500" /> support@darimmo.ne
          </a>
        </div>

        {/* Admin Unlock Access */}
        <div className="pt-2 border-t border-slate-800/60">
          <button
            type="button"
            onClick={onAdminLogin}
            className="inline-flex items-center gap-1.5 text-[11px] text-slate-400 hover:text-slate-200 transition-colors cursor-pointer"
          >
            <Lock className="w-3 h-3 text-slate-500" />
            <span>Connexion Administrateur / Déverrouiller le système</span>
          </button>
        </div>

      </div>
    </div>
  );
};
