import React, { useState, useEffect } from 'react';
import { X, FileText, Calendar, Building, DollarSign, User, AlertCircle } from 'lucide-react';
import { Lease, Property, Tenant } from '../../types';

interface LeaseModalProps {
  isOpen: boolean;
  lease: Lease | null;
  properties: Property[];
  tenants: Tenant[];
  onClose: () => void;
  onSave: (lease: Lease) => void;
  organizationId: string;
}

export const LeaseModal: React.FC<LeaseModalProps> = ({
  isOpen,
  lease,
  properties,
  tenants,
  onClose,
  onSave,
  organizationId
}) => {
  const [tenantId, setTenantId] = useState('');
  const [propertyId, setPropertyId] = useState('');
  const [startDate, setStartDate] = useState('2026-01-01');
  const [endDate, setEndDate] = useState('2026-12-31');
  const [monthlyRent, setMonthlyRent] = useState(250000);
  const [deposit, setDeposit] = useState(500000);
  const [paymentDueDay, setPaymentDueDay] = useState(5);
  const [status, setStatus] = useState<'actif' | 'expire' | 'resilie'>('actif');
  const [clauses, setClauses] = useState<string[]>([
    'Le loyer est payable d’avance au plus tard le 5 de chaque mois.',
    'La caution ne peut en aucun cas se substituer au paiement d’un terme de loyer.',
    'Sous-location strictement interdite sans consentement écrit préalable du bailleur.',
    'Le présent contrat est soumis au droit en vigueur en République du Niger.'
  ]);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (lease) {
      setTenantId(lease.tenantId);
      setPropertyId(lease.propertyId);
      setStartDate(lease.startDate);
      setEndDate(lease.endDate);
      setMonthlyRent(lease.monthlyRent);
      setDeposit(lease.deposit);
      setPaymentDueDay(lease.paymentDueDay);
      setStatus(lease.status);
      setClauses(lease.clauses);
    } else {
      setTenantId(tenants[0]?.id || '');
      setPropertyId(properties[0]?.id || '');
      setStartDate(new Date().toISOString().split('T')[0]);
      
      const nextYear = new Date();
      nextYear.setFullYear(nextYear.getFullYear() + 1);
      setEndDate(nextYear.toISOString().split('T')[0]);

      setMonthlyRent(properties[0]?.monthlyRent || 250000);
      setDeposit((properties[0]?.monthlyRent || 250000) * 2);
      setPaymentDueDay(5);
      setStatus('actif');
    }
    setError(null);
  }, [lease, tenants, properties, isOpen]);

  if (!isOpen) return null;

  const handlePropertySelect = (pId: string) => {
    setPropertyId(pId);
    const p = properties.find(prop => prop.id === pId);
    if (p) {
      setMonthlyRent(p.monthlyRent);
      setDeposit(p.monthlyRent * 2);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!tenantId || !propertyId) {
      setError('Veuillez sélectionner un locataire et un bien immobilier.');
      return;
    }

    const tenant = tenants.find(t => t.id === tenantId);
    const property = properties.find(p => p.id === propertyId);

    const saved: Lease = {
      id: lease ? lease.id : `lease_${Date.now()}`,
      organizationId,
      leaseNumber: lease ? lease.leaseNumber : `BAIL-DAR-${Date.now().toString().slice(-4)}`,
      tenantId,
      tenantName: tenant ? tenant.fullName : 'Locataire non spécifié',
      propertyId,
      propertyTitle: property ? `${property.title} (${property.neighborhood})` : 'Bien non spécifié',
      startDate,
      endDate,
      monthlyRent: Number(monthlyRent),
      deposit: Number(deposit),
      paymentDueDay: Number(paymentDueDay),
      clauses,
      status,
      createdAt: lease ? lease.createdAt : new Date().toISOString()
    };

    onSave(saved);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/60 backdrop-blur-xs overflow-y-auto">
      <div className="bg-white rounded-2xl shadow-2xl border border-slate-200 max-w-lg w-full overflow-hidden my-6 animate-in fade-in zoom-in-95">
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-100 bg-slate-50">
          <div className="flex items-center gap-2">
            <FileText className="w-5 h-5 text-emerald-700" />
            <h3 className="font-bold text-slate-900 text-sm sm:text-base">
              {lease ? 'Modifier le Bail / Contrat de Location' : 'Générer un Nouveau Bail de Location'}
            </h3>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-slate-600 rounded-lg hover:bg-slate-200/50"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-4 text-xs">
          {error && (
            <div className="p-3 rounded-lg bg-rose-50 border border-rose-200 text-rose-700 flex items-center gap-2">
              <AlertCircle className="w-4 h-4 shrink-0" />
              <span>{error}</span>
            </div>
          )}

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block font-semibold text-slate-700 mb-1">
                Locataire signataire *
              </label>
              <select
                required
                value={tenantId}
                onChange={(e) => setTenantId(e.target.value)}
                className="w-full px-3 py-2 rounded-lg border border-slate-200 focus:outline-hidden focus:ring-1 focus:ring-emerald-500 text-xs bg-white"
              >
                <option value="">Sélectionnez le locataire...</option>
                {tenants.map(t => (
                  <option key={t.id} value={t.id}>{t.fullName}</option>
                ))}
              </select>
            </div>

            <div>
              <label className="block font-semibold text-slate-700 mb-1">
                Bien loué *
              </label>
              <select
                required
                value={propertyId}
                onChange={(e) => handlePropertySelect(e.target.value)}
                className="w-full px-3 py-2 rounded-lg border border-slate-200 focus:outline-hidden focus:ring-1 focus:ring-emerald-500 text-xs bg-white"
              >
                <option value="">Sélectionnez le bien...</option>
                {properties.map(p => (
                  <option key={p.id} value={p.id}>{p.title} ({p.neighborhood})</option>
                ))}
              </select>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block font-semibold text-slate-700 mb-1">
                Date de début du bail
              </label>
              <input
                type="date"
                required
                value={startDate}
                onChange={(e) => setStartDate(e.target.value)}
                className="w-full px-3 py-2 rounded-lg border border-slate-200 focus:outline-hidden focus:ring-1 focus:ring-emerald-500 text-xs"
              />
            </div>

            <div>
              <label className="block font-semibold text-slate-700 mb-1">
                Date de fin (terme du bail)
              </label>
              <input
                type="date"
                required
                value={endDate}
                onChange={(e) => setEndDate(e.target.value)}
                className="w-full px-3 py-2 rounded-lg border border-slate-200 focus:outline-hidden focus:ring-1 focus:ring-emerald-500 text-xs"
              />
            </div>
          </div>

          <div className="grid grid-cols-3 gap-3">
            <div>
              <label className="block font-semibold text-slate-700 mb-1">
                Loyer mensuel (FCFA) *
              </label>
              <input
                type="number"
                step={5000}
                required
                value={monthlyRent}
                onChange={(e) => setMonthlyRent(Number(e.target.value))}
                className="w-full px-2.5 py-2 rounded-lg border border-slate-200 focus:outline-hidden focus:ring-1 focus:ring-emerald-500 text-xs font-mono font-bold text-emerald-800"
              />
            </div>

            <div>
              <label className="block font-semibold text-slate-700 mb-1">
                Caution (FCFA) *
              </label>
              <input
                type="number"
                step={10000}
                required
                value={deposit}
                onChange={(e) => setDeposit(Number(e.target.value))}
                className="w-full px-2.5 py-2 rounded-lg border border-slate-200 focus:outline-hidden focus:ring-1 focus:ring-emerald-500 text-xs font-mono"
              />
            </div>

            <div>
              <label className="block font-semibold text-slate-700 mb-1">
                Échéance (Jour max)
              </label>
              <input
                type="number"
                min={1}
                max={31}
                value={paymentDueDay}
                onChange={(e) => setPaymentDueDay(Number(e.target.value))}
                className="w-full px-2.5 py-2 rounded-lg border border-slate-200 focus:outline-hidden focus:ring-1 focus:ring-emerald-500 text-xs font-mono"
              />
            </div>
          </div>

          <div>
            <label className="block font-semibold text-slate-700 mb-1">
              Clauses particulières & obligations
            </label>
            <div className="p-3 bg-slate-50 rounded-xl space-y-1.5 text-[11px] text-slate-600 border border-slate-100">
              {clauses.map((c, i) => (
                <p key={i} className="flex items-start gap-1.5">
                  <span className="text-emerald-700 font-bold">•</span>
                  <span>{c}</span>
                </p>
              ))}
            </div>
          </div>

          <div className="flex justify-end gap-2 pt-3 border-t border-slate-100">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 rounded-lg border border-slate-200 text-slate-600 hover:bg-slate-50 transition-colors font-medium text-xs cursor-pointer"
            >
              Annuler
            </button>
            <button
              type="submit"
              className="px-4 py-2 rounded-lg bg-emerald-700 hover:bg-emerald-800 text-white font-semibold text-xs transition-colors cursor-pointer"
            >
              {lease ? 'Enregistrer les modifications' : 'Éditer & Signer le Bail'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
