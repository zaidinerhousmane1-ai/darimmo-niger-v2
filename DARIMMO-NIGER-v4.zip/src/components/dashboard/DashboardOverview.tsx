import React from 'react';
import { 
  Building2, 
  Users, 
  Receipt, 
  TrendingDown, 
  Wrench, 
  FileText, 
  ArrowUpRight, 
  ArrowDownRight, 
  CheckCircle2, 
  Clock, 
  AlertTriangle, 
  Calendar as CalendarIcon, 
  DollarSign, 
  Plus, 
  ChevronRight,
  TrendingUp,
  Sparkles
} from 'lucide-react';
import { 
  Property, 
  Tenant, 
  RentPayment, 
  Expense, 
  RepairTicket, 
  SubscriptionState 
} from '../../types';

interface DashboardOverviewProps {
  properties: Property[];
  tenants: Tenant[];
  payments: RentPayment[];
  expenses: Expense[];
  repairs: RepairTicket[];
  subscription: SubscriptionState;
  onNavigate: (view: string) => void;
  onOpenAddProperty: () => void;
  onOpenAddTenant: () => void;
  onOpenCollectRent: () => void;
  onOpenAddExpense: () => void;
  onOpenAddRepair: () => void;
  onViewReceipt: (payment: RentPayment) => void;
}

export const DashboardOverview: React.FC<DashboardOverviewProps> = ({
  properties,
  tenants,
  payments,
  expenses,
  repairs,
  subscription,
  onNavigate,
  onOpenAddProperty,
  onOpenAddTenant,
  onOpenCollectRent,
  onOpenAddExpense,
  onOpenAddRepair,
  onViewReceipt
}) => {
  // Calculations
  const totalProperties = properties.length;
  const occupiedProperties = properties.filter(p => p.status === 'occupe').length;
  const occupancyRate = totalProperties > 0 ? Math.round((occupiedProperties / totalProperties) * 100) : 0;

  // Monthly financials (Mars 2026)
  const currentMonthPayments = payments.filter(p => p.periodMonth.toLowerCase().includes('mars'));
  const totalExpectedRent = currentMonthPayments.reduce((acc, p) => acc + p.amountExpected, 0);
  const totalCollectedRent = currentMonthPayments.reduce((acc, p) => acc + p.amountPaid, 0);
  const totalOverdueRent = currentMonthPayments
    .filter(p => p.status === 'retard' || (p.amountPaid < p.amountExpected))
    .reduce((acc, p) => acc + (p.amountExpected - p.amountPaid), 0);

  const currentMonthExpenses = expenses.reduce((acc, e) => acc + e.amount, 0);
  const netIncome = totalCollectedRent - currentMonthExpenses;

  // Pending repairs
  const pendingRepairs = repairs.filter(r => r.status !== 'resolu');

  // Trial countdown
  const trialEnd = new Date(subscription.trialEndsAt);
  const now = new Date();
  const trialDaysRemaining = Math.max(0, Math.ceil((trialEnd.getTime() - now.getTime()) / (1000 * 60 * 60 * 24)));

  return (
    <div className="space-y-6 max-w-7xl mx-auto pb-12">
      {/* Trial Reminder Banner if in trial */}
      {subscription.status === 'trial' && (
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 p-4 rounded-xl bg-gradient-to-r from-emerald-900 to-slate-900 text-white shadow-sm border border-emerald-800/40">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-lg bg-emerald-500/20 text-emerald-400 flex items-center justify-center shrink-0 border border-emerald-500/30">
              <Sparkles className="w-5 h-5" />
            </div>
            <div>
              <p className="text-xs font-semibold text-emerald-300 uppercase tracking-wider">
                Période d'Essai Gratuit DARIMMO PRO (14 Jours)
              </p>
              <p className="text-sm font-medium text-slate-200">
                Il vous reste <strong className="text-white font-mono">{trialDaysRemaining} jours</strong> pour profiter sans frais des quittances illimitées et de toutes les fonctionnalités avancées.
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={() => onNavigate('subscription')}
            className="px-4 py-2 bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-semibold text-xs rounded-lg transition-colors whitespace-nowrap cursor-pointer shrink-0"
          >
            Choisir mon abonnement
          </button>
        </div>
      )}

      {/* Top Action Tiles (Directly inspired by Reference Screenshot 1) */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
        <button
          type="button"
          onClick={onOpenAddProperty}
          className="p-3.5 bg-white hover:bg-slate-50/80 rounded-xl border border-slate-200/80 shadow-2xs flex flex-col items-center text-center gap-2 transition-all hover:border-emerald-300 group cursor-pointer"
        >
          <div className="w-10 h-10 rounded-xl bg-blue-50 text-blue-600 flex items-center justify-center group-hover:scale-105 transition-transform">
            <Building2 className="w-5 h-5" />
          </div>
          <span className="text-xs font-semibold text-slate-800">Ajouter un bien</span>
        </button>

        <button
          type="button"
          onClick={onOpenAddTenant}
          className="p-3.5 bg-white hover:bg-slate-50/80 rounded-xl border border-slate-200/80 shadow-2xs flex flex-col items-center text-center gap-2 transition-all hover:border-emerald-300 group cursor-pointer"
        >
          <div className="w-10 h-10 rounded-xl bg-purple-50 text-purple-600 flex items-center justify-center group-hover:scale-105 transition-transform">
            <Users className="w-5 h-5" />
          </div>
          <span className="text-xs font-semibold text-slate-800">Nouveau locataire</span>
        </button>

        <button
          type="button"
          onClick={onOpenCollectRent}
          className="p-3.5 bg-white hover:bg-slate-50/80 rounded-xl border border-slate-200/80 shadow-2xs flex flex-col items-center text-center gap-2 transition-all hover:border-emerald-300 group cursor-pointer"
        >
          <div className="w-10 h-10 rounded-xl bg-emerald-50 text-emerald-700 flex items-center justify-center group-hover:scale-105 transition-transform">
            <Receipt className="w-5 h-5" />
          </div>
          <span className="text-xs font-semibold text-slate-800">Encaisser un loyer</span>
        </button>

        <button
          type="button"
          onClick={onOpenAddExpense}
          className="p-3.5 bg-white hover:bg-slate-50/80 rounded-xl border border-slate-200/80 shadow-2xs flex flex-col items-center text-center gap-2 transition-all hover:border-emerald-300 group cursor-pointer"
        >
          <div className="w-10 h-10 rounded-xl bg-amber-50 text-amber-600 flex items-center justify-center group-hover:scale-105 transition-transform">
            <TrendingDown className="w-5 h-5" />
          </div>
          <span className="text-xs font-semibold text-slate-800">Déclarer dépense</span>
        </button>

        <button
          type="button"
          onClick={onOpenAddRepair}
          className="p-3.5 bg-white hover:bg-slate-50/80 rounded-xl border border-slate-200/80 shadow-2xs flex flex-col items-center text-center gap-2 transition-all hover:border-emerald-300 group cursor-pointer"
        >
          <div className="w-10 h-10 rounded-xl bg-rose-50 text-rose-600 flex items-center justify-center group-hover:scale-105 transition-transform">
            <Wrench className="w-5 h-5" />
          </div>
          <span className="text-xs font-semibold text-slate-800">Signaler travaux</span>
        </button>

        <button
          type="button"
          onClick={() => onNavigate('rents')}
          className="p-3.5 bg-white hover:bg-slate-50/80 rounded-xl border border-slate-200/80 shadow-2xs flex flex-col items-center text-center gap-2 transition-all hover:border-emerald-300 group cursor-pointer"
        >
          <div className="w-10 h-10 rounded-xl bg-indigo-50 text-indigo-600 flex items-center justify-center group-hover:scale-105 transition-transform">
            <FileText className="w-5 h-5" />
          </div>
          <span className="text-xs font-semibold text-slate-800">Quittances PDF</span>
        </button>
      </div>

      {/* KPI Cards Row (Tabular figures) */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* KPI 1: Loyers Encaissés */}
        <div className="p-5 rounded-2xl bg-white border border-slate-200/80 shadow-2xs">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs font-medium text-slate-500">Loyers Encaissés (Mars)</span>
            <div className="w-8 h-8 rounded-lg bg-emerald-50 text-emerald-700 flex items-center justify-center">
              <ArrowUpRight className="w-4 h-4" />
            </div>
          </div>
          <div className="flex items-baseline gap-1.5">
            <span className="text-2xl font-bold text-slate-900 font-mono tracking-tight">
              {totalCollectedRent.toLocaleString('fr-FR')}
            </span>
            <span className="text-xs font-semibold text-slate-500">FCFA</span>
          </div>
          <p className="text-[11px] text-emerald-700 font-medium mt-1.5 flex items-center gap-1">
            <span>Attendu : {totalExpectedRent.toLocaleString('fr-FR')} FCFA</span>
          </p>
        </div>

        {/* KPI 2: Impayés / Retards */}
        <div className="p-5 rounded-2xl bg-white border border-slate-200/80 shadow-2xs">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs font-medium text-slate-500">Loyers en Attente / Retard</span>
            <div className="w-8 h-8 rounded-lg bg-rose-50 text-rose-600 flex items-center justify-center">
              <Clock className="w-4 h-4" />
            </div>
          </div>
          <div className="flex items-baseline gap-1.5">
            <span className="text-2xl font-bold text-rose-600 font-mono tracking-tight">
              {totalOverdueRent.toLocaleString('fr-FR')}
            </span>
            <span className="text-xs font-semibold text-slate-500">FCFA</span>
          </div>
          <p className="text-[11px] text-slate-500 mt-1.5">
            1 échéance en retard sur Mars 2026
          </p>
        </div>

        {/* KPI 3: Dépenses & Entretien */}
        <div className="p-5 rounded-2xl bg-white border border-slate-200/80 shadow-2xs">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs font-medium text-slate-500">Dépenses Cumulées</span>
            <div className="w-8 h-8 rounded-lg bg-amber-50 text-amber-600 flex items-center justify-center">
              <TrendingDown className="w-4 h-4" />
            </div>
          </div>
          <div className="flex items-baseline gap-1.5">
            <span className="text-2xl font-bold text-slate-900 font-mono tracking-tight">
              {currentMonthExpenses.toLocaleString('fr-FR')}
            </span>
            <span className="text-xs font-semibold text-slate-500">FCFA</span>
          </div>
          <p className="text-[11px] text-slate-500 mt-1.5">
            Gardiennage, travaux et plomberie
          </p>
        </div>

        {/* KPI 4: Taux d'Occupation */}
        <div className="p-5 rounded-2xl bg-white border border-slate-200/80 shadow-2xs">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs font-medium text-slate-500">Taux d'Occupation</span>
            <div className="w-8 h-8 rounded-lg bg-blue-50 text-blue-600 flex items-center justify-center">
              <Building2 className="w-4 h-4" />
            </div>
          </div>
          <div className="flex items-baseline gap-1.5">
            <span className="text-2xl font-bold text-slate-900 font-mono tracking-tight">
              {occupancyRate}%
            </span>
            <span className="text-xs font-semibold text-slate-500">
              ({occupiedProperties} / {totalProperties} biens)
            </span>
          </div>
          <div className="w-full bg-slate-100 h-1.5 rounded-full mt-2.5 overflow-hidden">
            <div 
              className="bg-emerald-600 h-full rounded-full transition-all duration-500" 
              style={{ width: `${occupancyRate}%` }}
            />
          </div>
        </div>
      </div>

      {/* Middle Grid: Noticeboard / Alertes & Échéances (inspired by Reference Screenshot 1) */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Noticeboard & Recent Alerts (7 cols) */}
        <div className="lg:col-span-7 bg-white rounded-2xl border border-slate-200/80 shadow-2xs p-5 space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-slate-100">
            <div className="flex items-center gap-2">
              <div className="w-2 h-2 rounded-full bg-emerald-600" />
              <h3 className="text-sm font-bold text-slate-900">
                Tableau d'Affichage & Alertes Échéances
              </h3>
            </div>
            <span className="text-xs text-slate-400 font-mono">Niamey · GMT+1</span>
          </div>

          <div className="space-y-3">
            {/* Alert 1: Overdue Rent */}
            <div className="p-3.5 rounded-xl bg-rose-50/70 border border-rose-100 flex items-start justify-between gap-3">
              <div className="flex items-start gap-3">
                <div className="w-8 h-8 rounded-lg bg-rose-100 text-rose-700 flex items-center justify-center shrink-0 mt-0.5">
                  <AlertTriangle className="w-4 h-4" />
                </div>
                <div>
                  <h4 className="text-xs font-bold text-rose-900">
                    Loyer de Mars en retard · Boutique Grand Marché
                  </h4>
                  <p className="text-[11px] text-rose-700 mt-0.5 leading-snug">
                    Locataire : <strong>Elhadj Mamane Sani</strong> · Montant : <strong className="font-mono">280 000 FCFA</strong> (échéance le 01/03/2026).
                  </p>
                </div>
              </div>
              <div className="flex items-center gap-1.5 shrink-0">
                <a
                  href={`https://wa.me/?text=${encodeURIComponent("Bonjour Elhadj Mamane Sani,\n\nSauf erreur de notre part, votre loyer de Mars 2026 pour le local commercial (Grand Marché) d'un montant de 280 000 FCFA est en retard. Merci de procéder au règlement via Airtel Money, Nita ou Amana. DARIMMO")}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="px-2.5 py-1.5 bg-emerald-100/90 hover:bg-emerald-200 text-emerald-900 border border-emerald-300 rounded-lg text-xs font-semibold shrink-0 cursor-pointer transition-colors inline-flex items-center gap-1"
                  title="Ouvrir WhatsApp avec message pré-rempli"
                >
                  <span>Relancer WhatsApp</span>
                </a>
                <button
                  type="button"
                  onClick={onOpenCollectRent}
                  className="px-3 py-1.5 bg-rose-700 hover:bg-rose-800 text-white rounded-lg text-xs font-semibold shrink-0 cursor-pointer transition-colors"
                >
                  Encaisser
                </button>
              </div>
            </div>

            {/* Alert 2: Maintenance Notice */}
            <div className="p-3.5 rounded-xl bg-amber-50/70 border border-amber-100 flex items-start justify-between gap-3">
              <div className="flex items-start gap-3">
                <div className="w-8 h-8 rounded-lg bg-amber-100 text-amber-700 flex items-center justify-center shrink-0 mt-0.5">
                  <Wrench className="w-4 h-4" />
                </div>
                <div>
                  <h4 className="text-xs font-bold text-amber-900">
                    Intervention en cours · Baisse de pression d'eau
                  </h4>
                  <p className="text-[11px] text-amber-700 mt-0.5 leading-snug">
                    Appartement F4 Résidence Sahel (Dr. Fatouma Abdoulaye) · Technicien surpresseur assigné.
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => onNavigate('repairs')}
                className="px-3 py-1.5 bg-amber-700 hover:bg-amber-800 text-white rounded-lg text-xs font-semibold shrink-0 cursor-pointer transition-colors"
              >
                Suivre
              </button>
            </div>

            {/* Alert 3: Successful Rent */}
            <div className="p-3.5 rounded-xl bg-emerald-50/70 border border-emerald-100 flex items-start justify-between gap-3">
              <div className="flex items-start gap-3">
                <div className="w-8 h-8 rounded-lg bg-emerald-100 text-emerald-800 flex items-center justify-center shrink-0 mt-0.5">
                  <CheckCircle2 className="w-4 h-4" />
                </div>
                <div>
                  <h4 className="text-xs font-bold text-emerald-950">
                    Loyer Villa Plateau reçu · Virement BOA
                  </h4>
                  <p className="text-[11px] text-emerald-800 mt-0.5 leading-snug">
                    Locataire : <strong>Ibrahim Moussa</strong> · Montant : <strong className="font-mono">650 000 FCFA</strong> · Quittance émise.
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => {
                  const p = payments.find(pay => pay.id === 'pay_1');
                  if (p) onViewReceipt(p);
                }}
                className="px-3 py-1.5 bg-emerald-800 hover:bg-emerald-900 text-white rounded-lg text-xs font-semibold shrink-0 cursor-pointer transition-colors"
              >
                Voir Quittance
              </button>
            </div>
          </div>
        </div>

        {/* Right Schedule & Mini Calendar (5 cols) */}
        <div className="lg:col-span-5 bg-white rounded-2xl border border-slate-200/80 shadow-2xs p-5 flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between pb-3 border-b border-slate-100 mb-4">
              <div className="flex items-center gap-2">
                <CalendarIcon className="w-4 h-4 text-emerald-700" />
                <h3 className="text-sm font-bold text-slate-900">Échéancier & Calendrier</h3>
              </div>
              <span className="text-xs font-semibold text-slate-700">Mars 2026</span>
            </div>

            <div className="space-y-2.5 text-xs">
              <div className="flex items-center justify-between p-2.5 rounded-lg bg-slate-50 border border-slate-100">
                <div className="flex items-center gap-2.5">
                  <span className="w-7 h-7 rounded-md bg-white border border-slate-200 font-bold text-slate-700 flex items-center justify-center font-mono">
                    01
                  </span>
                  <div>
                    <p className="font-semibold text-slate-900">Échéance Loyer Boutique</p>
                    <p className="text-[10px] text-slate-500">Grand Marché · 280 000 FCFA</p>
                  </div>
                </div>
                <span className="text-[10px] font-semibold text-rose-600 bg-rose-50 px-2 py-0.5 rounded border border-rose-200">
                  En retard
                </span>
              </div>

              <div className="flex items-center justify-between p-2.5 rounded-lg bg-slate-50 border border-slate-100">
                <div className="flex items-center gap-2.5">
                  <span className="w-7 h-7 rounded-md bg-emerald-100 text-emerald-800 font-bold flex items-center justify-center font-mono">
                    05
                  </span>
                  <div>
                    <p className="font-semibold text-slate-900">Échéance Villa Plateau</p>
                    <p className="text-[10px] text-slate-500">Ibrahim Moussa · 650 000 FCFA</p>
                  </div>
                </div>
                <span className="text-[10px] font-semibold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200">
                  Payé
                </span>
              </div>

              <div className="flex items-center justify-between p-2.5 rounded-lg bg-slate-50 border border-slate-100">
                <div className="flex items-center gap-2.5">
                  <span className="w-7 h-7 rounded-md bg-emerald-100 text-emerald-800 font-bold flex items-center justify-center font-mono">
                    05
                  </span>
                  <div>
                    <p className="font-semibold text-slate-900">Échéance F4 Sahel</p>
                    <p className="text-[10px] text-slate-500">Dr. Fatouma · 350 000 FCFA</p>
                  </div>
                </div>
                <span className="text-[10px] font-semibold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200">
                  Payé
                </span>
              </div>
            </div>
          </div>

          <div className="pt-4 border-t border-slate-100 mt-4 flex items-center justify-between text-xs">
            <span className="text-slate-500">Revenus nets ce mois :</span>
            <span className="font-bold text-slate-900 font-mono text-sm">
              {netIncome.toLocaleString('fr-FR')} FCFA
            </span>
          </div>
        </div>
      </div>

      {/* Financial Category Breakdown (Donut Cards inspired by Reference Screenshot 1) */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {/* Category 1: Revenus par Catégorie de Biens */}
        <div className="bg-white rounded-2xl border border-slate-200/80 shadow-2xs p-5">
          <h4 className="text-xs font-bold text-slate-900 uppercase tracking-wider mb-4">
            Revenus par Type de Bien
          </h4>
          <div className="space-y-3 text-xs">
            <div>
              <div className="flex justify-between font-medium text-slate-700 mb-1">
                <span>Villas & Maisons (Plateau)</span>
                <span className="font-mono font-semibold">650 000 F (65%)</span>
              </div>
              <div className="w-full bg-slate-100 h-2 rounded-full overflow-hidden">
                <div className="bg-emerald-600 h-full rounded-full" style={{ width: '65%' }} />
              </div>
            </div>
            <div>
              <div className="flex justify-between font-medium text-slate-700 mb-1">
                <span>Appartements (Koubia)</span>
                <span className="font-mono font-semibold">350 000 F (35%)</span>
              </div>
              <div className="w-full bg-slate-100 h-2 rounded-full overflow-hidden">
                <div className="bg-blue-600 h-full rounded-full" style={{ width: '35%' }} />
              </div>
            </div>
            <div>
              <div className="flex justify-between font-medium text-slate-700 mb-1">
                <span>Boutiques & Commerces</span>
                <span className="font-mono font-semibold">En attente</span>
              </div>
              <div className="w-full bg-slate-100 h-2 rounded-full overflow-hidden">
                <div className="bg-slate-300 h-full rounded-full" style={{ width: '0%' }} />
              </div>
            </div>
          </div>
        </div>

        {/* Category 2: Dépenses par Catégorie */}
        <div className="bg-white rounded-2xl border border-slate-200/80 shadow-2xs p-5">
          <h4 className="text-xs font-bold text-slate-900 uppercase tracking-wider mb-4">
            Dépenses par Poste
          </h4>
          <div className="space-y-3 text-xs">
            <div>
              <div className="flex justify-between font-medium text-slate-700 mb-1">
                <span>Rénovation & Peinture</span>
                <span className="font-mono font-semibold">145 000 F (55%)</span>
              </div>
              <div className="w-full bg-slate-100 h-2 rounded-full overflow-hidden">
                <div className="bg-amber-600 h-full rounded-full" style={{ width: '55%' }} />
              </div>
            </div>
            <div>
              <div className="flex justify-between font-medium text-slate-700 mb-1">
                <span>Sécurité & Gardiennage</span>
                <span className="font-mono font-semibold">80 000 F (31%)</span>
              </div>
              <div className="w-full bg-slate-100 h-2 rounded-full overflow-hidden">
                <div className="bg-purple-600 h-full rounded-full" style={{ width: '31%' }} />
              </div>
            </div>
            <div>
              <div className="flex justify-between font-medium text-slate-700 mb-1">
                <span>Plomberie & Sanitaire</span>
                <span className="font-mono font-semibold">35 000 F (14%)</span>
              </div>
              <div className="w-full bg-slate-100 h-2 rounded-full overflow-hidden">
                <div className="bg-rose-500 h-full rounded-full" style={{ width: '14%' }} />
              </div>
            </div>
          </div>
        </div>

        {/* Category 3: Modes d'Encaissement */}
        <div className="bg-white rounded-2xl border border-slate-200/80 shadow-2xs p-5">
          <h4 className="text-xs font-bold text-slate-900 uppercase tracking-wider mb-4">
            Modes d'Encaissement (Niger)
          </h4>
          <div className="space-y-3 text-xs">
            <div>
              <div className="flex justify-between font-medium text-slate-700 mb-1">
                <span>Virement Bancaire (BOA)</span>
                <span className="font-mono font-semibold">650 000 F (65%)</span>
              </div>
              <div className="w-full bg-slate-100 h-2 rounded-full overflow-hidden">
                <div className="bg-indigo-600 h-full rounded-full" style={{ width: '65%' }} />
              </div>
            </div>
            <div>
              <div className="flex justify-between font-medium text-slate-700 mb-1">
                <span>Airtel Money Niger</span>
                <span className="font-mono font-semibold">350 000 F (35%)</span>
              </div>
              <div className="w-full bg-slate-100 h-2 rounded-full overflow-hidden">
                <div className="bg-red-600 h-full rounded-full" style={{ width: '35%' }} />
              </div>
            </div>
            <div>
              <div className="flex justify-between font-medium text-slate-700 mb-1">
                <span>Nita & Amana Transfert</span>
                <span className="font-mono font-semibold">Historique actif</span>
              </div>
              <div className="w-full bg-slate-100 h-2 rounded-full overflow-hidden">
                <div className="bg-emerald-500 h-full rounded-full" style={{ width: '25%' }} />
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Recent Rents Table */}
      <div className="bg-white rounded-2xl border border-slate-200/80 shadow-2xs overflow-hidden">
        <div className="flex items-center justify-between p-5 border-b border-slate-100">
          <div>
            <h3 className="text-sm font-bold text-slate-900">Derniers Règlements de Loyer</h3>
            <p className="text-xs text-slate-500">Historique des quittances émises</p>
          </div>
          <button
            type="button"
            onClick={() => onNavigate('rents')}
            className="inline-flex items-center gap-1 text-xs font-semibold text-emerald-700 hover:text-emerald-800 cursor-pointer"
          >
            <span>Voir tout le grand livre</span>
            <ChevronRight className="w-4 h-4" />
          </button>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50 text-slate-500 border-b border-slate-100">
              <tr>
                <th className="py-3 px-4 font-semibold">Quittance</th>
                <th className="py-3 px-4 font-semibold">Locataire</th>
                <th className="py-3 px-4 font-semibold">Bien concerné</th>
                <th className="py-3 px-4 font-semibold">Mois</th>
                <th className="py-3 px-4 font-semibold">Montant (FCFA)</th>
                <th className="py-3 px-4 font-semibold">Statut</th>
                <th className="py-3 px-4 font-semibold text-right">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {payments.slice(0, 5).map(pay => (
                <tr key={pay.id} className="hover:bg-slate-50/60 transition-colors">
                  <td className="py-3 px-4 font-mono font-medium text-slate-800">
                    {pay.receiptNumber}
                  </td>
                  <td className="py-3 px-4 font-medium text-slate-900">
                    {pay.tenantName}
                  </td>
                  <td className="py-3 px-4 text-slate-600 truncate max-w-xs">
                    {pay.propertyTitle}
                  </td>
                  <td className="py-3 px-4 text-slate-600">
                    {pay.periodMonth}
                  </td>
                  <td className="py-3 px-4 font-mono font-semibold text-slate-900">
                    {pay.amountPaid > 0 ? pay.amountPaid.toLocaleString('fr-FR') : pay.amountExpected.toLocaleString('fr-FR')}
                  </td>
                  <td className="py-3 px-4">
                    {pay.status === 'paye' ? (
                      <span className="inline-flex items-center px-2 py-0.5 rounded text-[10px] font-semibold bg-emerald-50 text-emerald-800 border border-emerald-200">
                        Payé
                      </span>
                    ) : (
                      <span className="inline-flex items-center px-2 py-0.5 rounded text-[10px] font-semibold bg-rose-50 text-rose-700 border border-rose-200">
                        En retard
                      </span>
                    )}
                  </td>
                  <td className="py-3 px-4 text-right">
                    {pay.status === 'paye' ? (
                      <button
                        type="button"
                        onClick={() => onViewReceipt(pay)}
                        className="text-xs font-semibold text-emerald-700 hover:text-emerald-800 cursor-pointer"
                      >
                        Quittance PDF
                      </button>
                    ) : (
                      <button
                        type="button"
                        onClick={onOpenCollectRent}
                        className="text-xs font-semibold text-rose-600 hover:text-rose-700 cursor-pointer"
                      >
                        Encaisser
                      </button>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
