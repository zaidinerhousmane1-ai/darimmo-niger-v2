import React, { useState, useMemo } from 'react';
import { TrendingDown, Plus, Search, Edit3, Trash2, Calendar, Tag } from 'lucide-react';
import { Expense } from '../../types';
import { Pagination } from '../common/Pagination';
import { EmptyState } from '../common/EmptyState';

interface ExpensesListProps {
  expenses: Expense[];
  onAddExpense: () => void;
  onEditExpense: (expense: Expense) => void;
  onDeleteExpense: (id: string) => void;
}

export const ExpensesList: React.FC<ExpensesListProps> = ({
  expenses,
  onAddExpense,
  onEditExpense,
  onDeleteExpense
}) => {
  const [search, setSearch] = useState('');
  const [categoryFilter, setCategoryFilter] = useState<string>('all');
  const [expenseToDelete, setExpenseToDelete] = useState<Expense | null>(null);

  // Pagination
  const [currentPage, setCurrentPage] = useState(1);
  const [pageSize, setPageSize] = useState(10);

  const filtered = useMemo(() => {
    return expenses.filter(e => {
      const matchSearch = search.trim() === '' ||
        e.beneficiary.toLowerCase().includes(search.toLowerCase()) ||
        e.description.toLowerCase().includes(search.toLowerCase()) ||
        (e.propertyTitle && e.propertyTitle.toLowerCase().includes(search.toLowerCase()));

      const matchCategory = categoryFilter === 'all' || e.category === categoryFilter;

      return matchSearch && matchCategory;
    });
  }, [expenses, search, categoryFilter]);

  const paginatedItems = useMemo(() => {
    const start = (currentPage - 1) * pageSize;
    return filtered.slice(start, start + pageSize);
  }, [filtered, currentPage, pageSize]);

  const totalAmount = filtered.reduce((acc, e) => acc + e.amount, 0);

  return (
    <div className="space-y-5 max-w-7xl mx-auto pb-12">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold text-slate-900 tracking-tight">Dépenses & Charges Locatives</h2>
          <p className="text-xs text-slate-500 mt-0.5">
            Gardiennage, travaux de réfection, plomberie, électricité et factures d'immeuble.
          </p>
        </div>

        <button
          type="button"
          onClick={onAddExpense}
          className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs font-semibold bg-amber-600 hover:bg-amber-700 text-white shadow-xs transition-colors cursor-pointer self-start sm:self-auto"
        >
          <Plus className="w-4 h-4" />
          <span>Déclarer une dépense</span>
        </button>
      </div>

      {/* Total expense metric card */}
      <div className="p-4 bg-white rounded-2xl border border-slate-200/80 shadow-2xs flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-amber-50 text-amber-700 flex items-center justify-center">
            <TrendingDown className="w-5 h-5" />
          </div>
          <div>
            <span className="text-[10px] font-semibold text-slate-400 uppercase tracking-wider block">
              Total Dépenses Filtrées
            </span>
            <span className="text-xl font-bold text-slate-900 font-mono">
              {totalAmount.toLocaleString('fr-FR')} <span className="text-xs font-normal text-slate-500">FCFA</span>
            </span>
          </div>
        </div>
        <span className="text-xs text-slate-500 font-mono">
          {filtered.length} justificatif(s)
        </span>
      </div>

      {/* Filter and Search Bar */}
      <div className="p-4 bg-white rounded-2xl border border-slate-200/80 shadow-2xs flex flex-col sm:flex-row gap-3 items-stretch sm:items-center justify-between">
        <div className="flex-1 relative">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
          <input
            type="text"
            value={search}
            onChange={(e) => { setSearch(e.target.value); setCurrentPage(1); }}
            placeholder="Rechercher par bénéficiaire, artisan, description..."
            className="w-full pl-9 pr-3 py-2 text-xs rounded-xl border border-slate-200 focus:outline-hidden focus:ring-1 focus:ring-amber-500 bg-slate-50/50"
          />
        </div>

        <div className="flex items-center gap-2">
          <select
            value={categoryFilter}
            onChange={(e) => { setCategoryFilter(e.target.value); setCurrentPage(1); }}
            className="px-3 py-2 text-xs rounded-xl border border-slate-200 bg-white text-slate-700 focus:outline-hidden focus:ring-1 focus:ring-amber-500"
          >
            <option value="all">Toutes les catégories</option>
            <option value="Gardiennage & Sécurité">Gardiennage & Sécurité</option>
            <option value="Maçonnerie & Peinture">Maçonnerie & Peinture</option>
            <option value="Plomberie & Sanitaire">Plomberie & Sanitaire</option>
            <option value="Électricité">Électricité</option>
            <option value="Facture Eau / Nigelec">Facture Eau / Nigelec</option>
            <option value="Taxes & Impôts Fonciers">Taxes & Impôts Fonciers</option>
          </select>
        </div>
      </div>

      {/* Content */}
      {filtered.length === 0 ? (
        <EmptyState
          icon={TrendingDown}
          title="Aucune dépense enregistrée"
          description={
            search || categoryFilter !== 'all'
              ? 'Aucune charge ne correspond à vos filtres.'
              : 'Enregistrez les factures de gardiennage, réparations et taxes de vos biens pour calculer votre rendement net.'
          }
          actionLabel="Enregistrer une première dépense"
          onAction={onAddExpense}
        />
      ) : (
        <div className="bg-white rounded-2xl border border-slate-200/80 shadow-2xs overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-50 text-slate-500 border-b border-slate-100">
                <tr>
                  <th className="py-3 px-4 font-semibold">Date</th>
                  <th className="py-3 px-4 font-semibold">Catégorie</th>
                  <th className="py-3 px-4 font-semibold">Bénéficiaire / Fournisseur</th>
                  <th className="py-3 px-4 font-semibold">Bien Associé</th>
                  <th className="py-3 px-4 font-semibold">Description</th>
                  <th className="py-3 px-4 font-semibold">Montant</th>
                  <th className="py-3 px-4 font-semibold text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {paginatedItems.map(exp => (
                  <tr key={exp.id} className="hover:bg-slate-50/60 transition-colors">
                    <td className="py-3 px-4 font-mono text-slate-600">
                      {exp.date}
                    </td>
                    <td className="py-3 px-4">
                      <span className="px-2 py-0.5 rounded text-[10px] font-semibold bg-slate-100 text-slate-700">
                        {exp.category}
                      </span>
                    </td>
                    <td className="py-3 px-4 font-semibold text-slate-900">
                      {exp.beneficiary}
                    </td>
                    <td className="py-3 px-4 text-slate-600 truncate max-w-xs">
                      {exp.propertyTitle || 'Général'}
                    </td>
                    <td className="py-3 px-4 text-slate-600 max-w-xs truncate">
                      {exp.description}
                    </td>
                    <td className="py-3 px-4 font-mono font-bold text-amber-700">
                      {exp.amount.toLocaleString('fr-FR')} FCFA
                    </td>
                    <td className="py-3 px-4 text-right">
                      <div className="inline-flex items-center gap-1">
                        <button
                          type="button"
                          onClick={() => onEditExpense(exp)}
                          className="p-1 text-slate-500 hover:text-amber-700 rounded-md hover:bg-slate-100"
                        >
                          <Edit3 className="w-4 h-4" />
                        </button>
                        <button
                          type="button"
                          onClick={() => setExpenseToDelete(exp)}
                          className="p-1 text-slate-400 hover:text-rose-600 rounded-md hover:bg-slate-100"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          <Pagination
            currentPage={currentPage}
            totalItems={filtered.length}
            pageSize={pageSize}
            onPageChange={setCurrentPage}
            onPageSizeChange={(newSize) => {
              setPageSize(newSize);
              setCurrentPage(1);
            }}
          />
        </div>
      )}

      {/* Delete confirmation modal */}
      {expenseToDelete && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/60 backdrop-blur-xs">
          <div className="bg-white rounded-2xl shadow-xl border border-slate-200 max-w-sm w-full p-6 text-center animate-in fade-in zoom-in-95">
            <div className="w-12 h-12 rounded-full bg-rose-50 text-rose-600 flex items-center justify-center mx-auto mb-4">
              <Trash2 className="w-6 h-6" />
            </div>
            <h3 className="font-bold text-slate-900 text-sm mb-1">
              Supprimer la dépense
            </h3>
            <p className="text-xs text-slate-500 mb-6 leading-relaxed">
              Êtes-vous certain de vouloir supprimer cette écriture de <strong>{expenseToDelete.amount.toLocaleString('fr-FR')} FCFA</strong> ?
            </p>
            <div className="flex gap-2">
              <button
                type="button"
                onClick={() => setExpenseToDelete(null)}
                className="flex-1 py-2 px-3 text-xs font-semibold rounded-lg border border-slate-200 text-slate-600 hover:bg-slate-50"
              >
                Annuler
              </button>
              <button
                type="button"
                onClick={() => {
                  onDeleteExpense(expenseToDelete.id);
                  setExpenseToDelete(null);
                }}
                className="flex-1 py-2 px-3 text-xs font-semibold rounded-lg bg-rose-600 hover:bg-rose-700 text-white"
              >
                Confirmer
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
