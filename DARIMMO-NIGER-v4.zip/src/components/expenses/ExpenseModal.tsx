import React, { useState, useEffect } from 'react';
import { X, TrendingDown, DollarSign, Calendar, Building, AlertCircle } from 'lucide-react';
import { Expense, ExpenseCategory, Property } from '../../types';

interface ExpenseModalProps {
  isOpen: boolean;
  expense: Expense | null;
  properties: Property[];
  onClose: () => void;
  onSave: (expense: Expense) => void;
  organizationId: string;
}

const CATEGORIES: ExpenseCategory[] = [
  'Plomberie & Sanitaire',
  'Électricité',
  'Maçonnerie & Peinture',
  'Gardiennage & Sécurité',
  'Nettoyage & Salubrité',
  'Taxes & Impôts Fonciers',
  'Facture Eau / Nigelec',
  'Gestion & Frais Divers'
];

export const ExpenseModal: React.FC<ExpenseModalProps> = ({
  isOpen,
  expense,
  properties,
  onClose,
  onSave,
  organizationId
}) => {
  const [propertyId, setPropertyId] = useState('');
  const [category, setCategory] = useState<ExpenseCategory>('Gardiennage & Sécurité');
  const [amount, setAmount] = useState(50000);
  const [date, setDate] = useState(new Date().toISOString().split('T')[0]);
  const [beneficiary, setBeneficiary] = useState('');
  const [description, setDescription] = useState('');
  const [receiptRef, setReceiptRef] = useState('');
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (expense) {
      setPropertyId(expense.propertyId || '');
      setCategory(expense.category);
      setAmount(expense.amount);
      setDate(expense.date);
      setBeneficiary(expense.beneficiary);
      setDescription(expense.description);
      setReceiptRef(expense.receiptRef || '');
    } else {
      setPropertyId(properties[0]?.id || '');
      setCategory('Gardiennage & Sécurité');
      setAmount(50000);
      setDate(new Date().toISOString().split('T')[0]);
      setBeneficiary('');
      setDescription('');
      setReceiptRef(`FACT-${Date.now().toString().slice(-5)}`);
    }
    setError(null);
  }, [expense, properties, isOpen]);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!beneficiary.trim() || !description.trim() || amount <= 0) {
      setError('Veuillez renseigner le bénéficiaire, la description et un montant valide.');
      return;
    }

    const selectedProp = properties.find(p => p.id === propertyId);

    const saved: Expense = {
      id: expense ? expense.id : `exp_${Date.now()}`,
      organizationId,
      propertyId: propertyId || undefined,
      propertyTitle: selectedProp ? selectedProp.title : 'Dépense générale',
      category,
      amount: Number(amount),
      date,
      beneficiary: beneficiary.trim(),
      description: description.trim(),
      receiptRef: receiptRef.trim() || undefined,
      createdAt: expense ? expense.createdAt : new Date().toISOString()
    };

    onSave(saved);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/60 backdrop-blur-xs overflow-y-auto">
      <div className="bg-white rounded-2xl shadow-2xl border border-slate-200 max-w-lg w-full overflow-hidden my-6 animate-in fade-in zoom-in-95">
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-100 bg-slate-50">
          <div className="flex items-center gap-2">
            <TrendingDown className="w-5 h-5 text-amber-600" />
            <h3 className="font-bold text-slate-900 text-sm sm:text-base">
              {expense ? 'Modifier la Dépense' : 'Enregistrer une Dépense / Charge'}
            </h3>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-slate-600 rounded-lg hover:bg-slate-200/50"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-4 text-xs">
          {error && (
            <div className="p-3 rounded-lg bg-rose-50 border border-rose-200 text-rose-700 flex items-center gap-2">
              <AlertCircle className="w-4 h-4 shrink-0" />
              <span>{error}</span>
            </div>
          )}

          <div>
            <label className="block font-semibold text-slate-700 mb-1">
              Bien immobilier concerné
            </label>
            <select
              value={propertyId}
              onChange={(e) => setPropertyId(e.target.value)}
              className="w-full px-3 py-2 rounded-lg border border-slate-200 focus:outline-hidden focus:ring-1 focus:ring-emerald-500 text-xs bg-white"
            >
              <option value="">Dépense générale / Non affectée à un bien</option>
              {properties.map(p => (
                <option key={p.id} value={p.id}>
                  {p.title} ({p.neighborhood})
                </option>
              ))}
            </select>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block font-semibold text-slate-700 mb-1">
                Catégorie de charge
              </label>
              <select
                value={category}
                onChange={(e) => setCategory(e.target.value as ExpenseCategory)}
                className="w-full px-3 py-2 rounded-lg border border-slate-200 focus:outline-hidden focus:ring-1 focus:ring-emerald-500 text-xs bg-white"
              >
                {CATEGORIES.map(c => (
                  <option key={c} value={c}>{c}</option>
                ))}
              </select>
            </div>

            <div>
              <label className="block font-semibold text-slate-700 mb-1">
                Montant décaissé (FCFA) *
              </label>
              <input
                type="number"
                step={1000}
                required
                value={amount}
                onChange={(e) => setAmount(Number(e.target.value))}
                className="w-full px-3 py-2 rounded-lg border border-slate-200 focus:outline-hidden focus:ring-1 focus:ring-emerald-500 text-xs font-mono font-bold text-amber-700"
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block font-semibold text-slate-700 mb-1">
                Date du paiement *
              </label>
              <input
                type="date"
                required
                value={date}
                onChange={(e) => setDate(e.target.value)}
                className="w-full px-3 py-2 rounded-lg border border-slate-200 focus:outline-hidden focus:ring-1 focus:ring-emerald-500 text-xs"
              />
            </div>

            <div>
              <label className="block font-semibold text-slate-700 mb-1">
                N° Facture / Reçu
              </label>
              <input
                type="text"
                value={receiptRef}
                onChange={(e) => setReceiptRef(e.target.value)}
                placeholder="Ex: RECU-SNS-2026-03"
                className="w-full px-3 py-2 rounded-lg border border-slate-200 focus:outline-hidden focus:ring-1 focus:ring-emerald-500 text-xs font-mono"
              />
            </div>
          </div>

          <div>
            <label className="block font-semibold text-slate-700 mb-1">
              Bénéficiaire / Prestataire / Artisan *
            </label>
            <input
              type="text"
              required
              value={beneficiary}
              onChange={(e) => setBeneficiary(e.target.value)}
              placeholder="Ex: Société Nigérienne de Sécurité (SNS) ou Artisan Plombier"
              className="w-full px-3 py-2 rounded-lg border border-slate-200 focus:outline-hidden focus:ring-1 focus:ring-emerald-500 text-xs"
            />
          </div>

          <div>
            <label className="block font-semibold text-slate-700 mb-1">
              Description de la prestation *
            </label>
            <textarea
              rows={2}
              required
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="Détails de l'intervention, matériel acheté, etc."
              className="w-full px-3 py-2 rounded-lg border border-slate-200 focus:outline-hidden focus:ring-1 focus:ring-emerald-500 text-xs"
            />
          </div>

          <div className="flex justify-end gap-2 pt-3 border-t border-slate-100">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 rounded-lg border border-slate-200 text-slate-600 hover:bg-slate-50 transition-colors font-medium text-xs cursor-pointer"
            >
              Annuler
            </button>
            <button
              type="submit"
              className="px-4 py-2 rounded-lg bg-amber-600 hover:bg-amber-700 text-white font-semibold text-xs transition-colors cursor-pointer"
            >
              {expense ? 'Enregistrer les modifications' : 'Enregistrer la Dépense'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
