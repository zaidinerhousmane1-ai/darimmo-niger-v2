import React, { useState, useMemo } from 'react';
import { 
  Receipt, 
  Plus, 
  Search, 
  Printer, 
  Download, 
  CheckCircle2, 
  Clock, 
  AlertCircle, 
  Calendar,
  CreditCard,
  MessageSquare,
  AlertTriangle,
  ExternalLink
} from 'lucide-react';
import { RentPayment } from '../../types';
import { Pagination } from '../common/Pagination';
import { EmptyState } from '../common/EmptyState';

interface RentsListProps {
  payments: RentPayment[];
  onAddPayment: () => void;
  onEditPayment: (payment: RentPayment) => void;
  onViewReceipt: (payment: RentPayment) => void;
  onSendReminder?: (payment: RentPayment) => void;
}

export const RentsList: React.FC<RentsListProps> = ({
  payments,
  onAddPayment,
  onEditPayment,
  onViewReceipt,
  onSendReminder
}) => {
  const [search, setSearch] = useState('');
  const [activeTab, setActiveTab] = useState<'all' | 'overdue'>('all');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [monthFilter, setMonthFilter] = useState<string>('all');

  // Pagination
  const [currentPage, setCurrentPage] = useState(1);
  const [pageSize, setPageSize] = useState(10);

  // Month options from data
  const monthOptions = useMemo(() => {
    const set = new Set<string>();
    payments.forEach(p => set.add(p.periodMonth));
    return Array.from(set);
  }, [payments]);

  // Overdue items sorted by ancienneté (oldest due date first)
  const overdueCount = useMemo(() => {
    return payments.filter(p => p.status === 'retard' || (p.amountPaid < p.amountExpected && p.status !== 'paye')).length;
  }, [payments]);

  const filtered = useMemo(() => {
    let list = payments.filter(p => {
      const isOverdue = p.status === 'retard' || (p.amountPaid < p.amountExpected && p.status !== 'paye');
      if (activeTab === 'overdue' && !isOverdue) return false;

      const matchSearch = search.trim() === '' ||
        p.tenantName.toLowerCase().includes(search.toLowerCase()) ||
        p.propertyTitle.toLowerCase().includes(search.toLowerCase()) ||
        p.receiptNumber.toLowerCase().includes(search.toLowerCase());

      const matchStatus = statusFilter === 'all' || p.status === statusFilter;
      const matchMonth = monthFilter === 'all' || p.periodMonth === monthFilter;

      return matchSearch && matchStatus && matchMonth;
    });

    if (activeTab === 'overdue') {
      // Triée par ancienneté (date d'échéance la plus ancienne d'abord)
      list = [...list].sort((a, b) => new Date(a.dueDate).getTime() - new Date(b.dueDate).getTime());
    }

    return list;
  }, [payments, search, activeTab, statusFilter, monthFilter]);

  const paginatedItems = useMemo(() => {
    const start = (currentPage - 1) * pageSize;
    return filtered.slice(start, start + pageSize);
  }, [filtered, currentPage, pageSize]);

  // Aggregate stats of current filtered list
  const totalExpected = filtered.reduce((acc, p) => acc + p.amountExpected, 0);
  const totalPaid = filtered.reduce((acc, p) => acc + p.amountPaid, 0);
  const totalUnpaid = Math.max(0, totalExpected - totalPaid);

  const getMethodBadge = (m?: string) => {
    switch (m) {
      case 'airtel_money':
        return <span className="text-[10px] text-red-600 font-semibold bg-red-50 px-1.5 py-0.5 rounded border border-red-100">Airtel Money</span>;
      case 'nita':
        return <span className="text-[10px] text-emerald-700 font-semibold bg-emerald-50 px-1.5 py-0.5 rounded border border-emerald-100">Nita</span>;
      case 'amana':
        return <span className="text-[10px] text-blue-700 font-semibold bg-blue-50 px-1.5 py-0.5 rounded border border-blue-100">Amana</span>;
      case 'virement':
        return <span className="text-[10px] text-indigo-700 font-semibold bg-indigo-50 px-1.5 py-0.5 rounded border border-indigo-100">Virement</span>;
      case 'especes':
        return <span className="text-[10px] text-amber-700 font-semibold bg-amber-50 px-1.5 py-0.5 rounded border border-amber-100">Espèces</span>;
      default:
        return <span className="text-[10px] text-slate-400">—</span>;
    }
  };

  // Helper function to build direct WhatsApp link
  const getDirectWhatsAppUrl = (payment: RentPayment) => {
    const tenantPhone = '22790000000'; // Standard clean phone fallback
    const dueAmount = (payment.amountExpected - payment.amountPaid).toLocaleString('fr-FR');
    const msg = `Bonjour ${payment.tenantName},\n\nSauf erreur de notre part, votre loyer du mois de *${payment.periodMonth}* pour le logement *${payment.propertyTitle}* d'un montant de *${dueAmount} FCFA* est actuellement en retard de règlement.\n\nMerci de bien vouloir procéder au paiement via Airtel Money, Nita, Amana ou virement bancaire.\n\nVotre quittance électronique DARIMMO vous sera envoyée dès encaissement. Merci pour votre diligence.`;
    return `https://wa.me/?text=${encodeURIComponent(msg)}`;
  };

  return (
    <div className="space-y-5 max-w-7xl mx-auto pb-12">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold text-slate-900 tracking-tight">Grand Livre des Loyers & Quittances</h2>
          <p className="text-xs text-slate-500 mt-0.5">
            Suivi des encaissements, relances WhatsApp et émission des quittances officielles.
          </p>
        </div>

        <button
          type="button"
          onClick={onAddPayment}
          className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs font-semibold bg-emerald-700 hover:bg-emerald-800 text-white shadow-xs transition-colors cursor-pointer self-start sm:self-auto"
        >
          <Plus className="w-4 h-4" />
          <span>Encaisser un loyer</span>
        </button>
      </div>

      {/* Tabs Switcher: Tous les loyers vs Loyers en retard triés par ancienneté */}
      <div className="flex items-center gap-2 border-b border-slate-200">
        <button
          type="button"
          onClick={() => { setActiveTab('all'); setCurrentPage(1); }}
          className={`py-2.5 px-4 text-xs font-semibold border-b-2 transition-colors cursor-pointer ${
            activeTab === 'all'
              ? 'border-emerald-600 text-emerald-800'
              : 'border-transparent text-slate-500 hover:text-slate-800'
          }`}
        >
          Tous les loyers ({payments.length})
        </button>
        <button
          type="button"
          onClick={() => { setActiveTab('overdue'); setCurrentPage(1); }}
          className={`py-2.5 px-4 text-xs font-semibold border-b-2 transition-colors cursor-pointer flex items-center gap-1.5 ${
            activeTab === 'overdue'
              ? 'border-rose-600 text-rose-700'
              : 'border-transparent text-slate-500 hover:text-rose-600'
          }`}
        >
          <AlertTriangle className="w-3.5 h-3.5" />
          <span>Loyers en retard ({overdueCount})</span>
          <span className="text-[10px] font-normal bg-rose-100 text-rose-800 px-1.5 py-0.2 rounded-full">
            Triés par ancienneté
          </span>
        </button>
      </div>

      {/* Financial Summary Strip */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 p-4 bg-white rounded-2xl border border-slate-200/80 shadow-2xs">
        <div className="p-3 rounded-xl bg-slate-50 border border-slate-100">
          <span className="text-[10px] font-semibold text-slate-500 uppercase tracking-wider block">
            {activeTab === 'overdue' ? 'Montant Total en Retard' : 'Total Loyers Attendus'}
          </span>
          <span className="text-lg font-bold text-slate-900 font-mono">
            {(activeTab === 'overdue' ? totalUnpaid : totalExpected).toLocaleString('fr-FR')}{' '}
            <span className="text-xs font-normal text-slate-500">FCFA</span>
          </span>
        </div>

        <div className="p-3 rounded-xl bg-emerald-50/60 border border-emerald-100">
          <span className="text-[10px] font-semibold text-emerald-800 uppercase tracking-wider block">
            Total Encaissé
          </span>
          <span className="text-lg font-bold text-emerald-800 font-mono">
            {totalPaid.toLocaleString('fr-FR')} <span className="text-xs font-normal text-emerald-700">FCFA</span>
          </span>
        </div>

        <div className="p-3 rounded-xl bg-rose-50/60 border border-rose-100">
          <span className="text-[10px] font-semibold text-rose-800 uppercase tracking-wider block">
            Reste à Recouvrer / Impayés
          </span>
          <span className="text-lg font-bold text-rose-600 font-mono">
            {totalUnpaid.toLocaleString('fr-FR')} <span className="text-xs font-normal text-rose-500">FCFA</span>
          </span>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="p-4 bg-white rounded-2xl border border-slate-200/80 shadow-2xs flex flex-col sm:flex-row gap-3 items-stretch sm:items-center justify-between">
        <div className="flex-1 relative">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
          <input
            type="text"
            value={search}
            onChange={(e) => { setSearch(e.target.value); setCurrentPage(1); }}
            placeholder="Rechercher par quittance N°, locataire, bien loué..."
            className="w-full pl-9 pr-3 py-2 text-xs rounded-xl border border-slate-200 focus:outline-hidden focus:ring-1 focus:ring-emerald-500 bg-slate-50/50"
          />
        </div>

        <div className="flex items-center gap-2">
          <select
            value={monthFilter}
            onChange={(e) => { setMonthFilter(e.target.value); setCurrentPage(1); }}
            className="px-3 py-2 text-xs rounded-xl border border-slate-200 bg-white text-slate-700 focus:outline-hidden focus:ring-1 focus:ring-emerald-500"
          >
            <option value="all">Tous les mois</option>
            {monthOptions.map(m => (
              <option key={m} value={m}>{m}</option>
            ))}
          </select>

          {activeTab !== 'overdue' && (
            <select
              value={statusFilter}
              onChange={(e) => { setStatusFilter(e.target.value); setCurrentPage(1); }}
              className="px-3 py-2 text-xs rounded-xl border border-slate-200 bg-white text-slate-700 focus:outline-hidden focus:ring-1 focus:ring-emerald-500"
            >
              <option value="all">Tous les états</option>
              <option value="paye">Payé (Quittance émise)</option>
              <option value="retard">En retard / Impayé</option>
              <option value="partiel">Paiement partiel</option>
            </select>
          )}
        </div>
      </div>

      {/* Content */}
      {filtered.length === 0 ? (
        <EmptyState
          icon={Receipt}
          title={activeTab === 'overdue' ? 'Aucun loyer en retard' : 'Aucun loyer enregistré'}
          description={
            activeTab === 'overdue'
              ? 'Félicitations, tous vos locataires sont à jour dans leurs paiements de loyers.'
              : 'Commencez à enregistrer les encaissements pour éditer vos quittances.'
          }
          actionLabel="Encaisser un loyer"
          onAction={onAddPayment}
        />
      ) : (
        <div className="bg-white rounded-2xl border border-slate-200/80 shadow-2xs overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs text-slate-700">
              <thead className="bg-slate-50/80 text-slate-500 border-b border-slate-200/80 uppercase text-[10px] tracking-wider">
                <tr>
                  <th className="py-3 px-4 font-semibold">N° Quittance</th>
                  <th className="py-3 px-4 font-semibold">Locataire</th>
                  <th className="py-3 px-4 font-semibold">Logement</th>
                  <th className="py-3 px-4 font-semibold">Mois</th>
                  <th className="py-3 px-4 font-semibold">Montant Réglé / Attendu</th>
                  <th className="py-3 px-4 font-semibold">Mode (Niger)</th>
                  <th className="py-3 px-4 font-semibold">Statut</th>
                  <th className="py-3 px-4 font-semibold text-right">Actions & Relances</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {paginatedItems.map(p => (
                  <tr key={p.id} className="hover:bg-slate-50/60 transition-colors">
                    <td className="py-3 px-4 font-mono font-medium text-slate-800">
                      {p.receiptNumber}
                    </td>
                    <td className="py-3 px-4 font-semibold text-slate-900">
                      {p.tenantName}
                    </td>
                    <td className="py-3 px-4 text-slate-600 truncate max-w-xs">
                      {p.propertyTitle}
                    </td>
                    <td className="py-3 px-4 text-slate-600 font-medium">
                      {p.periodMonth}
                    </td>
                    <td className="py-3 px-4 font-mono">
                      <span className="font-bold text-slate-900">
                        {p.amountPaid.toLocaleString('fr-FR')}
                      </span>{' '}
                      <span className="text-slate-400">/ {p.amountExpected.toLocaleString('fr-FR')} FCFA</span>
                    </td>
                    <td className="py-3 px-4">
                      {getMethodBadge(p.paymentMethod)}
                    </td>
                    <td className="py-3 px-4">
                      {p.status === 'paye' ? (
                        <span className="px-2 py-0.5 rounded text-[10px] font-semibold bg-emerald-50 text-emerald-800 border border-emerald-200">
                          Payé
                        </span>
                      ) : (
                        <span className="px-2 py-0.5 rounded text-[10px] font-semibold bg-rose-50 text-rose-700 border border-rose-200 flex items-center gap-1 w-fit">
                          <AlertCircle className="w-3 h-3" />
                          <span>En retard ({new Date(p.dueDate).toLocaleDateString('fr-FR')})</span>
                        </span>
                      )}
                    </td>
                    <td className="py-3 px-4 text-right">
                      {p.status === 'paye' ? (
                        <button
                          type="button"
                          onClick={() => onViewReceipt(p)}
                          className="inline-flex items-center gap-1.5 px-2.5 py-1 text-xs font-semibold text-emerald-700 bg-emerald-50 hover:bg-emerald-100 rounded-lg transition-colors cursor-pointer"
                        >
                          <Printer className="w-3.5 h-3.5" />
                          <span>Imprimer Quittance</span>
                        </button>
                      ) : (
                        <div className="inline-flex items-center gap-2 justify-end">
                          {/* Direct WhatsApp Reminder Button */}
                          <a
                            href={getDirectWhatsAppUrl(p)}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="inline-flex items-center gap-1.5 px-2.5 py-1 text-xs font-semibold text-emerald-800 bg-emerald-100/80 hover:bg-emerald-200 border border-emerald-300 rounded-lg transition-colors cursor-pointer"
                            title="Relancer par WhatsApp avec message pré-rempli"
                          >
                            <MessageSquare className="w-3.5 h-3.5 text-emerald-700" />
                            <span>Relancer par WhatsApp</span>
                          </a>

                          <button
                            type="button"
                            onClick={() => onEditPayment(p)}
                            className="inline-flex items-center gap-1.5 px-2.5 py-1 text-xs font-semibold text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-lg transition-colors cursor-pointer"
                          >
                            <span>Encaisser</span>
                          </button>
                        </div>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          <Pagination
            currentPage={currentPage}
            totalItems={filtered.length}
            pageSize={pageSize}
            onPageChange={setCurrentPage}
            onPageSizeChange={(newSize) => {
              setPageSize(newSize);
              setCurrentPage(1);
            }}
          />
        </div>
      )}
    </div>
  );
};
