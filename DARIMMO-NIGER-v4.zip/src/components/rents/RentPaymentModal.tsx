import React, { useState, useEffect } from 'react';
import { X, Receipt, DollarSign, Calendar, CreditCard, AlertCircle } from 'lucide-react';
import { RentPayment, Tenant, PaymentMethod, PaymentStatus } from '../../types';

interface RentPaymentModalProps {
  isOpen: boolean;
  payment: RentPayment | null;
  tenants: Tenant[];
  onClose: () => void;
  onSave: (payment: RentPayment) => void;
  organizationId: string;
}

const MONTHS = [
  'Janvier 2026', 'Février 2026', 'Mars 2026', 'Avril 2026',
  'Mai 2026', 'Juin 2026', 'Juillet 2026', 'Août 2026',
  'Septembre 2026', 'Octobre 2026', 'Novembre 2026', 'Décembre 2026'
];

export const RentPaymentModal: React.FC<RentPaymentModalProps> = ({
  isOpen,
  payment,
  tenants,
  onClose,
  onSave,
  organizationId
}) => {
  const [tenantId, setTenantId] = useState('');
  const [periodMonth, setPeriodMonth] = useState('Mars 2026');
  const [dueDate, setDueDate] = useState('2026-03-05');
  const [paymentDate, setPaymentDate] = useState(new Date().toISOString().split('T')[0]);
  const [amountExpected, setAmountExpected] = useState(250000);
  const [amountPaid, setAmountPaid] = useState(250000);
  const [paymentMethod, setPaymentMethod] = useState<PaymentMethod>('airtel_money');
  const [transactionReference, setTransactionReference] = useState('');
  const [status, setStatus] = useState<PaymentStatus>('paye');
  const [notes, setNotes] = useState('');
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (payment) {
      setTenantId(payment.tenantId);
      setPeriodMonth(payment.periodMonth);
      setDueDate(payment.dueDate);
      setPaymentDate(payment.paymentDate || new Date().toISOString().split('T')[0]);
      setAmountExpected(payment.amountExpected);
      setAmountPaid(payment.amountPaid);
      setPaymentMethod(payment.paymentMethod || 'airtel_money');
      setTransactionReference(payment.transactionReference || '');
      setStatus(payment.status);
      setNotes(payment.notes || '');
    } else {
      const firstTenant = tenants[0];
      setTenantId(firstTenant?.id || '');
      setPeriodMonth('Mars 2026');
      setDueDate('2026-03-05');
      setPaymentDate(new Date().toISOString().split('T')[0]);
      setAmountExpected(firstTenant?.monthlyRent || 250000);
      setAmountPaid(firstTenant?.monthlyRent || 250000);
      setPaymentMethod('airtel_money');
      setTransactionReference(`TX-AIRTEL-${Date.now().toString().slice(-6)}`);
      setStatus('paye');
      setNotes('');
    }
    setError(null);
  }, [payment, tenants, isOpen]);

  if (!isOpen) return null;

  const handleTenantSelect = (id: string) => {
    setTenantId(id);
    const selected = tenants.find(t => t.id === id);
    if (selected) {
      setAmountExpected(selected.monthlyRent);
      setAmountPaid(selected.monthlyRent);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!tenantId) {
      setError('Veuillez sélectionner un locataire.');
      return;
    }

    const selectedTenant = tenants.find(t => t.id === tenantId);
    if (!selectedTenant) return;

    const receiptNum = payment ? payment.receiptNumber : `QUIT-DAR-2026-${Date.now().toString().slice(-4)}`;

    const saved: RentPayment = {
      id: payment ? payment.id : `pay_${Date.now()}`,
      organizationId,
      receiptNumber: receiptNum,
      tenantId,
      tenantName: selectedTenant.fullName,
      propertyId: selectedTenant.propertyId,
      propertyTitle: selectedTenant.propertyTitle,
      periodMonth,
      dueDate,
      paymentDate: status === 'paye' ? paymentDate : undefined,
      amountExpected: Number(amountExpected) || 0,
      amountPaid: status === 'paye' ? Number(amountPaid) : 0,
      paymentMethod: status === 'paye' ? paymentMethod : undefined,
      transactionReference: status === 'paye' ? transactionReference.trim() : undefined,
      status,
      notes: notes.trim(),
      createdAt: payment ? payment.createdAt : new Date().toISOString()
    };

    onSave(saved);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/60 backdrop-blur-xs overflow-y-auto">
      <div className="bg-white rounded-2xl shadow-2xl border border-slate-200 max-w-lg w-full overflow-hidden my-6 animate-in fade-in zoom-in-95">
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-100 bg-slate-50">
          <div className="flex items-center gap-2">
            <Receipt className="w-5 h-5 text-emerald-700" />
            <h3 className="font-bold text-slate-900 text-sm sm:text-base">
              {payment ? 'Modifier le Paiement / Quittance' : 'Enregistrer un Encaissement de Loyer'}
            </h3>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-slate-600 rounded-lg hover:bg-slate-200/50"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-4 text-xs">
          {error && (
            <div className="p-3 rounded-lg bg-rose-50 border border-rose-200 text-rose-700 flex items-center gap-2">
              <AlertCircle className="w-4 h-4 shrink-0" />
              <span>{error}</span>
            </div>
          )}

          <div>
            <label className="block font-semibold text-slate-700 mb-1">
              Locataire concerné *
            </label>
            {tenants.length === 0 && (
              <p className="mb-2 p-3 rounded-lg bg-amber-50 border border-amber-200 text-amber-800 text-xs">
                Aucun locataire enregistré pour le moment. Ajoutez d'abord un bien (menu « Biens »), puis un locataire (menu « Locataires ») pour pouvoir enregistrer un loyer.
              </p>
            )}
            <select
              required
              value={tenantId}
              onChange={(e) => handleTenantSelect(e.target.value)}
              className="w-full px-3 py-2 rounded-lg border border-slate-200 focus:outline-hidden focus:ring-1 focus:ring-emerald-500 text-xs bg-white"
            >
              <option value="">Sélectionnez un locataire...</option>
              {tenants.map(t => (
                <option key={t.id} value={t.id}>
                  {t.fullName} — {t.propertyTitle} ({t.monthlyRent.toLocaleString('fr-FR')} FCFA)
                </option>
              ))}
            </select>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block font-semibold text-slate-700 mb-1">
                Période / Mois de loyer
              </label>
              <select
                value={periodMonth}
                onChange={(e) => setPeriodMonth(e.target.value)}
                className="w-full px-3 py-2 rounded-lg border border-slate-200 focus:outline-hidden focus:ring-1 focus:ring-emerald-500 text-xs bg-white"
              >
                {MONTHS.map(m => (
                  <option key={m} value={m}>{m}</option>
                ))}
              </select>
            </div>

            <div>
              <label className="block font-semibold text-slate-700 mb-1">
                Statut du règlement
              </label>
              <select
                value={status}
                onChange={(e) => setStatus(e.target.value as PaymentStatus)}
                className="w-full px-3 py-2 rounded-lg border border-slate-200 focus:outline-hidden focus:ring-1 focus:ring-emerald-500 text-xs bg-white font-semibold"
              >
                <option value="paye">Payé en totalité (Générer quittance)</option>
                <option value="partiel">Paiement Partiel</option>
                <option value="retard">En retard / Impayé</option>
                <option value="en_attente">En attente de virement</option>
              </select>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block font-semibold text-slate-700 mb-1">
                Montant attendu (FCFA) *
              </label>
              <input
                type="number"
                step={5000}
                required
                value={amountExpected}
                onChange={(e) => setAmountExpected(Number(e.target.value))}
                className="w-full px-3 py-2 rounded-lg border border-slate-200 focus:outline-hidden focus:ring-1 focus:ring-emerald-500 text-xs font-mono"
              />
            </div>

            <div>
              <label className="block font-semibold text-slate-700 mb-1">
                Montant encaissé (FCFA) *
              </label>
              <input
                type="number"
                step={5000}
                required
                value={amountPaid}
                onChange={(e) => setAmountPaid(Number(e.target.value))}
                className="w-full px-3 py-2 rounded-lg border border-slate-200 focus:outline-hidden focus:ring-1 focus:ring-emerald-500 text-xs font-mono font-bold text-emerald-800"
              />
            </div>
          </div>

          {status === 'paye' && (
            <>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">
                    Mode de paiement (Niger)
                  </label>
                  <select
                    value={paymentMethod}
                    onChange={(e) => setPaymentMethod(e.target.value as PaymentMethod)}
                    className="w-full px-3 py-2 rounded-lg border border-slate-200 focus:outline-hidden focus:ring-1 focus:ring-emerald-500 text-xs bg-white"
                  >
                    <option value="airtel_money">Airtel Money Niger</option>
                    <option value="nita">Nita Transfert</option>
                    <option value="amana">Amana Express</option>
                    <option value="virement">Virement bancaire (BOA, BIA, Sonibank)</option>
                    <option value="especes">Espèces / Cash</option>
                  </select>
                </div>

                <div>
                  <label className="block font-semibold text-slate-700 mb-1">
                    Date de règlement
                  </label>
                  <input
                    type="date"
                    required
                    value={paymentDate}
                    onChange={(e) => setPaymentDate(e.target.value)}
                    className="w-full px-3 py-2 rounded-lg border border-slate-200 focus:outline-hidden focus:ring-1 focus:ring-emerald-500 text-xs"
                  />
                </div>
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">
                  Réf. Transaction / Bordereau
                </label>
                <input
                  type="text"
                  value={transactionReference}
                  onChange={(e) => setTransactionReference(e.target.value)}
                  placeholder="Ex: AIRTEL-TX-984102 ou Reçu Nita N° 4410"
                  className="w-full px-3 py-2 rounded-lg border border-slate-200 focus:outline-hidden focus:ring-1 focus:ring-emerald-500 text-xs font-mono"
                />
              </div>
            </>
          )}

          <div>
            <label className="block font-semibold text-slate-700 mb-1">
              Observations / Notes internes
            </label>
            <input
              type="text"
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="Ex: Règlement déposé à l'agence de Niamey..."
              className="w-full px-3 py-2 rounded-lg border border-slate-200 focus:outline-hidden focus:ring-1 focus:ring-emerald-500 text-xs"
            />
          </div>

          <div className="flex justify-end gap-2 pt-3 border-t border-slate-100">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 rounded-lg border border-slate-200 text-slate-600 hover:bg-slate-50 transition-colors font-medium text-xs cursor-pointer"
            >
              Annuler
            </button>
            <button
              type="submit"
              className="px-4 py-2 rounded-lg bg-emerald-700 hover:bg-emerald-800 text-white font-semibold text-xs transition-colors cursor-pointer"
            >
              {payment ? 'Enregistrer les modifications' : 'Valider & Émettre la Quittance'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
