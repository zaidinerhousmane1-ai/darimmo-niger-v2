import React, { useState } from 'react';
import { 
  Bell, 
  Menu, 
  X, 
  LogOut, 
  Building, 
  ShieldCheck, 
  UserCheck, 
  Sparkles,
  ChevronDown
} from 'lucide-react';
import { UserProfile, AppNotification, SubscriptionState } from '../../types';

interface HeaderProps {
  user: UserProfile | null;
  subscription: SubscriptionState;
  notifications: AppNotification[];
  isDemo?: boolean;
  onOpenMobileMenu: () => void;
  onRoleSwitch?: (role: 'owner' | 'agency' | 'tenant' | 'super_admin') => void;
  onSwitchDemoRole?: (role: 'owner' | 'agency' | 'tenant' | 'super_admin') => void;
  onExitDemo?: () => void;
  onLogout: () => void;
  onMarkNotificationRead: (id: string) => void;
  onMarkAllNotificationsRead: () => void;
  onNavigate: (view: string) => void;
  currentView: string;
}

export const Header: React.FC<HeaderProps> = ({
  user,
  subscription,
  notifications,
  isDemo = false,
  onOpenMobileMenu,
  onRoleSwitch,
  onSwitchDemoRole,
  onExitDemo,
  onLogout,
  onMarkNotificationRead,
  onMarkAllNotificationsRead,
  onNavigate,
  currentView
}) => {
  const [showNotifs, setShowNotifs] = useState(false);
  const [showRoleMenu, setShowRoleMenu] = useState(false);

  const unreadNotifs = notifications.filter(n => !n.read);

  // Compute trial days remaining
  const trialEnd = new Date(subscription.trialEndsAt);
  const now = new Date();
  const diffDays = Math.max(0, Math.ceil((trialEnd.getTime() - now.getTime()) / (1000 * 60 * 60 * 24)));

  return (
    <header className="sticky top-0 z-40 bg-white/95 backdrop-blur-md border-b border-slate-200/80 px-4 sm:px-6 py-3">
      <div className="flex items-center justify-between gap-4 md:gap-8 max-w-7xl mx-auto">
        {/* Zone 1: Brand Wordmark & Mobile Drawer Button */}
        <div className="flex items-center gap-3 shrink-0">
          <button
            type="button"
            onClick={onOpenMobileMenu}
            className="md:hidden p-2 rounded-lg text-slate-600 hover:text-slate-900 hover:bg-slate-100 transition-colors"
            aria-label="Ouvrir le menu"
          >
            <Menu className="w-5 h-5" />
          </button>
          
          <button
            type="button"
            onClick={() => onNavigate('dashboard')}
            className="flex items-center gap-2.5 text-left group cursor-pointer"
          >
            <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-emerald-800 to-emerald-600 text-white flex items-center justify-center font-bold text-lg shadow-sm">
              D
            </div>
            <div>
              <span className="text-lg font-bold tracking-tight text-slate-900 block leading-tight group-hover:text-emerald-700 transition-colors">
                DARIMMO
              </span>
              <span className="text-[10px] font-medium text-slate-400 tracking-wider uppercase block">
                SaaS Immobilier
              </span>
            </div>
          </button>
        </div>

        {/* Zone 2: Navigation Links or Context Breadcrumb */}
        <nav className="hidden lg:flex items-center gap-6 text-sm font-medium text-slate-600">
          <button
            type="button"
            onClick={() => onNavigate('dashboard')}
            className={`whitespace-nowrap transition-colors hover:text-emerald-700 cursor-pointer ${
              currentView === 'dashboard' ? 'text-emerald-700 font-semibold' : ''
            }`}
          >
            Tableau de bord
          </button>
          <button
            type="button"
            onClick={() => onNavigate('properties')}
            className={`whitespace-nowrap transition-colors hover:text-emerald-700 cursor-pointer ${
              currentView === 'properties' ? 'text-emerald-700 font-semibold' : ''
            }`}
          >
            Biens
          </button>
          <button
            type="button"
            onClick={() => onNavigate('rents')}
            className={`whitespace-nowrap transition-colors hover:text-emerald-700 cursor-pointer ${
              currentView === 'rents' ? 'text-emerald-700 font-semibold' : ''
            }`}
          >
            Loyers & Quittances
          </button>
          <button
            type="button"
            onClick={() => onNavigate('expenses')}
            className={`whitespace-nowrap transition-colors hover:text-emerald-700 cursor-pointer ${
              currentView === 'expenses' ? 'text-emerald-700 font-semibold' : ''
            }`}
          >
            Dépenses
          </button>
          <button
            type="button"
            onClick={() => onNavigate('subscription')}
            className={`whitespace-nowrap transition-colors hover:text-emerald-700 cursor-pointer ${
              currentView === 'subscription' ? 'text-emerald-700 font-semibold' : ''
            }`}
          >
            Abonnement
          </button>
        </nav>

        {/* Zone 3: Actions, Trial Counter, Notifications & Profile Role Switcher */}
        <div className="flex items-center gap-2 sm:gap-3 shrink-0">
          {/* Trial / Plan indicator */}
          {subscription.status === 'trial' ? (
            <button
              type="button"
              onClick={() => onNavigate('subscription')}
              className="hidden sm:inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-amber-50 border border-amber-200/80 text-amber-800 text-xs font-medium hover:bg-amber-100 transition-colors cursor-pointer"
            >
              <Sparkles className="w-3.5 h-3.5 text-amber-600" />
              <span>Essai Pro : {diffDays}j restants</span>
            </button>
          ) : (
            <span className="hidden sm:inline-flex items-center px-2.5 py-1 rounded-md bg-emerald-50 text-emerald-800 text-xs font-medium border border-emerald-200">
              {subscription.planId.toUpperCase()}
            </span>
          )}

          {/* Role Display: In Demo Mode, allow testing different demo personas; in Real Mode, strictly locked to server role */}
          {isDemo ? (
            <div className="relative">
              <button
                type="button"
                onClick={() => setShowRoleMenu(!showRoleMenu)}
                className="inline-flex items-center gap-1.5 px-2.5 py-1.5 text-xs font-semibold text-amber-900 bg-amber-100/90 hover:bg-amber-200 border border-amber-300 rounded-lg transition-colors cursor-pointer"
                title="Mode Démonstration Bac à Sable"
              >
                <span className="w-2 h-2 rounded-full bg-amber-600 animate-pulse" />
                <span className="hidden sm:inline">Démo :</span>
                <span>
                  {user?.role === 'super_admin' ? 'Super Admin' :
                   user?.role === 'agency_admin' ? 'Agence' :
                   user?.role === 'tenant' ? 'Locataire' : 'Propriétaire'}
                </span>
                <ChevronDown className="w-3.5 h-3.5 text-amber-700" />
              </button>

              {showRoleMenu && (
                <div className="absolute right-0 mt-2 w-64 bg-white rounded-xl shadow-xl border border-amber-200 py-1.5 z-50 text-xs animate-in fade-in zoom-in-95">
                  <div className="px-3 py-1.5 border-b border-slate-100 text-[11px] font-semibold text-amber-800 uppercase tracking-wider flex items-center justify-between">
                    <span>Tester un rôle démo :</span>
                    <span className="text-[10px] text-amber-600 font-normal">Isolé</span>
                  </div>
                  <button
                    type="button"
                    onClick={() => { onSwitchDemoRole?.('owner'); setShowRoleMenu(false); }}
                    className={`w-full text-left px-3 py-2 flex items-center justify-between hover:bg-slate-50 ${user?.role === 'owner' ? 'text-emerald-700 font-semibold bg-emerald-50/50' : 'text-slate-700'}`}
                  >
                    <div>
                      <span className="block font-medium">Propriétaire Particulier</span>
                      <span className="text-[10px] text-slate-400">Ousmane Mamadou</span>
                    </div>
                    {user?.role === 'owner' && <span className="text-emerald-600 text-xs">✓</span>}
                  </button>
                  <button
                    type="button"
                    onClick={() => { onSwitchDemoRole?.('agency'); setShowRoleMenu(false); }}
                    className={`w-full text-left px-3 py-2 flex items-center justify-between hover:bg-slate-50 ${user?.role === 'agency_admin' ? 'text-blue-700 font-semibold bg-blue-50/50' : 'text-slate-700'}`}
                  >
                    <div>
                      <span className="block font-medium">Agence Immobilière</span>
                      <span className="text-[10px] text-slate-400">Sahel Immo SARL</span>
                    </div>
                    {user?.role === 'agency_admin' && <span className="text-blue-600 text-xs">✓</span>}
                  </button>
                  <button
                    type="button"
                    onClick={() => { onSwitchDemoRole?.('tenant'); setShowRoleMenu(false); }}
                    className={`w-full text-left px-3 py-2 flex items-center justify-between hover:bg-slate-50 ${user?.role === 'tenant' ? 'text-amber-700 font-semibold bg-amber-50/50' : 'text-slate-700'}`}
                  >
                    <div>
                      <span className="block font-medium">Portail Locataire</span>
                      <span className="text-[10px] text-slate-400">Ibrahim Moussa</span>
                    </div>
                    {user?.role === 'tenant' && <span className="text-amber-600 text-xs">✓</span>}
                  </button>
                  <button
                    type="button"
                    onClick={() => { onSwitchDemoRole?.('super_admin'); setShowRoleMenu(false); }}
                    className={`w-full text-left px-3 py-2 flex items-center justify-between hover:bg-slate-50 ${user?.role === 'super_admin' ? 'text-indigo-700 font-semibold bg-indigo-50/50' : 'text-slate-700'}`}
                  >
                    <div>
                      <span className="block font-medium">Console Super Admin</span>
                      <span className="text-[10px] text-slate-400">Paiements & Audit</span>
                    </div>
                    {user?.role === 'super_admin' && <span className="text-indigo-600 text-xs">✓</span>}
                  </button>
                  
                  <div className="border-t border-slate-100 my-1 pt-1 px-2">
                    <button
                      type="button"
                      onClick={() => { onExitDemo?.(); setShowRoleMenu(false); }}
                      className="w-full text-center py-1.5 px-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg text-[11px] font-medium"
                    >
                      Quitter le mode démo
                    </button>
                  </div>
                </div>
              )}
            </div>
          ) : (
            <div className="inline-flex items-center gap-1.5 px-2.5 py-1.5 text-xs font-medium text-slate-700 bg-slate-100 rounded-lg">
              {user?.role === 'super_admin' && <ShieldCheck className="w-3.5 h-3.5 text-indigo-600" />}
              {user?.role === 'agency_admin' && <Building className="w-3.5 h-3.5 text-blue-600" />}
              {user?.role === 'owner' && <UserCheck className="w-3.5 h-3.5 text-emerald-600" />}
              {user?.role === 'tenant' && <UserCheck className="w-3.5 h-3.5 text-amber-600" />}
              
              <span className="hidden md:inline">
                {user?.role === 'super_admin' ? 'Super Admin' :
                 user?.role === 'agency_admin' ? 'Agence Immobilière' :
                 user?.role === 'tenant' ? 'Locataire' : 'Propriétaire'}
              </span>
            </div>
          )}

          {/* Notifications Button & Dropdown */}
          <div className="relative">
            <button
              type="button"
              onClick={() => setShowNotifs(!showNotifs)}
              className="p-2 rounded-lg text-slate-600 hover:text-slate-900 hover:bg-slate-100 relative transition-colors cursor-pointer"
              aria-label="Centre de notifications"
            >
              <Bell className="w-5 h-5" />
              {unreadNotifs.length > 0 && (
                <span className="absolute top-1 right-1 w-4 h-4 rounded-full bg-emerald-600 text-white text-[10px] font-bold flex items-center justify-center ring-2 ring-white">
                  {unreadNotifs.length}
                </span>
              )}
            </button>

            {showNotifs && (
              <div className="absolute right-0 mt-2 w-80 sm:w-96 bg-white rounded-2xl shadow-xl border border-slate-200 overflow-hidden z-50 animate-in fade-in zoom-in-95">
                <div className="flex items-center justify-between px-4 py-3 bg-slate-50 border-b border-slate-100">
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-semibold text-slate-900">Notifications</span>
                    {unreadNotifs.length > 0 && (
                      <span className="text-[11px] px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800 font-semibold">
                        {unreadNotifs.length} non lues
                      </span>
                    )}
                  </div>
                  {unreadNotifs.length > 0 && (
                    <button
                      type="button"
                      onClick={onMarkAllNotificationsRead}
                      className="text-[11px] text-emerald-700 hover:text-emerald-800 font-medium cursor-pointer"
                    >
                      Tout marquer comme lu
                    </button>
                  )}
                </div>

                <div className="max-h-80 overflow-y-auto divide-y divide-slate-100">
                  {notifications.length === 0 ? (
                    <div className="py-8 text-center text-xs text-slate-400">
                      Aucune notification pour le moment.
                    </div>
                  ) : (
                    notifications.map(n => (
                      <div
                        key={n.id}
                        onClick={() => {
                          onMarkNotificationRead(n.id);
                          if (n.link) onNavigate(n.link);
                          setShowNotifs(false);
                        }}
                        className={`p-3.5 transition-colors cursor-pointer hover:bg-slate-50 flex items-start gap-3 ${
                          !n.read ? 'bg-emerald-50/30' : ''
                        }`}
                      >
                        <div className={`w-2 h-2 rounded-full mt-1.5 shrink-0 ${
                          !n.read ? 'bg-emerald-600' : 'bg-transparent'
                        }`} />
                        <div className="flex-1 min-w-0">
                          <p className={`text-xs ${!n.read ? 'font-semibold text-slate-900' : 'text-slate-700'}`}>
                            {n.title}
                          </p>
                          <p className="text-[11px] text-slate-500 mt-0.5 leading-snug">
                            {n.message}
                          </p>
                          <span className="text-[10px] text-slate-400 mt-1 block">
                            {new Date(n.createdAt).toLocaleDateString('fr-FR', { hour: '2-digit', minute: '2-digit' })}
                          </span>
                        </div>
                      </div>
                    ))
                  )}
                </div>
              </div>
            )}
          </div>

          {/* User Profile Pill / Logout */}
          <div className="flex items-center gap-2 pl-2 border-l border-slate-200">
            {user?.avatarUrl ? (
              <img
                src={user.avatarUrl}
                alt={user.fullName}
                referrerPolicy="no-referrer"
                className="w-8 h-8 rounded-full object-cover ring-1 ring-slate-200"
              />
            ) : (
              <div className="w-8 h-8 rounded-full bg-emerald-100 text-emerald-800 font-bold text-xs flex items-center justify-center">
                {user?.fullName.charAt(0) || 'U'}
              </div>
            )}
            <button
              type="button"
              onClick={onLogout}
              className="p-1.5 text-slate-400 hover:text-rose-600 rounded-lg hover:bg-slate-100 transition-colors"
              title="Déconnexion"
              aria-label="Déconnexion"
            >
              <LogOut className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>
    </header>
  );
};
