import React from 'react';
import { LayoutDashboard, Building2, Receipt, TrendingDown, MoreHorizontal } from 'lucide-react';

interface MobileNavProps {
  currentView: string;
  onNavigate: (view: string) => void;
  onOpenMore: () => void;
}

export const MobileNav: React.FC<MobileNavProps> = ({
  currentView,
  onNavigate,
  onOpenMore
}) => {
  return (
    <nav className="md:hidden fixed bottom-0 left-0 right-0 z-40 bg-white/95 backdrop-blur-md border-t border-slate-200 px-2 py-1.5 flex items-center justify-around shadow-lg">
      <button
        type="button"
        onClick={() => onNavigate('dashboard')}
        className={`flex flex-col items-center gap-0.5 py-1 px-3 rounded-lg text-[10px] font-medium transition-colors ${
          currentView === 'dashboard' ? 'text-emerald-700 font-semibold' : 'text-slate-500 hover:text-slate-900'
        }`}
      >
        <LayoutDashboard className="w-5 h-5" />
        <span>Accueil</span>
      </button>

      <button
        type="button"
        onClick={() => onNavigate('properties')}
        className={`flex flex-col items-center gap-0.5 py-1 px-3 rounded-lg text-[10px] font-medium transition-colors ${
          currentView === 'properties' ? 'text-emerald-700 font-semibold' : 'text-slate-500 hover:text-slate-900'
        }`}
      >
        <Building2 className="w-5 h-5" />
        <span>Biens</span>
      </button>

      <button
        type="button"
        onClick={() => onNavigate('rents')}
        className={`flex flex-col items-center gap-0.5 py-1 px-3 rounded-lg text-[10px] font-medium transition-colors ${
          currentView === 'rents' ? 'text-emerald-700 font-semibold' : 'text-slate-500 hover:text-slate-900'
        }`}
      >
        <Receipt className="w-5 h-5" />
        <span>Loyers</span>
      </button>

      <button
        type="button"
        onClick={() => onNavigate('expenses')}
        className={`flex flex-col items-center gap-0.5 py-1 px-3 rounded-lg text-[10px] font-medium transition-colors ${
          currentView === 'expenses' ? 'text-emerald-700 font-semibold' : 'text-slate-500 hover:text-slate-900'
        }`}
      >
        <TrendingDown className="w-5 h-5" />
        <span>Dépenses</span>
      </button>

      <button
        type="button"
        onClick={onOpenMore}
        className="flex flex-col items-center gap-0.5 py-1 px-3 rounded-lg text-[10px] font-medium text-slate-500 hover:text-slate-900 transition-colors"
      >
        <MoreHorizontal className="w-5 h-5" />
        <span>Menu</span>
      </button>
    </nav>
  );
};
