import React from 'react';
import { 
  LayoutDashboard, 
  Building2, 
  Users, 
  FileText, 
  Receipt, 
  TrendingDown, 
  Wrench, 
  CreditCard, 
  Briefcase, 
  ShieldCheck, 
  X,
  Sparkles,
  Sliders,
  BarChart3
} from 'lucide-react';
import { UserProfile, SubscriptionState } from '../../types';

interface SidebarProps {
  currentView: string;
  onNavigate: (view: string) => void;
  user: UserProfile | null;
  subscription: SubscriptionState;
  isOpen: boolean;
  onClose: () => void;
}

export const Sidebar: React.FC<SidebarProps> = ({
  currentView,
  onNavigate,
  user,
  subscription,
  isOpen,
  onClose
}) => {
  const isSuperAdmin = user?.role === 'super_admin';
  const isTenant = user?.role === 'tenant';
  const isAgency = user?.role === 'agency_admin' || user?.role === 'agency_agent';

  // Navigation items per role
  const mainNavItems = [
    { id: 'dashboard', label: 'Tableau de bord', icon: LayoutDashboard, visible: true },
    { id: 'properties', label: 'Biens Immobiliers', icon: Building2, visible: !isTenant && !isSuperAdmin },
    { id: 'tenants', label: 'Locataires', icon: Users, visible: !isTenant && !isSuperAdmin },
    { id: 'leases', label: 'Baux & Contrats', icon: FileText, visible: !isTenant && !isSuperAdmin },
    { id: 'rents', label: 'Loyers & Quittances', icon: Receipt, visible: !isTenant && !isSuperAdmin },
    { id: 'expenses', label: 'Dépenses & Charges', icon: TrendingDown, visible: !isTenant && !isSuperAdmin },
    { id: 'repairs', label: 'Pannes & Travaux', icon: Wrench, visible: !isTenant && !isSuperAdmin },
    { id: 'reports', label: 'Rapports Financiers', icon: BarChart3, visible: !isTenant && !isSuperAdmin },
    { id: 'agency', label: 'Équipe & Mandats', icon: Briefcase, visible: isAgency },
    
    // Tenant specific
    { id: 'tenant_portal', label: 'Mon Logement & Quittances', icon: Building2, visible: isTenant },
    { id: 'tenant_repairs', label: 'Signaler une panne', icon: Wrench, visible: isTenant },

    // Super Admin specific
    { id: 'admin', label: 'Administration SaaS', icon: ShieldCheck, visible: isSuperAdmin },
    { id: 'admin_pricing', label: 'Tarifs & Formules', icon: Sliders, visible: isSuperAdmin },

    // Subscription
    { id: 'subscription', label: 'Mon Abonnement', icon: CreditCard, visible: !isTenant }
  ].filter(item => item.visible);

  const trialEnd = new Date(subscription.trialEndsAt);
  const now = new Date();
  const diffDays = Math.max(0, Math.ceil((trialEnd.getTime() - now.getTime()) / (1000 * 60 * 60 * 24)));

  return (
    <>
      {/* Mobile Backdrop */}
      {isOpen && (
        <div 
          onClick={onClose}
          className="fixed inset-0 bg-slate-950/40 backdrop-blur-xs z-40 md:hidden transition-opacity"
        />
      )}

      {/* Sidebar Container */}
      <aside
        className={`fixed top-0 bottom-0 left-0 z-50 w-64 bg-slate-900 text-slate-300 flex flex-col transition-transform duration-200 ease-in-out md:translate-x-0 md:static ${
          isOpen ? 'translate-x-0' : '-translate-x-full'
        }`}
      >
        {/* Sidebar Header */}
        <div className="flex items-center justify-between p-4 border-b border-slate-800">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-emerald-500 text-slate-950 flex items-center justify-center font-bold text-base shadow-sm">
              D
            </div>
            <div>
              <span className="text-base font-bold text-white tracking-tight">DARIMMO</span>
              <span className="text-[10px] text-emerald-400 block font-mono">Niger · Sahel SaaS</span>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="md:hidden p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Current Organization Card */}
        <div className="p-3 mx-3 my-3 bg-slate-800/80 rounded-xl border border-slate-700/60">
          <div className="flex items-center gap-2.5">
            <div className="w-7 h-7 rounded-lg bg-emerald-900/60 text-emerald-400 flex items-center justify-center font-semibold text-xs border border-emerald-700/40">
              {user?.organizationType === 'agency' ? 'AG' : 'PR'}
            </div>
            <div className="min-w-0 flex-1">
              <p className="text-xs font-semibold text-white truncate">
                {user?.organizationName || 'Mon Organisation'}
              </p>
              <p className="text-[10px] text-slate-400 truncate capitalize">
                {user?.role.replace('_', ' ')}
              </p>
            </div>
          </div>
        </div>

        {/* Navigation Links */}
        <div className="flex-1 px-3 py-2 space-y-1 overflow-y-auto">
          <div className="px-3 py-1.5 text-[10px] font-semibold text-slate-500 uppercase tracking-wider">
            Menu Principal
          </div>
          {mainNavItems.map(item => {
            const Icon = item.icon;
            const isActive = currentView === item.id;
            return (
              <button
                key={item.id}
                type="button"
                onClick={() => {
                  onNavigate(item.id);
                  onClose();
                }}
                className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-xs font-medium transition-all cursor-pointer ${
                  isActive
                    ? 'bg-emerald-600 text-white font-semibold shadow-xs shadow-emerald-900/40'
                    : 'text-slate-300 hover:text-white hover:bg-slate-800/70'
                }`}
              >
                <Icon className={`w-4 h-4 shrink-0 ${isActive ? 'text-white' : 'text-slate-400'}`} />
                <span className="truncate">{item.label}</span>
              </button>
            );
          })}
        </div>

        {/* Trial / Subscription Footer Card */}
        {!isSuperAdmin && !isTenant && (
          <div className="p-3 mx-3 mb-3 bg-gradient-to-b from-slate-800 to-slate-850 rounded-xl border border-slate-700/70">
            <div className="flex items-center gap-2 mb-1.5">
              <Sparkles className="w-4 h-4 text-emerald-400" />
              <span className="text-xs font-semibold text-white">
                {subscription.status === 'trial' ? 'Essai Gratuit' : `Plan ${subscription.planId.toUpperCase()}`}
              </span>
            </div>
            {subscription.status === 'trial' ? (
              <>
                <p className="text-[11px] text-slate-400 mb-2.5">
                  Il vous reste <strong className="text-emerald-400 font-mono">{diffDays} jours</strong> d’accès complet à toutes les fonctionnalités Pro.
                </p>
                <button
                  type="button"
                  onClick={() => {
                    onNavigate('subscription');
                    onClose();
                  }}
                  className="w-full py-1.5 px-3 bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold rounded-lg shadow-sm transition-colors cursor-pointer"
                >
                  Activer mon abonnement
                </button>
              </>
            ) : (
              <p className="text-[11px] text-slate-400">
                Abonnement actif · Valable jusqu'au {new Date(subscription.currentPeriodEnd).toLocaleDateString('fr-FR')}
              </p>
            )}
          </div>
        )}

        {/* Footer info */}
        <div className="p-3 border-t border-slate-800/80 text-[10px] text-slate-500 flex items-center justify-between">
          <span>DARIMMO v1.2</span>
          <span>Niamey, Niger</span>
        </div>
      </aside>
    </>
  );
};
