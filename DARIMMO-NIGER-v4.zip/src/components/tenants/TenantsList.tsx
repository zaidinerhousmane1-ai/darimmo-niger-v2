import React, { useState, useMemo } from 'react';
import { Users, Plus, Search, Phone, Mail, Building, Edit3, Trash2, Shield } from 'lucide-react';
import { Tenant } from '../../types';
import { Pagination } from '../common/Pagination';
import { EmptyState } from '../common/EmptyState';

interface TenantsListProps {
  tenants: Tenant[];
  onAddTenant: () => void;
  onEditTenant: (tenant: Tenant) => void;
  onDeleteTenant: (id: string) => void;
}

export const TenantsList: React.FC<TenantsListProps> = ({
  tenants,
  onAddTenant,
  onEditTenant,
  onDeleteTenant
}) => {
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState<'all' | 'actif' | 'ancien'>('all');
  const [tenantToDelete, setTenantToDelete] = useState<Tenant | null>(null);

  // Pagination state
  const [currentPage, setCurrentPage] = useState(1);
  const [pageSize, setPageSize] = useState(10);

  const filtered = useMemo(() => {
    return tenants.filter(t => {
      const matchSearch = search.trim() === '' ||
        t.fullName.toLowerCase().includes(search.toLowerCase()) ||
        t.phone.includes(search) ||
        t.propertyTitle.toLowerCase().includes(search.toLowerCase());

      const matchStatus = statusFilter === 'all' || t.status === statusFilter;
      return matchSearch && matchStatus;
    });
  }, [tenants, search, statusFilter]);

  const paginatedItems = useMemo(() => {
    const start = (currentPage - 1) * pageSize;
    return filtered.slice(start, start + pageSize);
  }, [filtered, currentPage, pageSize]);

  return (
    <div className="space-y-5 max-w-7xl mx-auto pb-12">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold text-slate-900 tracking-tight">Registre des Locataires</h2>
          <p className="text-xs text-slate-500 mt-0.5">
            Dossiers complets, coordonnées d'urgence et suivi des cautions.
          </p>
        </div>

        <button
          type="button"
          onClick={onAddTenant}
          className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs font-semibold bg-emerald-700 hover:bg-emerald-800 text-white shadow-xs transition-colors cursor-pointer self-start sm:self-auto"
        >
          <Plus className="w-4 h-4" />
          <span>Nouveau locataire</span>
        </button>
      </div>

      {/* Filter and Search */}
      <div className="p-4 bg-white rounded-2xl border border-slate-200/80 shadow-2xs flex flex-col sm:flex-row gap-3 items-stretch sm:items-center justify-between">
        <div className="flex-1 relative">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
          <input
            type="text"
            value={search}
            onChange={(e) => { setSearch(e.target.value); setCurrentPage(1); }}
            placeholder="Rechercher par nom de locataire, téléphone, bien loué..."
            className="w-full pl-9 pr-3 py-2 text-xs rounded-xl border border-slate-200 focus:outline-hidden focus:ring-1 focus:ring-emerald-500 bg-slate-50/50"
          />
        </div>

        <div className="flex items-center gap-2">
          <select
            value={statusFilter}
            onChange={(e) => { setStatusFilter(e.target.value as any); setCurrentPage(1); }}
            className="px-3 py-2 text-xs rounded-xl border border-slate-200 bg-white text-slate-700 focus:outline-hidden focus:ring-1 focus:ring-emerald-500"
          >
            <option value="all">Tous les locataires</option>
            <option value="actif">Locataires Actifs</option>
            <option value="ancien">Anciens Locataires</option>
          </select>
        </div>
      </div>

      {/* Content */}
      {filtered.length === 0 ? (
        <EmptyState
          icon={Users}
          title="Aucun dossier locataire trouvé"
          description={
            search || statusFilter !== 'all'
              ? 'Aucun résultat ne correspond à votre recherche.'
              : 'Vous n’avez pas encore associé de locataire à vos biens immobiliers.'
          }
          actionLabel="Créer un premier locataire"
          onAction={onAddTenant}
        />
      ) : (
        <div className="bg-white rounded-2xl border border-slate-200/80 shadow-2xs overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-50 text-slate-500 border-b border-slate-100">
                <tr>
                  <th className="py-3 px-4 font-semibold">Locataire</th>
                  <th className="py-3 px-4 font-semibold">Téléphone / Contact</th>
                  <th className="py-3 px-4 font-semibold">Logement Occupé</th>
                  <th className="py-3 px-4 font-semibold">Loyer Mensuel</th>
                  <th className="py-3 px-4 font-semibold">Caution Déposée</th>
                  <th className="py-3 px-4 font-semibold">Statut</th>
                  <th className="py-3 px-4 font-semibold text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {paginatedItems.map(t => (
                  <tr key={t.id} className="hover:bg-slate-50/60 transition-colors">
                    <td className="py-3 px-4">
                      <div>
                        <span className="font-semibold text-slate-900 block">{t.fullName}</span>
                        <span className="text-[10px] text-slate-400">{t.profession || 'Particulier'}</span>
                      </div>
                    </td>
                    <td className="py-3 px-4">
                      <div className="flex flex-col gap-0.5">
                        <a href={`tel:${t.phone}`} className="font-mono text-emerald-700 hover:underline flex items-center gap-1">
                          <Phone className="w-3 h-3" />
                          <span>{t.phone}</span>
                        </a>
                        {t.email && (
                          <span className="text-[10px] text-slate-400">{t.email}</span>
                        )}
                      </div>
                    </td>
                    <td className="py-3 px-4 text-slate-700 max-w-xs truncate">
                      {t.propertyTitle}
                    </td>
                    <td className="py-3 px-4 font-mono font-bold text-slate-900">
                      {t.monthlyRent.toLocaleString('fr-FR')} FCFA
                    </td>
                    <td className="py-3 px-4 font-mono text-slate-600">
                      {t.depositAmount.toLocaleString('fr-FR')} FCFA
                    </td>
                    <td className="py-3 px-4">
                      {t.status === 'actif' ? (
                        <span className="px-2 py-0.5 rounded text-[10px] font-semibold bg-emerald-50 text-emerald-800 border border-emerald-200">
                          En cours
                        </span>
                      ) : (
                        <span className="px-2 py-0.5 rounded text-[10px] font-semibold bg-slate-100 text-slate-600">
                          Sorti
                        </span>
                      )}
                    </td>
                    <td className="py-3 px-4 text-right">
                      <div className="inline-flex items-center gap-1">
                        <button
                          type="button"
                          onClick={() => onEditTenant(t)}
                          className="p-1 text-slate-500 hover:text-emerald-700 rounded-md hover:bg-slate-100"
                          title="Modifier"
                        >
                          <Edit3 className="w-4 h-4" />
                        </button>
                        <button
                          type="button"
                          onClick={() => setTenantToDelete(t)}
                          className="p-1 text-slate-400 hover:text-rose-600 rounded-md hover:bg-slate-100"
                          title="Supprimer"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          <Pagination
            currentPage={currentPage}
            totalItems={filtered.length}
            pageSize={pageSize}
            onPageChange={setCurrentPage}
            onPageSizeChange={(newSize) => {
              setPageSize(newSize);
              setCurrentPage(1);
            }}
          />
        </div>
      )}

      {/* Delete confirmation modal */}
      {tenantToDelete && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/60 backdrop-blur-xs">
          <div className="bg-white rounded-2xl shadow-xl border border-slate-200 max-w-sm w-full p-6 text-center animate-in fade-in zoom-in-95">
            <div className="w-12 h-12 rounded-full bg-rose-50 text-rose-600 flex items-center justify-center mx-auto mb-4">
              <Trash2 className="w-6 h-6" />
            </div>
            <h3 className="font-bold text-slate-900 text-sm mb-1">
              Supprimer le locataire
            </h3>
            <p className="text-xs text-slate-500 mb-6 leading-relaxed">
              Êtes-vous certain de vouloir retirer le dossier de <strong>« {tenantToDelete.fullName} »</strong> ?
            </p>
            <div className="flex gap-2">
              <button
                type="button"
                onClick={() => setTenantToDelete(null)}
                className="flex-1 py-2 px-3 text-xs font-semibold rounded-lg border border-slate-200 text-slate-600 hover:bg-slate-50"
              >
                Annuler
              </button>
              <button
                type="button"
                onClick={() => {
                  onDeleteTenant(tenantToDelete.id);
                  setTenantToDelete(null);
                }}
                className="flex-1 py-2 px-3 text-xs font-semibold rounded-lg bg-rose-600 hover:bg-rose-700 text-white"
              >
                Confirmer
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
