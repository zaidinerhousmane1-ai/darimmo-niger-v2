import React, { useState, useEffect } from 'react';
import { X, Wrench, AlertTriangle, Building, Phone, User, DollarSign, AlertCircle } from 'lucide-react';
import { RepairTicket, RepairPriority, RepairStatus, Property } from '../../types';

interface RepairModalProps {
  isOpen: boolean;
  repair: RepairTicket | null;
  properties: Property[];
  onClose: () => void;
  onSave: (repair: RepairTicket) => void;
  organizationId: string;
}

export const RepairModal: React.FC<RepairModalProps> = ({
  isOpen,
  repair,
  properties,
  onClose,
  onSave,
  organizationId
}) => {
  const [propertyId, setPropertyId] = useState('');
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [reportedBy, setReportedBy] = useState('');
  const [contactPhone, setContactPhone] = useState('+227 ');
  const [priority, setPriority] = useState<RepairPriority>('moyenne');
  const [status, setStatus] = useState<RepairStatus>('signale');
  const [estimatedCost, setEstimatedCost] = useState(25000);
  const [actualCost, setActualCost] = useState(0);
  const [technicianName, setTechnicianName] = useState('');
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (repair) {
      setPropertyId(repair.propertyId);
      setTitle(repair.title);
      setDescription(repair.description);
      setReportedBy(repair.reportedBy);
      setContactPhone(repair.contactPhone);
      setPriority(repair.priority);
      setStatus(repair.status);
      setEstimatedCost(repair.estimatedCost || 0);
      setActualCost(repair.actualCost || 0);
      setTechnicianName(repair.technicianName || '');
    } else {
      setPropertyId(properties[0]?.id || '');
      setTitle('');
      setDescription('');
      setReportedBy('Gestionnaire DARIMMO');
      setContactPhone('+227 90 12 34 56');
      setPriority('moyenne');
      setStatus('signale');
      setEstimatedCost(20000);
      setActualCost(0);
      setTechnicianName('');
    }
    setError(null);
  }, [repair, properties, isOpen]);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim() || !description.trim() || !propertyId) {
      setError('Veuillez renseigner le titre, le bien et la description de la panne.');
      return;
    }

    const selectedProp = properties.find(p => p.id === propertyId);

    const saved: RepairTicket = {
      id: repair ? repair.id : `rep_${Date.now()}`,
      organizationId,
      propertyId,
      propertyTitle: selectedProp ? `${selectedProp.title} (${selectedProp.neighborhood})` : 'Bien non spécifié',
      title: title.trim(),
      description: description.trim(),
      reportedBy: reportedBy.trim(),
      contactPhone: contactPhone.trim(),
      priority,
      status,
      estimatedCost: Number(estimatedCost) || 0,
      actualCost: Number(actualCost) || undefined,
      technicianName: technicianName.trim() || undefined,
      createdAt: repair ? repair.createdAt : new Date().toISOString(),
      resolvedAt: status === 'resolu' ? new Date().toISOString() : undefined
    };

    onSave(saved);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/60 backdrop-blur-xs overflow-y-auto">
      <div className="bg-white rounded-2xl shadow-2xl border border-slate-200 max-w-lg w-full overflow-hidden my-6 animate-in fade-in zoom-in-95">
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-100 bg-slate-50">
          <div className="flex items-center gap-2">
            <Wrench className="w-5 h-5 text-rose-600" />
            <h3 className="font-bold text-slate-900 text-sm sm:text-base">
              {repair ? 'Modifier le Ticket d’Intervention' : 'Signaler une Panne ou Travaux'}
            </h3>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-slate-600 rounded-lg hover:bg-slate-200/50"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-4 text-xs">
          {error && (
            <div className="p-3 rounded-lg bg-rose-50 border border-rose-200 text-rose-700 flex items-center gap-2">
              <AlertCircle className="w-4 h-4 shrink-0" />
              <span>{error}</span>
            </div>
          )}

          <div>
            <label className="block font-semibold text-slate-700 mb-1">
              Logement / Bien concerné *
            </label>
            <select
              required
              value={propertyId}
              onChange={(e) => setPropertyId(e.target.value)}
              className="w-full px-3 py-2 rounded-lg border border-slate-200 focus:outline-hidden focus:ring-1 focus:ring-rose-500 text-xs bg-white"
            >
              <option value="">Sélectionnez un bien immobilier...</option>
              {properties.map(p => (
                <option key={p.id} value={p.id}>
                  {p.title} — {p.neighborhood}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block font-semibold text-slate-700 mb-1">
              Objet de la panne / incident *
            </label>
            <input
              type="text"
              required
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="Ex: Fuite d’eau sous l'évier ou climatiseur en panne"
              className="w-full px-3 py-2 rounded-lg border border-slate-200 focus:outline-hidden focus:ring-1 focus:ring-rose-500 text-xs"
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block font-semibold text-slate-700 mb-1">
                Niveau d'urgence
              </label>
              <select
                value={priority}
                onChange={(e) => setPriority(e.target.value as RepairPriority)}
                className="w-full px-3 py-2 rounded-lg border border-slate-200 focus:outline-hidden focus:ring-1 focus:ring-rose-500 text-xs bg-white font-semibold"
              >
                <option value="basse">Basse (Non urgent)</option>
                <option value="moyenne">Moyenne (Sous 5 jours)</option>
                <option value="haute">Haute (Sous 48h)</option>
                <option value="urgente">Urgente (Immédiat / Danger)</option>
              </select>
            </div>

            <div>
              <label className="block font-semibold text-slate-700 mb-1">
                État d'avancement
              </label>
              <select
                value={status}
                onChange={(e) => setStatus(e.target.value as RepairStatus)}
                className="w-full px-3 py-2 rounded-lg border border-slate-200 focus:outline-hidden focus:ring-1 focus:ring-rose-500 text-xs bg-white font-semibold"
              >
                <option value="signale">Signalé</option>
                <option value="en_cours">En cours de réparation</option>
                <option value="resolu">Résolu / Terminé</option>
                <option value="annule">Annulé</option>
              </select>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block font-semibold text-slate-700 mb-1">
                Déclaré par
              </label>
              <input
                type="text"
                value={reportedBy}
                onChange={(e) => setReportedBy(e.target.value)}
                placeholder="Ex: Nom du locataire ou du gardien"
                className="w-full px-3 py-2 rounded-lg border border-slate-200 focus:outline-hidden focus:ring-1 focus:ring-rose-500 text-xs"
              />
            </div>

            <div>
              <label className="block font-semibold text-slate-700 mb-1">
                Téléphone de contact
              </label>
              <input
                type="tel"
                value={contactPhone}
                onChange={(e) => setContactPhone(e.target.value)}
                placeholder="+227 90 00 00 00"
                className="w-full px-3 py-2 rounded-lg border border-slate-200 focus:outline-hidden focus:ring-1 focus:ring-rose-500 text-xs"
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block font-semibold text-slate-700 mb-1">
                Artisan / Technicien assigné
              </label>
              <input
                type="text"
                value={technicianName}
                onChange={(e) => setTechnicianName(e.target.value)}
                placeholder="Ex: Oumarou (Frigoriste / Plombier)"
                className="w-full px-3 py-2 rounded-lg border border-slate-200 focus:outline-hidden focus:ring-1 focus:ring-rose-500 text-xs"
              />
            </div>

            <div>
              <label className="block font-semibold text-slate-700 mb-1">
                Coût estimé / réel (FCFA)
              </label>
              <input
                type="number"
                step={2500}
                value={status === 'resolu' ? actualCost : estimatedCost}
                onChange={(e) => {
                  if (status === 'resolu') setActualCost(Number(e.target.value));
                  else setEstimatedCost(Number(e.target.value));
                }}
                className="w-full px-3 py-2 rounded-lg border border-slate-200 focus:outline-hidden focus:ring-1 focus:ring-rose-500 text-xs font-mono"
              />
            </div>
          </div>

          <div>
            <label className="block font-semibold text-slate-700 mb-1">
              Description détaillée du problème *
            </label>
            <textarea
              rows={3}
              required
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="Précisez la localisation de la fuite, les symptômes observés, le matériel défaillant..."
              className="w-full px-3 py-2 rounded-lg border border-slate-200 focus:outline-hidden focus:ring-1 focus:ring-rose-500 text-xs"
            />
          </div>

          <div className="flex justify-end gap-2 pt-3 border-t border-slate-100">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 rounded-lg border border-slate-200 text-slate-600 hover:bg-slate-50 transition-colors font-medium text-xs cursor-pointer"
            >
              Annuler
            </button>
            <button
              type="submit"
              className="px-4 py-2 rounded-lg bg-rose-600 hover:bg-rose-700 text-white font-semibold text-xs transition-colors cursor-pointer"
            >
              {repair ? 'Enregistrer les modifications' : 'Créer l’intervention'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
