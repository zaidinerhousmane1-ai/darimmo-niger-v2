/**
 * DARIMMO - Service Cloud Firestore Multi-Tenant
 * Gestion des collections isolées par organisation
 */

import { 
  collection, 
  doc, 
  getDoc, 
  getDocs, 
  setDoc, 
  updateDoc, 
  deleteDoc, 
  query, 
  where, 
  orderBy,
  serverTimestamp,
  onSnapshot 
} from 'firebase/firestore';
import { db } from './firebase';
import { 
  UserProfile, 
  Property, 
  Tenant, 
  Lease, 
  RentPayment, 
  Expense, 
  RepairTicket, 
  AgencyMember, 
  SubscriptionState, 
  SubscriptionPaymentRequest, 
  AppNotification, 
  AuditLog,
  PlanConfig,
  AppConfig
} from '../types';

export class FirestoreService {
  // === UTILISATEURS ===
  async getUserProfile(uid: string): Promise<UserProfile | null> {
    try {
      const userRef = doc(db, 'users', uid);
      const snap = await getDoc(userRef);
      if (snap.exists()) {
        return snap.data() as UserProfile;
      }
      return null;
    } catch (err) {
      console.warn('Erreur getUserProfile Firestore:', err);
      return null;
    }
  }

  async createUserProfile(profile: UserProfile): Promise<void> {
    const userRef = doc(db, 'users', profile.id);
    await setDoc(userRef, {
      ...profile,
      updatedAt: new Date().toISOString()
    }, { merge: true });
  }

  // === BIENS IMMOBILIERS ===
  async getProperties(orgId: string): Promise<Property[]> {
    try {
      const q = query(collection(db, 'properties'), where('organizationId', '==', orgId));
      const snap = await getDocs(q);
      return snap.docs.map(d => ({ ...d.data(), id: d.id } as Property));
    } catch (err) {
      console.warn('Erreur getProperties Firestore:', err);
      return [];
    }
  }

  // Acces global reserve au Super Admin (protege aussi par firestore.rules).
  async getAllProperties(): Promise<Property[]> {
    const snap = await getDocs(collection(db, 'properties'));
    return snap.docs.map(d => ({ ...d.data(), id: d.id } as Property));
  }

  // Les organisations sont des documents autonomes. Les profils utilisateurs
  // owner/agency_admin restent associes a leur organizationId lorsqu'ils existent.
  async getAllOrganizations(): Promise<UserProfile[]> {
    const [usersSnap, orgsSnap] = await Promise.all([
      getDocs(collection(db, 'users')),
      getDocs(collection(db, 'organizations'))
    ]);
    const unique = new Map<string, UserProfile>();
    usersSnap.docs
      .map(d => ({ ...d.data(), id: d.id } as UserProfile))
      .filter(u => ['owner', 'agency_admin'].includes(u.role) && !!u.organizationId)
      .forEach(profile => {
        const existing = unique.get(profile.organizationId);
        if (!existing || profile.role === 'owner') unique.set(profile.organizationId, profile);
      });
    orgsSnap.docs.forEach(d => {
      const data = d.data();
      const organizationId = String(data.organizationId || d.id);
      const existing = unique.get(organizationId);
      unique.set(organizationId, {
        id: existing?.id || organizationId,
        email: existing?.email || '',
        fullName: existing?.fullName || data.organizationName || 'Organisation sans responsable',
        phone: existing?.phone || '',
        role: existing?.role || 'owner',
        organizationId,
        organizationName: data.organizationName || existing?.organizationName || 'Organisation sans nom',
        organizationType: data.organizationType || existing?.organizationType || 'agency',
        createdAt: data.createdAt || existing?.createdAt || new Date().toISOString(),
        isSuspended: data.isSuspended === true || existing?.isSuspended === true
      });
    });
    return Array.from(unique.values());
  }

  async createOrganization(organizationName: string, organizationType: 'individual' | 'agency'): Promise<string> {
    const name = organizationName.trim();
    if (!name) throw new Error('Le nom de l’organisation est obligatoire.');
    const organizationId = `org_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`;
    await setDoc(doc(db, 'organizations', organizationId), {
      organizationId,
      organizationName: name,
      organizationType,
      isSuspended: false,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    });
    return organizationId;
  }

  async updateOrganizationName(organizationId: string, organizationName: string): Promise<void> {
    const name = organizationName.trim();
    if (!name) throw new Error('Le nom de l’organisation est obligatoire.');
    const orgRef = doc(db, 'organizations', organizationId);
    const orgSnap = await getDoc(orgRef);
    if (orgSnap.exists()) await updateDoc(orgRef, { organizationName: name, updatedAt: new Date().toISOString() });
    const snap = await getDocs(collection(db, 'users'));
    const members = snap.docs.filter(d => d.data().organizationId === organizationId);
    await Promise.all(members.map(member => updateDoc(doc(db, 'users', member.id), {
      organizationName: name, updatedAt: new Date().toISOString()
    })));
    if (!orgSnap.exists() && !members.length) throw new Error('Organisation introuvable.');
  }

  async setOrganizationSuspended(organizationId: string, isSuspended: boolean): Promise<void> {
    const orgRef = doc(db, 'organizations', organizationId);
    const orgSnap = await getDoc(orgRef);
    if (orgSnap.exists()) await updateDoc(orgRef, { isSuspended, updatedAt: new Date().toISOString() });
    const snap = await getDocs(collection(db, 'users'));
    const members = snap.docs.filter(d => d.data().organizationId === organizationId);
    await Promise.all(members.map(member => updateDoc(doc(db, 'users', member.id), {
      isSuspended, updatedAt: new Date().toISOString()
    })));
    if (!orgSnap.exists() && !members.length) throw new Error('Organisation introuvable.');
  }

  // Tous les comptes utilisateurs (hors super admin) : sert a affecter un responsable a une organisation.
  async getAllUsers(): Promise<UserProfile[]> {
    const snap = await getDocs(collection(db, 'users'));
    return snap.docs
      .map(d => ({ ...d.data(), id: d.id } as UserProfile))
      .filter(u => u.role !== 'super_admin');
  }

  // Rattache un compte existant (owner / agency_admin) a une organisation.
  // Autorise par les regles Firestore uniquement pour le Super Admin.
  async assignUserToOrganization(userId: string, organizationId: string): Promise<void> {
    let organizationName = '';
    let organizationType: 'individual' | 'agency' = 'agency';
    let isSuspended = false;
    const orgSnap = await getDoc(doc(db, 'organizations', organizationId));
    if (orgSnap.exists()) {
      const data = orgSnap.data();
      organizationName = String(data.organizationName || '');
      organizationType = data.organizationType === 'individual' ? 'individual' : 'agency';
      isSuspended = data.isSuspended === true;
    } else {
      const usersSnap = await getDocs(collection(db, 'users'));
      const member = usersSnap.docs.map(d => d.data()).find(u => u.organizationId === organizationId);
      if (!member) throw new Error('Organisation introuvable.');
      organizationName = String(member.organizationName || '');
      organizationType = member.organizationType === 'individual' ? 'individual' : 'agency';
      isSuspended = member.isSuspended === true;
    }
    await updateDoc(doc(db, 'users', userId), {
      organizationId,
      organizationName,
      organizationType,
      isSuspended,
      updatedAt: new Date().toISOString()
    });
  }

  async saveProperty(property: Property): Promise<void> {
    const ref = doc(db, 'properties', property.id);
    await setDoc(ref, {
      ...property,
      updatedAt: new Date().toISOString()
    }, { merge: true });
  }

  async deleteProperty(propertyId: string): Promise<void> {
    await deleteDoc(doc(db, 'properties', propertyId));
  }

  // === LOCATAIRES ===
  async getTenants(orgId: string): Promise<Tenant[]> {
    try {
      const q = query(collection(db, 'tenants'), where('organizationId', '==', orgId));
      const snap = await getDocs(q);
      return snap.docs.map(d => ({ ...d.data(), id: d.id } as Tenant));
    } catch (err) {
      console.warn('Erreur getTenants Firestore:', err);
      return [];
    }
  }

  async saveTenant(tenant: Tenant): Promise<void> {
    const ref = doc(db, 'tenants', tenant.id);
    await setDoc(ref, {
      ...tenant,
      updatedAt: new Date().toISOString()
    }, { merge: true });
  }

  async deleteTenant(tenantId: string): Promise<void> {
    await deleteDoc(doc(db, 'tenants', tenantId));
  }

  // === BAUX ET CONTRATS ===
  async getLeases(orgId: string): Promise<Lease[]> {
    try {
      const q = query(collection(db, 'leases'), where('organizationId', '==', orgId));
      const snap = await getDocs(q);
      return snap.docs.map(d => ({ ...d.data(), id: d.id } as Lease));
    } catch (err) {
      console.warn('Erreur getLeases Firestore:', err);
      return [];
    }
  }

  async saveLease(lease: Lease): Promise<void> {
    const ref = doc(db, 'leases', lease.id);
    await setDoc(ref, {
      ...lease,
      updatedAt: new Date().toISOString()
    }, { merge: true });
  }

  // === PAIEMENTS ET QUITTANCES DE LOYER ===
  async getRentPayments(orgId: string): Promise<RentPayment[]> {
    try {
      const q = query(collection(db, 'rent_payments'), where('organizationId', '==', orgId));
      const snap = await getDocs(q);
      return snap.docs.map(d => ({ ...d.data(), id: d.id } as RentPayment));
    } catch (err) {
      console.warn('Erreur getRentPayments Firestore:', err);
      return [];
    }
  }

  async saveRentPayment(payment: RentPayment): Promise<void> {
    const ref = doc(db, 'rent_payments', payment.id);
    await setDoc(ref, {
      ...payment,
      updatedAt: new Date().toISOString()
    }, { merge: true });
  }

  // === DÉPENSES ===
  async getExpenses(orgId: string): Promise<Expense[]> {
    try {
      const q = query(collection(db, 'expenses'), where('organizationId', '==', orgId));
      const snap = await getDocs(q);
      return snap.docs.map(d => ({ ...d.data(), id: d.id } as Expense));
    } catch (err) {
      console.warn('Erreur getExpenses Firestore:', err);
      return [];
    }
  }

  async saveExpense(expense: Expense): Promise<void> {
    const ref = doc(db, 'expenses', expense.id);
    await setDoc(ref, {
      ...expense,
      updatedAt: new Date().toISOString()
    }, { merge: true });
  }

  async deleteExpense(expenseId: string): Promise<void> {
    await deleteDoc(doc(db, 'expenses', expenseId));
  }

  // === RÉPARATIONS ET PANNES ===
  async getRepairs(orgId: string): Promise<RepairTicket[]> {
    try {
      const q = query(collection(db, 'repairs'), where('organizationId', '==', orgId));
      const snap = await getDocs(q);
      return snap.docs.map(d => ({ ...d.data(), id: d.id } as RepairTicket));
    } catch (err) {
      console.warn('Erreur getRepairs Firestore:', err);
      return [];
    }
  }

  async saveRepair(repair: RepairTicket): Promise<void> {
    const ref = doc(db, 'repairs', repair.id);
    await setDoc(ref, {
      ...repair,
      updatedAt: new Date().toISOString()
    }, { merge: true });
  }

  // === MEMBRES D'AGENCE ===
  async getAgencyMembers(orgId: string): Promise<AgencyMember[]> {
    try {
      const q = query(collection(db, 'agency_members'), where('organizationId', '==', orgId));
      const snap = await getDocs(q);
      return snap.docs.map(d => ({ ...d.data(), id: d.id } as AgencyMember));
    } catch (err) {
      console.warn('Erreur getAgencyMembers Firestore:', err);
      return [];
    }
  }

  async saveAgencyMember(member: AgencyMember): Promise<void> {
    const ref = doc(db, 'agency_members', member.id);
    await setDoc(ref, {
      ...member,
      updatedAt: new Date().toISOString()
    }, { merge: true });
  }

  // === ABONNEMENTS ET ESSAIS ===
  async getSubscription(orgId: string): Promise<SubscriptionState | null> {
    try {
      const ref = doc(db, 'subscriptions', orgId);
      const snap = await getDoc(ref);
      if (snap.exists()) {
        return snap.data() as SubscriptionState;
      }
      return null;
    } catch (err) {
      console.warn('Erreur getSubscription Firestore:', err);
      return null;
    }
  }

  async saveSubscription(sub: SubscriptionState): Promise<void> {
    const ref = doc(db, 'subscriptions', sub.organizationId);
    await setDoc(ref, {
      ...sub,
      updatedAt: new Date().toISOString()
    }, { merge: true });
  }

  // === DEMANDES DE PAIEMENTS D'ABONNEMENT (Nita, Amana, Airtel Money) ===
  async getPaymentRequests(orgId?: string): Promise<SubscriptionPaymentRequest[]> {
    try {
      const q = orgId 
        ? query(collection(db, 'payment_requests'), where('organizationId', '==', orgId))
        : collection(db, 'payment_requests');
      const snap = await getDocs(q);
      return snap.docs.map(d => ({ ...d.data(), id: d.id } as SubscriptionPaymentRequest));
    } catch (err) {
      console.warn('Erreur getPaymentRequests Firestore:', err);
      return [];
    }
  }

  async savePaymentRequest(req: SubscriptionPaymentRequest): Promise<void> {
    const ref = doc(db, 'payment_requests', req.id);
    await setDoc(ref, {
      ...req,
      updatedAt: new Date().toISOString()
    }, { merge: true });
  }

  // === NOTIFICATIONS ===
  async getNotifications(orgId: string): Promise<AppNotification[]> {
    try {
      const q = query(collection(db, 'notifications'), where('organizationId', '==', orgId));
      const snap = await getDocs(q);
      return snap.docs.map(d => ({ ...d.data(), id: d.id } as AppNotification));
    } catch (err) {
      console.warn('Erreur getNotifications Firestore:', err);
      return [];
    }
  }

  async saveNotification(notif: AppNotification): Promise<void> {
    const ref = doc(db, 'notifications', notif.id);
    await setDoc(ref, notif, { merge: true });
  }

  // === JOURNAL D'AUDIT ===
  async getAuditLogs(orgId?: string): Promise<AuditLog[]> {
    try {
      const q = orgId 
        ? query(collection(db, 'audit_logs'), where('organizationId', '==', orgId))
        : collection(db, 'audit_logs');
      const snap = await getDocs(q);
      return snap.docs.map(d => ({ ...d.data(), id: d.id } as AuditLog));
    } catch (err) {
      console.warn('Erreur getAuditLogs Firestore:', err);
      return [];
    }
  }

  async addAuditLog(log: AuditLog): Promise<void> {
    const ref = doc(db, 'audit_logs', log.id);
    await setDoc(ref, {
      ...log,
      timestamp: new Date().toISOString()
    });
  }

  // === MODE MAINTENANCE EN TEMPS RÉEL (app_config/maintenance) ===
  async updateMaintenanceConfig(cfg: {
    maintenanceMode: boolean;
    maintenanceMessage: string;
    maintenanceExpectedEnd?: string;
  }): Promise<void> {
    const ref = doc(db, 'app_config', 'maintenance');
    await setDoc(ref, {
      ...cfg,
      updatedAt: new Date().toISOString()
    }, { merge: true });
  }

  onMaintenanceChange(callback: (cfg: {
    maintenanceMode: boolean;
    maintenanceMessage: string;
    maintenanceExpectedEnd?: string;
  }) => void): () => void {
    const ref = doc(db, 'app_config', 'maintenance');
    return onSnapshot(
      ref,
      (docSnap) => {
        if (docSnap.exists()) {
          const data = docSnap.data();
          callback({
            maintenanceMode: !!data.maintenanceMode,
            maintenanceMessage: data.maintenanceMessage || "Nous procédons actuellement à une opération de maintenance et d'optimisation.",
            maintenanceExpectedEnd: data.maintenanceExpectedEnd || ''
          });
        }
      },
      (err) => {
        console.warn('Erreur écoute maintenance Firestore:', err);
      }
    );
  }
}

export const firestoreService = new FirestoreService();
